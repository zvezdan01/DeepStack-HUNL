"""Source-faithful port of the original DeepStack-Leduc data generation
(reference_lua/Source/DataGeneration/{data_generation,range_generator,
random_card_generator}.lua), line-level faithful including dtypes, op order
and the original quirks. New Phase-2 code — the Golden Baseline engine
(deepstack_leduc/*) is consumed read-only via its certified public API.

Faithfulness notes (Lua line references):
- board: one torch.random(1,6) rejection sampler (random_card_generator.lua:16-32)
- ranges: strength-sorted stick-breaking (range_generator.lua:18-42), f32
  masses, rand per internal node, torch.random(0,1) per odd split, left-first
  recursion; un-sort via gather + maskedCopy (:88-102). torch7 sort on <=10
  elements is a stable insertion sort (THTensorMath.c:2107-2180 with
  M_SMALL=10), so np.argsort(kind='stable') is exact.
- pots: 100 + U[0,1)*1099.9 in f32 (mul then add passes), feature =
  pot * f32(1/1200) (data_generation.lua:77-84); the solver pot is
  RECOMPUTED from the f32 feature in double: feature*1200
  (data_generation.lua:105) — the round-trip is reproduced.
- targets: per sample fresh Resolving().resolve_first_node on street-2
  {board, P1, bets=(pot,pot)}, get_root_cfv_both_players, then
  values:mul(1/pot) with 1/pot double cast to f32 (:98-112).
- serialization: inputs 73 = [P1 36 buckets | P2 36 buckets | pot],
  targets 72, mask 36; valid file generated FIRST, then train
  (data_generation.lua:25-40); Torch7 f32 .t7 files.
- bucket conversion: f32 0/1 matrix mat-mul via the bundled Torch7 BLAS
  (bucket_conversion.lua:19-75); implemented here f32-faithfully (the
  training-side deepstack_leduc.bucketing.BucketConversion is float64 and
  is intentionally NOT used).
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from deepstack_leduc.bucketing import Bucketer
from deepstack_leduc.card_tools import possible_hand_indexes
from deepstack_leduc.cards import hand_strength
from deepstack_leduc.config import Config
from deepstack_leduc.resolving import Resolving
from deepstack_leduc.torch7_blas import mm as torch7_mm
from deepstack_leduc.tree import Node

from .lua_tree import LuaF32TreeBuilder
from .t7_writer import save_float_tensor
from .th_random import THRandom

CARD_COUNT = 6


def batch_eval(board_card: int) -> np.ndarray:
    """evaluator.lua:89-106 batch_eval for a 1-card board: strength per
    private card, impossible (board) card = -1. f32 like arguments.Tensor."""
    out = np.full(CARD_COUNT, -1.0, dtype=np.float32)
    for card in range(CARD_COUNT):
        if card != board_card:
            out[card] = np.float32(hand_strength(card, (board_card,)))
    return out


def generate_board(rng: THRandom, count: int = 1) -> list[int]:
    """random_card_generator.lua:16-32 (0-based cards)."""
    used = [0] * CARD_COUNT
    out = []
    while len(out) < count:
        card = rng.random_range(1, CARD_COUNT)  # 1-based draw as in Lua
        if not used[card - 1]:
            out.append(card - 1)
            used[card - 1] = 1
    return out


class RangeGenerator:
    """Port of range_generator.lua."""

    def set_board(self, board_card: int) -> None:
        strengths = batch_eval(board_card)
        mask = possible_hand_indexes((board_card,)).astype(bool)
        self.possible_mask = mask
        self.possible_count = int(mask.sum())
        non_colliding = strengths[mask]  # maskedSelect: card order
        # torch7 sort (stable insertion sort for <=10 elements)
        order = np.argsort(non_colliding, kind='stable')
        self.reverse_order = np.argsort(order, kind='stable')

    def _generate_recursion(self, cards: np.ndarray, mass: np.ndarray,
                            rng: THRandom) -> None:
        batch_size, card_count = cards.shape
        if card_count == 1:
            cards[:, 0] = mass
            return
        rand = rng.rand_float(batch_size)
        mass1 = (mass * rand).astype(np.float32, copy=False)
        mass2 = (mass - mass1).astype(np.float32, copy=False)
        half = card_count / 2
        if half % 1 != 0:
            half = (half - 0.5) + rng.random_range(0, 1)
        half = int(half)
        self._generate_recursion(cards[:, :half], mass1, rng)
        self._generate_recursion(cards[:, half:], mass2, rng)

    def generate_range(self, out_range: np.ndarray, rng: THRandom) -> None:
        batch_size = out_range.shape[0]
        sorted_range = np.empty((batch_size, self.possible_count), dtype=np.float32)
        self._generate_recursion(
            sorted_range, np.ones(batch_size, dtype=np.float32), rng
        )
        reordered = sorted_range[:, self.reverse_order]  # gather
        out_range[:] = 0.0
        out_range[:, self.possible_mask] = reordered  # maskedCopy


class BucketConversionF32:
    """f32-faithful port of Nn/bucket_conversion.lua (mat-mul semantics)."""

    def set_board(self, board_card: int) -> None:
        bucketer = Bucketer()
        self.bucket_count = bucketer.get_bucket_count()
        buckets = bucketer.compute_buckets((board_card,))
        self.range_matrix = np.zeros((CARD_COUNT, self.bucket_count), dtype=np.float32)
        for card in range(CARD_COUNT):
            b = int(buckets[card])
            if b >= 0:
                self.range_matrix[card, b] = 1.0

    def card_range_to_bucket_range(self, card_range: np.ndarray) -> np.ndarray:
        return torch7_mm(
            np.ascontiguousarray(card_range, dtype=np.float32), self.range_matrix
        )

    def get_possible_bucket_mask(self) -> np.ndarray:
        ones = np.ones((1, CARD_COUNT), dtype=np.float32)
        return torch7_mm(ones, self.range_matrix)


def resolve_targets(board_card: int, pot_size: float,
                    p1_range: np.ndarray, p2_range: np.ndarray,
                    net, cfg: Config) -> np.ndarray:
    """data_generation.lua:98-112 per-sample target computation via the
    certified Golden Baseline resolve path."""
    resolving = Resolving(cfg, net)
    # Lua-faithful f32 bets at every tree node (divergence D1 remedy;
    # Golden Baseline builder is injected-around, not modified)
    resolving.tree_builder = LuaF32TreeBuilder(cfg)
    node = Node(2, 0, np.array([pot_size, pot_size], dtype=np.float32),
                (board_card,))
    resolving.resolve_first_node(node, p1_range, p2_range)
    root_values = resolving.get_root_cfv_both_players()
    root_values *= np.float32(1.0 / pot_size)  # mul(1/pot_size): double->f32
    return root_values


def generate_data_file(data_count: int, file_prefix: str | Path,
                       rng: THRandom, net, cfg: Config = Config()) -> None:
    """data_generation.lua:52-128."""
    batch_size = 10  # arguments.gen_batch_size
    assert data_count % batch_size == 0
    batch_count = data_count // batch_size
    bucket_count = Bucketer().get_bucket_count()
    target_size = bucket_count * 2
    input_size = bucket_count * 2 + 1
    targets = np.zeros((data_count, target_size), dtype=np.float32)
    inputs = np.zeros((data_count, input_size), dtype=np.float32)
    mask = np.zeros((data_count, bucket_count), dtype=np.float32)
    range_generator = RangeGenerator()
    conversion = BucketConversionF32()

    for batch in range(batch_count):
        board_card = generate_board(rng)[0]
        range_generator.set_board(board_card)
        conversion.set_board(board_card)

        ranges = np.zeros((2, batch_size, CARD_COUNT), dtype=np.float32)
        for player in range(2):
            range_generator.generate_range(ranges[player], rng)

        min_pot = np.float32(100.0)             # arguments.ante
        pot_range = np.float32(1200 - 0.1 - 100)  # computed double, cast at mul
        pots = rng.rand_float(batch_size)
        pots = (pots * pot_range).astype(np.float32, copy=False)
        pots = (pots + min_pot).astype(np.float32, copy=False)
        pot_features = (pots * np.float32(1.0 / 1200.0)).astype(np.float32, copy=False)

        rows = slice(batch * batch_size, (batch + 1) * batch_size)
        inputs[rows, -1] = pot_features
        for player in range(2):
            block = slice(player * bucket_count, (player + 1) * bucket_count)
            inputs[rows, block] = conversion.card_range_to_bucket_range(ranges[player])

        values = np.zeros((2, batch_size, CARD_COUNT), dtype=np.float32)
        for i in range(batch_size):
            pot_size = float(pot_features[i]) * 1200.0  # Lua double round-trip
            root_values = resolve_targets(board_card, pot_size,
                                          ranges[0][i], ranges[1][i], net, cfg)
            values[:, i, :] = root_values

        for player in range(2):
            block = slice(player * bucket_count, (player + 1) * bucket_count)
            targets[rows, block] = conversion.card_range_to_bucket_range(values[player])
        mask[rows, :] = conversion.get_possible_bucket_mask()

    file_prefix = str(file_prefix)
    save_float_tensor(file_prefix + '.inputs', inputs)
    save_float_tensor(file_prefix + '.targets', targets)
    save_float_tensor(file_prefix + '.mask', mask)


def generate_data(train_count: int, valid_count: int, out_dir: str | Path,
                  rng: THRandom, net, cfg: Config = Config()) -> None:
    """data_generation.lua:25-40 — valid FIRST, then train, one RNG stream."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    generate_data_file(valid_count, out_dir / 'valid', rng, net, cfg)
    generate_data_file(train_count, out_dir / 'train', rng, net, cfg)
