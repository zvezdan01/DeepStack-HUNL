#!/usr/bin/env python3
"""Certify datagen/th_random.py bit-for-bit against the untouched original
THRandom.c oracle streams (datagen/thrandom_oracle/*.bin).
Run from the DS repo root with PYTHONPATH=."""
import struct
import sys
from pathlib import Path

import numpy as np

from datagen.th_random import THRandom

ROOT = Path(__file__).resolve().parent / 'thrandom_oracle'
SEEDS = [0, 1, 42, 20260812]
N = 10000
ok = True

for seed in SEEDS:
    g = THRandom(seed)
    ours = struct.pack(f'<{N}I', *[g.random_u32() for _ in range(N)])
    ref = (ROOT / f'u32_{seed}.bin').read_bytes()
    match = ours == ref
    ok &= match
    print(f'u32     seed={seed}: byte_equal={match}')

    g = THRandom(seed)
    ours = g.rand_float(N).tobytes()
    ref = (ROOT / f'rand_{seed}.bin').read_bytes()
    match = ours == ref
    ok &= match
    print(f'rand    seed={seed}: byte_equal={match}')

    g = THRandom(seed)
    ours = struct.pack(f'<{N}q', *[g.random_range(1, 6) for _ in range(N)])
    ref = (ROOT / f'ri16_{seed}.bin').read_bytes()
    match = ours == ref
    ok &= match
    print(f'randint seed={seed}: byte_equal={match}')

print('THRANDOM BIT EXACT:', 'PASS' if ok else 'FAIL')
sys.exit(0 if ok else 1)
