#!/usr/bin/env python3
"""Phase-2A core oracle: invert the 200 bundled author TrainSamples rows and
re-run the deterministic generator tail through the Golden Baseline resolve
path; compare with np.array_equal, zero tolerance.

Per row: board <- mask block; card ranges <- input bucket blocks (lossless —
bucketing is a permutation scatter of the 5 possible cards); pot_size <-
pot_feature * 1200 in double (exactly data_generation.lua:105). Then
resolve_first_node (street 2, P1, bets=(pot,pot)), get_root_cfv_both_players,
mul f32(1/pot), bucketize, compare against stored .targets. Additionally the
recovered ranges are re-bucketized and compared against the stored .inputs
blocks (inversion soundness) and the recomputed bucket mask against .mask.

On first divergence: freeze the row, dump index/expected/actual bytes and
upstream state. Run from the DS repo root, LD_LIBRARY_PATH=$PWD PYTHONPATH=.
"""
from pathlib import Path

import numpy as np

from datagen.generator import BucketConversionF32, resolve_targets
from deepstack_leduc.config import Config
from deepstack_leduc.torch7_blas import BIT_EXACT_BACKEND
from deepstack_leduc.torch7_tensor import load_float_tensor
from deepstack_leduc.value_model import load_original_value_net

assert BIT_EXACT_BACKEND, 'bit-exact BLAS backend required'

ROOT = Path('reference_lua/Data/TrainSamples/PotBet')
BUCKETS = 36
cfg = Config()
net = load_original_value_net()

rows_total = 0
rows_exact = 0
values_compared = 0
failures = []


def first_diff(a: np.ndarray, b: np.ndarray):
    idx = np.nonzero(a != b)[0]
    if len(idx) == 0:
        return None
    i = int(idx[0])
    return i, float(a[i]), float(b[i]), a[i].tobytes().hex(), b[i].tobytes().hex()


for split in ('train', 'valid'):
    inputs = load_float_tensor(ROOT / f'{split}.inputs')
    targets = load_float_tensor(ROOT / f'{split}.targets')
    mask = load_float_tensor(ROOT / f'{split}.mask')
    for r in range(inputs.shape[0]):
        rows_total += 1
        mrow = mask[r]
        # board from mask: the block with 5 ones
        blocks = mrow.reshape(6, 6)
        board_candidates = [b for b in range(6) if blocks[b].sum() == 5]
        if len(board_candidates) != 1:
            failures.append((split, r, 'mask', 'ambiguous board', None))
            continue
        board = board_candidates[0]

        conv = BucketConversionF32()
        conv.set_board(board)

        # recover card ranges from input bucket blocks
        ranges = np.zeros((2, 6), dtype=np.float32)
        for player in range(2):
            block = inputs[r, player * BUCKETS:(player + 1) * BUCKETS]
            for card in range(6):
                if card != board:
                    ranges[player, card] = block[board * 6 + card]

        pot_feature = inputs[r, -1]
        pot_size = float(pot_feature) * 1200.0

        # inversion soundness: re-bucketize == stored input blocks
        rebucket = conv.card_range_to_bucket_range(ranges)
        stored_blocks = inputs[r, :2 * BUCKETS].reshape(2, BUCKETS)
        values_compared += stored_blocks.size
        if not np.array_equal(rebucket, stored_blocks):
            failures.append((split, r, 'inputs', first_diff(rebucket.ravel(), stored_blocks.ravel()), None))
            continue
        # mask check
        m = conv.get_possible_bucket_mask().reshape(-1)
        values_compared += mrow.size
        if not np.array_equal(m, mrow):
            failures.append((split, r, 'mask', first_diff(m, mrow), None))
            continue

        # deterministic target recomputation through the Golden Baseline
        root_values = resolve_targets(board, pot_size, ranges[0], ranges[1], net, cfg)
        computed = conv.card_range_to_bucket_range(root_values).reshape(-1)
        stored = targets[r]
        values_compared += stored.size
        if np.array_equal(computed, stored):
            rows_exact += 1
        else:
            d = first_diff(computed, stored)
            failures.append((split, r, 'targets', d,
                             dict(board=board, pot_size=pot_size,
                                  pot_feature_hex=pot_feature.tobytes().hex(),
                                  p1=ranges[0].tolist(), p2=ranges[1].tolist())))
            print(f'FIRST DIVERGENCE frozen: {split} row {r}')
            print(' detail:', failures[-1])
            break
    else:
        continue
    break

print(f'rows: {rows_exact}/{rows_total} bit-exact; values compared: {values_compared}')
for f in failures[:3]:
    print('FAIL:', f)
print('RESULT:', 'TRAINSAMPLES INVERSION 200/200 BIT-EXACT PASS'
      if rows_exact == rows_total == 200 and not failures else 'FAIL')
