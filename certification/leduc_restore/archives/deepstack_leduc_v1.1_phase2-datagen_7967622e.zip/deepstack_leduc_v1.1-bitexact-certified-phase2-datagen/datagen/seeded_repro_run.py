#!/usr/bin/env python3
"""Seeded reproducibility run: generate a full 100+100 dataset with an
explicit THRandom seed and print SHA-256 of all six files. Run twice in
independent processes; hashes must be identical.
Usage: python3 datagen/seeded_repro_run.py <seed> <outdir>"""
import hashlib
import sys
from pathlib import Path

from datagen.generator import generate_data
from datagen.th_random import THRandom
from deepstack_leduc.config import Config
from deepstack_leduc.torch7_blas import BIT_EXACT_BACKEND
from deepstack_leduc.value_model import load_original_value_net

assert BIT_EXACT_BACKEND, 'bit-exact BLAS backend required'

seed = int(sys.argv[1])
out = Path(sys.argv[2])
rng = THRandom(seed)
net = load_original_value_net()
generate_data(100, 100, out, rng, net, Config())
for name in ('valid.inputs', 'valid.targets', 'valid.mask',
             'train.inputs', 'train.targets', 'train.mask'):
    digest = hashlib.sha256((out / name).read_bytes()).hexdigest()
    print(f'{name:14s} {digest}')
