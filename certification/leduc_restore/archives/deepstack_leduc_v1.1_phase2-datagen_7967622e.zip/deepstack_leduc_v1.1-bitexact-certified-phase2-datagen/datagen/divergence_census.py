#!/usr/bin/env python3
"""Census of target divergences across all 200 bundled rows (frozen-analysis
tool for divergence D2). For every row: recompute targets through the Golden
Baseline path and record max ULP distance, #diverging entries, pot, tree
depth class and range extremes. No fixes — measurement only."""
import numpy as np

from datagen.generator import BucketConversionF32, resolve_targets
from deepstack_leduc.config import Config
from deepstack_leduc.torch7_tensor import load_float_tensor
from deepstack_leduc.value_model import load_original_value_net

cfg = Config()
net = load_original_value_net()
ROOT = 'reference_lua/Data/TrainSamples/PotBet'

rows = []
for split in ('train', 'valid'):
    inputs = load_float_tensor(f'{ROOT}/{split}.inputs')
    targets = load_float_tensor(f'{ROOT}/{split}.targets')
    mask = load_float_tensor(f'{ROOT}/{split}.mask')
    for r in range(inputs.shape[0]):
        board = [b for b in range(6) if mask[r].reshape(6, 6)[b].sum() == 5][0]
        conv = BucketConversionF32()
        conv.set_board(board)
        ranges = np.zeros((2, 6), dtype=np.float32)
        for p in range(2):
            blk = inputs[r, p * 36:(p + 1) * 36]
            for c in range(6):
                if c != board:
                    ranges[p, c] = blk[board * 6 + c]
        pot = float(inputs[r, -1]) * 1200.0
        rv = resolve_targets(board, pot, ranges[0], ranges[1], net, cfg)
        comp = conv.card_range_to_bucket_range(rv).reshape(-1)
        stored = targets[r]
        neq = int(np.sum(comp != stored))
        if neq:
            ci = comp.view(np.int32).astype(np.int64)
            si = stored.view(np.int32).astype(np.int64)
            ulp = int(np.max(np.abs(ci - si)[comp != stored]))
            maxabs = float(np.max(np.abs(comp - stored)))
        else:
            ulp = 0
            maxabs = 0.0
        minr = float(min(ranges[0][ranges[0] > 0].min(), ranges[1][ranges[1] > 0].min()))
        rows.append((split, r, board, pot, neq, ulp, maxabs, minr))
        if neq:
            print(f'{split} {r:3d} board={board} pot={pot:9.3f} neq={neq:2d} '
                  f'maxULP={ulp:4d} maxabs={maxabs:.2e} minrange={minr:.2e}')

exact = sum(1 for x in rows if x[4] == 0)
print(f'\nEXACT {exact}/200; diverging rows: {200 - exact}')
div = [x for x in rows if x[4]]
if div:
    print('pot range of diverging rows:', min(x[3] for x in div), '-', max(x[3] for x in div))
    print('max ULP overall:', max(x[5] for x in div))
    import collections
    print('by board:', collections.Counter(x[2] for x in div))
