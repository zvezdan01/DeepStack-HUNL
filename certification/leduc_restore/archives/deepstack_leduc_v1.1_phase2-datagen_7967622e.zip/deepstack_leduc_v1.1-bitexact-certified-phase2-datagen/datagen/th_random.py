"""THRandom-exact RNG for the Phase-2 data generator.

Bit-exact reimplementation of torch7's TH random layer
(torch/torch7 @ 814ea4a, lib/TH/THRandom.c + TensorMath.lua bindings),
certified against the untouched original C compiled in
datagen/thrandom_oracle/ (see datagen/tests + DS_PHASE2A docs):

- seeding: THRandom_manualSeed = MT19937 init_genrand (THRandom.c:140-163)
- THRandom_random: MT19937 u32 with standard tempering (THRandom.c:186-201)
- torch.rand on the default FloatTensor: per element
  (float)THRandom_uniform(gen, 0, 1) = (float)(u32 * 2^-32)
  (THTensorRandom.c:58-61, THRandom.c:203-220)
- torch.random(a, b): (u32 % (b+1-a)) + a  (TensorMath.lua:770-773)

This module is new Phase-2 code; it does not touch the Golden Baseline.
"""
from __future__ import annotations

import numpy as np

_N, _M = 624, 397
_MATRIX_A = 0x9908B0DF
_UPPER = 0x80000000
_LOWER = 0x7FFFFFFF


class THRandom:
    def __init__(self, seed: int) -> None:
        self.manual_seed(seed)

    def manual_seed(self, seed: int) -> None:
        self.the_initial_seed = seed
        mt = [0] * _N
        mt[0] = seed & 0xFFFFFFFF
        for j in range(1, _N):
            mt[j] = (1812433253 * (mt[j - 1] ^ (mt[j - 1] >> 30)) + j) & 0xFFFFFFFF
        self._mt = mt
        self._mti = _N

    def _next_state(self) -> None:
        mt = self._mt
        for i in range(_N):
            y = (mt[i] & _UPPER) | (mt[(i + 1) % _N] & _LOWER)
            mt[i] = mt[(i + _M) % _N] ^ (y >> 1)
            if y & 1:
                mt[i] ^= _MATRIX_A
        self._mti = 0

    def random_u32(self) -> int:
        """THRandom_random (THRandom.c:186-201)."""
        if self._mti >= _N:
            self._next_state()
        y = self._mt[self._mti]
        self._mti += 1
        y ^= y >> 11
        y ^= (y << 7) & 0x9D2C5680
        y ^= (y << 15) & 0xEFC60000
        y ^= y >> 18
        return y & 0xFFFFFFFF

    def uniform(self) -> float:
        """__uniform__ = u32 * 2^-32, double (THRandom.c:203-207)."""
        return self.random_u32() * (1.0 / 4294967296.0)

    def rand_float(self, count: int) -> np.ndarray:
        """torch.rand(count) with default FloatTensor: f32 stores of the
        double uniforms, element order = TH_TENSOR_APPLY (ascending)."""
        out = np.empty(count, dtype=np.float32)
        for i in range(count):
            out[i] = np.float32(self.uniform())
        return out

    def random_range(self, a: int, b: int) -> int:
        """torch.random(a, b) = u32 % (b+1-a) + a (TensorMath.lua:770-773)."""
        return (self.random_u32() % (b + 1 - a)) + a
