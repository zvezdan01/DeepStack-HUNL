"""Torch7 FloatTensor serializer for the Phase-2 data generator.

Mirrors byte-for-byte the standalone `torch.save(path, tensor:float())`
layout consumed by `deepstack_leduc/torch7_tensor.py:load_float_tensor`
(the exact serialization of the bundled TrainSamples): 4=TYPE_TORCH tag,
object index, "V 1", class name, sizes/strides int64, one-based storage
offset, embedded FloatStorage. Certified by byte round-trip over the six
bundled author files (datagen/verify_t7_roundtrip.py)."""
from __future__ import annotations

import struct
from pathlib import Path

import numpy as np


def _w_i32(f, v: int) -> None:
    f.write(struct.pack('<i', v))


def _w_i64(f, v: int) -> None:
    f.write(struct.pack('<q', v))


def _w_string(f, s: str) -> None:
    data = s.encode('utf-8')
    _w_i32(f, len(data))
    f.write(data)


def save_float_tensor(path: str | Path, array: np.ndarray) -> None:
    array = np.ascontiguousarray(array, dtype=np.float32)
    sizes = array.shape
    # torch7 contiguous strides (elements), innermost = 1
    strides = []
    acc = 1
    for dim in reversed(sizes):
        strides.insert(0, acc)
        acc *= dim
    with Path(path).open('wb') as f:
        _w_i32(f, 4)          # TYPE_TORCH
        _w_i32(f, 1)          # object index
        _w_string(f, 'V 1')
        _w_string(f, 'torch.FloatTensor')
        _w_i32(f, len(sizes))
        for s in sizes:
            _w_i64(f, s)
        for s in strides:
            _w_i64(f, s)
        _w_i64(f, 1)          # storage offset, one-based
        _w_i32(f, 4)          # TYPE_TORCH (storage)
        _w_i32(f, 2)          # object index
        _w_string(f, 'V 1')
        _w_string(f, 'torch.FloatStorage')
        _w_i64(f, array.size)
        f.write(array.tobytes())
