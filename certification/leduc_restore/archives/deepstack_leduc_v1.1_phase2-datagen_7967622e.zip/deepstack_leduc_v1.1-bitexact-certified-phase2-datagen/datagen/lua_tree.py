"""Lua-faithful f32 tree construction for fractional (data-generation) pots.

DIVERGENCE D1 (frozen + explained before this remedy, see
DS_PHASE2A_CERTIFICATION.md): the Golden Baseline `deepstack_leduc/tree.py`
keeps `Node.bets` in float64 across tree levels, while the original Lua
stores every node's bets in a FloatTensor (`tree_builder.lua` node state,
`bet_sizing.lua:44-64` Tensor rows), so children derive from f32-truncated
parent bets. For integer chip counts (the entire certified trace corpus)
both are exact and identical; for the fractional pots drawn by data
generation (e.g. valid row 1, pot 106.26386404037476) the raise chains
differ in the last bits (first observed target divergence 4.292e-6).

This subclass reproduces the Lua semantics by casting each node's bets to
float32 at `_build` entry — i.e. exactly one f32 rounding point per node
before any child derives from it, matching `arguments.Tensor{}` storage.
The Golden Baseline itself is untouched (dependency injection only);
adopting this cast upstream is a candidate v1.1 fidelity patch that would
require full re-certification.
"""
from __future__ import annotations

import numpy as np

from deepstack_leduc.tree import PokerTreeBuilder


class LuaF32TreeBuilder(PokerTreeBuilder):
    def _build(self, node) -> None:
        node.bets = np.asarray(node.bets, dtype=np.float32)
        super()._build(node)
