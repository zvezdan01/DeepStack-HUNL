/* Minimal stubs for compiling the ORIGINAL torch7 THRandom.c standalone
 * (torch/torch7 @ 814ea4a, lib/TH/THRandom.c untouched).
 * Only allocation/error helpers are stubbed; RNG code is the author's. */
#ifndef TH_GENERAL_INC
#define TH_GENERAL_INC
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#define TH_API
#define TH_EXPORTS
static inline void *THAlloc(long size) { return malloc(size); }
static inline void THFree(void *p) { free(p); }
#define THError(...) do { fprintf(stderr, __VA_ARGS__); exit(1); } while (0)
#define THArgCheck(cond, idx, msg) do { if (!(cond)) { fprintf(stderr, "%s\n", msg); exit(1); } } while (0)
#endif
