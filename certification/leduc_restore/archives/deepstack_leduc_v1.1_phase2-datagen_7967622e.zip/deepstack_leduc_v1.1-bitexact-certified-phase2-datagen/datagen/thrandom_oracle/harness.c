/* Oracle harness: dumps raw THRandom streams for a given seed.
 * Modes: u32 (THRandom_random), rand (float32 of __uniform__ via
 * THRandom_uniform(0,1) cast to float, i.e. torch.rand on FloatTensor),
 * randint A B (TensorMath.lua THRandom_random2__: u32 % (b+1-a) + a). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "THRandom.h"

int main(int argc, char **argv) {
  if (argc < 5) { fprintf(stderr, "usage: %s <seed> <count> <mode> <out> [a b]\n", argv[0]); return 1; }
  unsigned long seed = strtoul(argv[1], NULL, 10);
  long count = strtol(argv[2], NULL, 10);
  const char *mode = argv[3];
  FILE *f = fopen(argv[4], "wb");
  THGenerator *gen = THGenerator_new();
  THRandom_manualSeed(gen, seed);
  for (long i = 0; i < count; ++i) {
    if (!strcmp(mode, "u32")) {
      uint32_t v = (uint32_t)THRandom_random(gen);
      fwrite(&v, 4, 1, f);
    } else if (!strcmp(mode, "rand")) {
      float v = (float)THRandom_uniform(gen, 0, 1);
      fwrite(&v, 4, 1, f);
    } else if (!strcmp(mode, "randint")) {
      long a = strtol(argv[5], NULL, 10), b = strtol(argv[6], NULL, 10);
      int64_t v = (int64_t)((THRandom_random(gen) % (unsigned long)(b + 1 - a)) + a);
      fwrite(&v, 8, 1, f);
    } else { fprintf(stderr, "bad mode\n"); return 1; }
  }
  fclose(f);
  return 0;
}
