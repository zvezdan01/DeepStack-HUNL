#!/usr/bin/env python3
"""Sampler-only distribution sanity + RNG call accounting (no resolves).
Checks: board uniformity (chi-square-ish bound), pot uniformity over
[100, 1199.9), range validity (board card zero, sums ~1, simplex spread),
and exact RNG draw accounting per batch.
Run from the DS repo root with PYTHONPATH=."""
import numpy as np

from datagen.generator import RangeGenerator, generate_board
from datagen.th_random import THRandom

rng = THRandom(777)
BATCHES = 3000
boards = []
pots = []
range_sums = []
range_zero_ok = True
draws = 0


class CountingRNG(THRandom):
    def random_u32(self):
        global draws
        draws += 1
        return super().random_u32()


rng = CountingRNG(777)
gen = RangeGenerator()
for _ in range(BATCHES):
    before = draws
    board = generate_board(rng)[0]
    board_draws = draws - before
    assert board_draws == 1, 'board must consume exactly 1 draw'
    boards.append(board)
    gen.set_board(board)
    r = np.zeros((2, 10, 6), dtype=np.float32)
    before = draws
    for p in range(2):
        gen.generate_range(r[p], rng)
    range_draws = draws - before
    # per player (J=5, batch 10): node5: rand(10)+odd(1); its halves
    # {2,3}: node2: rand(10); node3: rand(10)+odd(1) -> its half node2:
    # rand(10). Total per player = 11+10+11+10 = 42 u32; two players = 84.
    assert range_draws == 84, f'range draws {range_draws}'
    before = draws
    pot = (rng.rand_float(10) * np.float32(1099.9)).astype(np.float32) + np.float32(100.0)
    assert draws - before == 10
    pots.extend(pot.tolist())
    if not (r[:, :, board] == 0).all():
        range_zero_ok = False
    range_sums.extend(r.sum(axis=2).ravel().tolist())

boards = np.array(boards)
pots = np.array(pots)
sums = np.array(range_sums)
counts = np.bincount(boards, minlength=6)
expected = BATCHES / 6
chi2 = float(((counts - expected) ** 2 / expected).sum())
print('board counts:', counts.tolist(), f'chi2={chi2:.2f} (df=5, crit@0.001=20.5)')
print(f'pot: min={pots.min():.3f} max={pots.max():.3f} mean={pots.mean():.2f} '
      f'(expected ~649.95); uniform KS-ish max dev='
      f'{float(np.max(np.abs(np.sort(pots) - (100 + 1099.9*(np.arange(len(pots))+0.5)/len(pots))))):.2f}')
print(f'range sums: min={sums.min():.7f} max={sums.max():.7f} (f32 stick-breaking ~1)')
print('board-card zero in all ranges:', range_zero_ok)
print('RNG accounting: 1 board + 84 range + 10 pot draws per batch — verified for all batches')
ok = chi2 < 20.5 and abs(pots.mean() - 649.95) < 5 and range_zero_ok \
    and 0.999 < sums.min() and sums.max() < 1.001
print('DISTRIBUTION SANITY:', 'PASS' if ok else 'FAIL')
