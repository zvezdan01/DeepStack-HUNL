from __future__ import annotations

import io
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np


class Torch7ModelError(ValueError):
    pass


@dataclass
class Torch7Table:
    items: list[tuple[Any, Any]]

    def get(self, key: Any, default: Any = None) -> Any:
        for k, v in self.items:
            if k == key:
                return v
        return default

    def sequence(self) -> list[Any]:
        numeric: list[tuple[int, Any]] = []
        for k, v in self.items:
            if isinstance(k, (int, float)) and float(k).is_integer():
                numeric.append((int(k), v))
        numeric.sort(key=lambda x: x[0])
        return [v for _, v in numeric]


@dataclass
class Torch7Object:
    class_name: str
    version: str | None
    data: Any = None


class Torch7Reader:
    """Small Torch7 binary reader for the object types used by DeepStack.

    It supports tables, Torch objects, CPU float tensors/storages, numbers,
    strings and booleans. Unknown nn classes are retained as object wrappers
    whose payload is the serialized attribute table.
    """

    TYPE_NIL = 0
    TYPE_NUMBER = 1
    TYPE_STRING = 2
    TYPE_TABLE = 3
    TYPE_TORCH = 4
    TYPE_BOOLEAN = 5
    TYPE_FUNCTION = 6
    TYPE_RECUR_FUNCTION = 8
    LEGACY_RECUR_FUNCTION = 7

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._f: io.BufferedReader | None = None
        self._objects: dict[int, Any] = {}

    def _read(self, n: int) -> bytes:
        assert self._f is not None
        data = self._f.read(n)
        if len(data) != n:
            raise Torch7ModelError("unexpected end of Torch7 file")
        return data

    def _i32(self) -> int:
        return struct.unpack("<i", self._read(4))[0]

    def _i64(self) -> int:
        return struct.unpack("<q", self._read(8))[0]

    def _f64(self) -> float:
        return struct.unpack("<d", self._read(8))[0]

    def _string(self) -> str:
        n = self._i32()
        if n < 0 or n > 20_000_000:
            raise Torch7ModelError(f"invalid Torch7 string length {n}")
        return self._read(n).decode("utf-8", errors="strict")

    def load(self) -> Any:
        with self.path.open("rb") as f:
            self._f = f
            self._objects = {}
            result = self._object()
            trailing = f.read(1)
            if trailing:
                raise Torch7ModelError("trailing bytes after Torch7 root object")
            return result

    def _object(self) -> Any:
        type_tag = self._i32()
        if type_tag == self.TYPE_NIL:
            return None
        if type_tag == self.TYPE_NUMBER:
            return self._f64()
        if type_tag == self.TYPE_STRING:
            return self._string()
        if type_tag == self.TYPE_BOOLEAN:
            return bool(self._i32())
        if type_tag == self.TYPE_TABLE:
            return self._table()
        if type_tag == self.TYPE_TORCH:
            return self._torch_object()
        if type_tag in (self.TYPE_FUNCTION, self.TYPE_RECUR_FUNCTION, self.LEGACY_RECUR_FUNCTION):
            return self._function(type_tag)
        raise Torch7ModelError(f"unsupported Torch7 type tag {type_tag}")

    def _table(self) -> Torch7Table:
        object_index = self._i32()
        if object_index in self._objects:
            obj = self._objects[object_index]
            if not isinstance(obj, Torch7Table):
                raise Torch7ModelError("Torch7 object index type mismatch")
            return obj
        table = Torch7Table([])
        self._objects[object_index] = table
        n = self._i32()
        if n < 0 or n > 10_000_000:
            raise Torch7ModelError(f"invalid Torch7 table length {n}")
        for _ in range(n):
            table.items.append((self._object(), self._object()))
        return table

    def _torch_object(self) -> Torch7Object:
        object_index = self._i32()
        if object_index in self._objects:
            obj = self._objects[object_index]
            if not isinstance(obj, Torch7Object):
                raise Torch7ModelError("Torch7 object index type mismatch")
            return obj

        first = self._string()
        if first.startswith("V "):
            version = first
            class_name = self._string()
        else:
            version = None
            class_name = first
        obj = Torch7Object(class_name, version)
        self._objects[object_index] = obj

        if class_name == "torch.FloatStorage":
            size = self._i64()
            obj.data = np.frombuffer(self._read(size * 4), dtype="<f4").copy()
            return obj
        if class_name == "torch.FloatTensor":
            obj.data = self._float_tensor()
            return obj
        if class_name in ("torch.CudaStorage", "torch.CudaTensor"):
            raise Torch7ModelError("load the CPU checkpoint, not the CUDA checkpoint")

        obj.data = self._object()
        return obj

    def _float_tensor(self) -> np.ndarray:
        ndim = self._i32()
        if ndim < 0 or ndim > 16:
            raise Torch7ModelError(f"invalid tensor rank {ndim}")
        shape = tuple(self._i64() for _ in range(ndim))
        stride = tuple(self._i64() for _ in range(ndim))
        storage_offset = self._i64() - 1
        storage = self._object()
        if storage is None:
            return np.empty(shape, dtype=np.float32)
        if not isinstance(storage, Torch7Object) or storage.class_name != "torch.FloatStorage":
            raise Torch7ModelError("FloatTensor does not reference FloatStorage")
        values = storage.data
        if not isinstance(values, np.ndarray):
            raise Torch7ModelError("invalid FloatStorage payload")
        if ndim == 0:
            return values[storage_offset : storage_offset + 1].reshape(()).copy()
        if storage_offset < 0:
            raise Torch7ModelError("invalid tensor storage offset")
        max_index = storage_offset + sum((n - 1) * st for n, st in zip(shape, stride))
        if max_index >= values.size:
            raise Torch7ModelError("tensor view exceeds storage")
        return np.lib.stride_tricks.as_strided(
            values[storage_offset:],
            shape=shape,
            strides=tuple(st * values.itemsize for st in stride),
        ).copy()

    def _function(self, type_tag: int) -> Any:
        object_index = None
        if type_tag in (self.TYPE_RECUR_FUNCTION, self.LEGACY_RECUR_FUNCTION):
            object_index = self._i32()
        size = self._i32()
        bytecode = self._read(size)
        upvalues = self._object()
        value = ("function", bytecode, upvalues)
        if object_index is not None:
            self._objects[object_index] = value
        return value


def load_torch7_object(path: str | Path) -> Any:
    return Torch7Reader(path).load()


def table_get(obj: Torch7Object | Torch7Table, key: Any, default: Any = None) -> Any:
    table = obj.data if isinstance(obj, Torch7Object) else obj
    if not isinstance(table, Torch7Table):
        return default
    return table.get(key, default)


def module_children(module: Torch7Object) -> list[Torch7Object]:
    modules = table_get(module, "modules")
    if not isinstance(modules, Torch7Table):
        return []
    return [x for x in modules.sequence() if isinstance(x, Torch7Object)]
