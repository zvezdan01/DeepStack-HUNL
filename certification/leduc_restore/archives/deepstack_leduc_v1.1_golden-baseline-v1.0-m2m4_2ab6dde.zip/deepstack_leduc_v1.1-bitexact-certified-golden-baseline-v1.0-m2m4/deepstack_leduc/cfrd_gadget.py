from __future__ import annotations

import numpy as np

from .card_tools import possible_hand_indexes
from .config import Config


class CFRDGadget:
    """Line-for-line numerical port of Source/Lookahead/cfrd_gadget.lua.

    The ``iteration`` argument is accepted because it is part of the reference
    API, although the original implementation does not use it.
    """

    def __init__(
        self,
        board: tuple[int, ...],
        player_range: np.ndarray,
        opponent_cfvs: np.ndarray,
        config: Config = Config(),
    ) -> None:
        self.config = config
        self.input_opponent_range = np.asarray(player_range, dtype=np.float32).copy()
        self.input_opponent_value = np.asarray(opponent_cfvs, dtype=np.float32).copy()
        shape = (config.card_count,)
        if self.input_opponent_range.shape != shape or self.input_opponent_value.shape != shape:
            raise ValueError(f"Expected vectors of shape {shape}")

        self.regret_epsilon = 1.0 / 100_000_000.0
        self.play_current_strategy = np.zeros(shape, dtype=np.float32)
        self.terminate_current_strategy = np.ones(shape, dtype=np.float32)
        self.total_values = np.zeros(shape, dtype=np.float32)
        self.terminate_regrets = np.zeros(shape, dtype=np.float32)
        self.play_regrets = np.zeros(shape, dtype=np.float32)
        self.range_mask = possible_hand_indexes(board, config).astype(np.float32, copy=False)

    def compute_opponent_range(
        self, current_opponent_cfvs: np.ndarray, iteration: int
    ) -> np.ndarray:
        del iteration
        play_values = np.asarray(current_opponent_cfvs, dtype=np.float32)
        if play_values.shape != (self.config.card_count,):
            raise ValueError("current_opponent_cfvs has wrong shape")
        terminate_values = self.input_opponent_value

        self.total_values = (
            play_values * self.play_current_strategy
            + terminate_values * self.terminate_current_strategy
        )
        self.play_regrets += play_values - self.total_values
        self.terminate_regrets += terminate_values - self.total_values

        # Lua: regrets:clamp(regret_epsilon, tools:max_number()) with
        # tools.lua:29-31 max_number() = 999999  (cfrd_gadget.lua:76-77)
        np.clip(self.play_regrets, self.regret_epsilon, 999999.0, out=self.play_regrets)
        np.clip(self.terminate_regrets, self.regret_epsilon, 999999.0, out=self.terminate_regrets)

        regret_sum = self.play_regrets + self.terminate_regrets
        self.play_current_strategy = self.play_regrets / regret_sum
        self.terminate_current_strategy = self.terminate_regrets / regret_sum

        self.play_current_strategy *= self.range_mask
        self.terminate_current_strategy *= self.range_mask
        self.input_opponent_range = self.play_current_strategy.copy()
        return self.input_opponent_range
