from __future__ import annotations
import argparse,json,time
import numpy as np
from .config import Config
from .tree import PokerTreeBuilder
from .cards import uniform_range
from .cfr import TreeCFR
from .agent import DeepStackLeducAgent
from .acpc import ACPCClient

def main():
    p=argparse.ArgumentParser(prog='deepstack-leduc')
    sub=p.add_subparsers(dest='cmd',required=True)
    s=sub.add_parser('solve');s.add_argument('--iters',type=int,default=1000);s.add_argument('--skip',type=int,default=500)
    a=sub.add_parser('play');a.add_argument('host');a.add_argument('port',type=int);a.add_argument('--iters',type=int,default=1000);a.add_argument('--seed',type=int,default=0)
    t=sub.add_parser('tree')
    ns=p.parse_args()
    if ns.cmd=='tree':
        r=PokerTreeBuilder().build_tree();print(json.dumps({'nodes':PokerTreeBuilder.count_nodes(r),'depth':r.depth}))
    elif ns.cmd=='solve':
        cfg=Config(cfr_iters=ns.iters,cfr_skip_iters=min(ns.skip,ns.iters-1));r=PokerTreeBuilder(cfg).build_tree();rr=np.stack([uniform_range(()),uniform_range(())]);st=time.time();TreeCFR(cfg).run(r,rr);print(json.dumps({'nodes':PokerTreeBuilder.count_nodes(r),'depth':r.depth,'seconds':time.time()-st,'root_cfv':r.cf_values.tolist()}))
    else:
        cfg=Config(cfr_iters=ns.iters,cfr_skip_iters=max(0,ns.iters//2));agent=DeepStackLeducAgent(cfg, seed=ns.seed);ACPCClient(ns.host,ns.port).play(agent)
if __name__=='__main__':main()
