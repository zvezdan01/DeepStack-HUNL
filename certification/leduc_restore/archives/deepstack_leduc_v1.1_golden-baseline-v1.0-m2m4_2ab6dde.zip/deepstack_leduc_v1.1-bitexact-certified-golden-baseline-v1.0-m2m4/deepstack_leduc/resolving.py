from __future__ import annotations

import numpy as np

from .config import Config
from .lookahead import Lookahead, LookaheadResults
from .tree import Node, PokerTreeBuilder


class Resolving:
    """Port of ``Source/Lookahead/resolving.lua``."""

    def __init__(self, cfg: Config = Config(), value_network=None) -> None:
        self.cfg = cfg
        self.value_network = value_network
        self.tree_builder = PokerTreeBuilder(cfg)
        self.lookahead_tree: Node | None = None
        self.lookahead: Lookahead | None = None
        self.resolve_results: LookaheadResults | None = None

    def _create_lookahead_tree(self, node: Node) -> None:
        root = Node(
            street=node.street,
            current_player=node.current_player,
            bets=node.bets.copy(),
            board=tuple(node.board),
        )
        self.lookahead_tree = self.tree_builder.build_tree(root, limit_to_street=True)

    def resolve_first_node(
        self, node: Node, player_range: np.ndarray, opponent_range: np.ndarray
    ) -> LookaheadResults:
        self._create_lookahead_tree(node)
        assert self.lookahead_tree is not None
        self.lookahead = Lookahead(self.cfg, self.value_network)
        self.lookahead.build_lookahead(self.lookahead_tree)
        self.lookahead.resolve_first_node(player_range, opponent_range)
        self.resolve_results = self.lookahead.get_results()
        return self.resolve_results

    def resolve(
        self, node: Node, player_range: np.ndarray, opponent_cfvs: np.ndarray
    ) -> LookaheadResults:
        self._create_lookahead_tree(node)
        assert self.lookahead_tree is not None
        self.lookahead = Lookahead(self.cfg, self.value_network)
        self.lookahead.build_lookahead(self.lookahead_tree)
        self.lookahead.resolve(player_range, opponent_cfvs)
        self.resolve_results = self.lookahead.get_results()
        return self.resolve_results

    def get_possible_actions(self) -> list[int]:
        self._require()
        assert self.lookahead_tree is not None
        return list(self.lookahead_tree.actions)

    def _action_to_action_id(self, action: int) -> int:
        actions = self.get_possible_actions()
        try:
            return actions.index(action)
        except ValueError as exc:
            raise ValueError(f"illegal action {action}; legal actions: {actions}") from exc

    def get_root_cfv(self) -> np.ndarray:
        self._require()
        assert self.resolve_results is not None and self.resolve_results.root_cfvs is not None
        return self.resolve_results.root_cfvs.copy()

    def get_root_cfv_both_players(self) -> np.ndarray:
        self._require()
        assert self.resolve_results is not None and self.resolve_results.root_cfvs_both_players is not None
        return self.resolve_results.root_cfvs_both_players.copy()

    def get_action_cfv(self, action: int) -> np.ndarray:
        self._require()
        assert self.resolve_results is not None
        return self.resolve_results.children_cfvs[self._action_to_action_id(action)].copy()

    def get_chance_action_cfv(self, action: int, board: tuple[int, ...]) -> np.ndarray:
        self._require()
        assert self.lookahead is not None
        return self.lookahead.get_chance_action_cfv(self._action_to_action_id(action), board)

    def get_action_strategy(self, action: int) -> np.ndarray:
        self._require()
        assert self.resolve_results is not None
        return self.resolve_results.strategy[self._action_to_action_id(action)].copy()

    def _require(self) -> None:
        if self.resolve_results is None:
            raise RuntimeError("resolve() or resolve_first_node() must be called first")
