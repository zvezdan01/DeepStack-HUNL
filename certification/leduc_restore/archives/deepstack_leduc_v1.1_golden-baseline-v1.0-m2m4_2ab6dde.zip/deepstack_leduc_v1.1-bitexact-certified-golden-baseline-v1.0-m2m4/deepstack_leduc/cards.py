from __future__ import annotations
import numpy as np

RANKS = ("A", "K", "Q")
SUITS = ("s", "h")
CARD_STRINGS = tuple(r+s for r in RANKS for s in SUITS)
STR_TO_CARD = {s:i for i,s in enumerate(CARD_STRINGS)}

def card_to_rank(card: int) -> int:
    return card // 2

def card_to_string(card: int) -> str:
    return CARD_STRINGS[card]

def string_to_card(text: str) -> int:
    return STR_TO_CARD[text]

def string_to_board(text: str) -> tuple[int, ...]:
    text = text.strip()
    if not text:
        return ()
    if len(text) % 2:
        raise ValueError(f"Invalid board string: {text!r}")
    return tuple(string_to_card(text[i:i+2]) for i in range(0, len(text), 2))

def possible_mask(board: tuple[int, ...]) -> np.ndarray:
    out = np.ones(6, dtype=np.float64)
    for c in board:
        out[c] = 0.0
    return out

def uniform_range(board: tuple[int, ...]) -> np.ndarray:
    out = possible_mask(board)
    return out / out.sum()

def normalize_range(board: tuple[int, ...], values: np.ndarray) -> np.ndarray:
    out = np.asarray(values, dtype=np.float64).copy() * possible_mask(board)
    s = out.sum()
    return out if s <= 0 else out / s

def hand_strength(private_card: int, board: tuple[int, ...]) -> int:
    """Port of Source/Game/Evaluation/evaluator.lua.

    The Lua evaluator uses one-based rank indices (A=1, K=2, Q=3).  Using
    zero-based indices in its arithmetic creates collisions between pairs and
    high-card hands, so the conversion to one-based ranks is intentional.
    Lower values mean stronger hands.
    """
    if private_card in board:
        return -1
    ranks = sorted([card_to_rank(private_card) + 1, *(card_to_rank(c) + 1 for c in board)])
    if not board:
        return ranks[0]
    if len(ranks) == 2:
        return ranks[0] if ranks[0] == ranks[1] else ranks[0] * 3 + ranks[1]
    if ranks[0] == ranks[1]:
        return ranks[0] * 3 + ranks[2]
    if ranks[1] == ranks[2]:
        return ranks[1] * 3 + ranks[0]
    return ranks[0] * 9 + ranks[1] * 3 + ranks[2]
