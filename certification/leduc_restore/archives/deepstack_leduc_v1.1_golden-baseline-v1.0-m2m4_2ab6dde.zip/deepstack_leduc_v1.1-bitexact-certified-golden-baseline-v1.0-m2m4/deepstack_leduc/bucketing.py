from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .card_tools import board_index, boards_count
from .config import Config


@dataclass(frozen=True)
class Bucketer:
    config: Config = field(default_factory=Config)

    def get_bucket_count(self) -> int:
        return self.config.card_count * boards_count(self.config)

    def compute_buckets(self, board: tuple[int, ...]) -> np.ndarray:
        """Map private cards to zero-based bucket ids; impossible cards map to -1."""
        shift = board_index(board, self.config) * self.config.card_count
        buckets = np.arange(self.config.card_count, dtype=np.int64) + shift
        for card in board:
            buckets[card] = -1
        return buckets


class BucketConversion:
    def __init__(self, config: Config = Config()) -> None:
        self.config = config
        self.bucketer = Bucketer(config)
        self.bucket_count = self.bucketer.get_bucket_count()
        self._range_matrix: np.ndarray | None = None
        self._reverse_value_matrix: np.ndarray | None = None

    def set_board(self, board: tuple[int, ...]) -> None:
        buckets = self.bucketer.compute_buckets(board)
        matrix = np.zeros((self.config.card_count, self.bucket_count), dtype=np.float64)
        for card, bucket in enumerate(buckets):
            if bucket >= 0:
                matrix[card, bucket] = 1.0
        self._range_matrix = matrix
        self._reverse_value_matrix = matrix.T.copy()

    def _require_board(self) -> tuple[np.ndarray, np.ndarray]:
        if self._range_matrix is None or self._reverse_value_matrix is None:
            raise RuntimeError("set_board() must be called first")
        return self._range_matrix, self._reverse_value_matrix

    def card_range_to_bucket_range(self, card_range: np.ndarray) -> np.ndarray:
        matrix, _ = self._require_board()
        arr = np.asarray(card_range, dtype=np.float64)
        if arr.shape[-1] != self.config.card_count:
            raise ValueError("Last dimension must equal card_count")
        return arr @ matrix

    def bucket_value_to_card_value(self, bucket_value: np.ndarray) -> np.ndarray:
        _, reverse = self._require_board()
        arr = np.asarray(bucket_value, dtype=np.float64)
        if arr.shape[-1] != self.bucket_count:
            raise ValueError("Last dimension must equal bucket_count")
        return arr @ reverse

    def get_possible_bucket_mask(self) -> np.ndarray:
        matrix, _ = self._require_board()
        return np.ones((1, self.config.card_count), dtype=np.float64) @ matrix
