from __future__ import annotations

from .acpc import MatchState
from .config import Config
from .continual_resolving import ContinualResolving
from .value_model import load_original_value_net


class DeepStackLeducAgent:
    """Online player wired to the ported continual-resolving path."""

    def __init__(self, cfg: Config = Config(), value_network=None, seed: int | None = None):
        self.cfg = cfg
        if value_network is None:
            value_network = load_original_value_net()
        self.value_network = value_network
        self.continual = ContinualResolving(cfg, value_network=value_network, seed=seed)
        self.last_hand_number: int | None = None
        self.last_street: int | None = None

    def act(self, state: MatchState) -> str | None:
        if state.private_card is None:
            return None
        if state.acting_player != state.position:
            return None
        new_hand = (
            self.last_hand_number is None
            or self.last_hand_number != state.hand_number
            or (self.last_street is not None and state.street < self.last_street)
        )
        if new_hand:
            self.continual.start_new_hand(state)
        action = self.continual.compute_action(state.to_node(), state)
        self.last_hand_number = state.hand_number
        self.last_street = state.street
        return action
