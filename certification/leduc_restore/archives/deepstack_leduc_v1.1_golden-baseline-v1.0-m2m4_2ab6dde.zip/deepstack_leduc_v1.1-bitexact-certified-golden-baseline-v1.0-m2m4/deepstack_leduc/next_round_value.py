from __future__ import annotations

from typing import Protocol

import numpy as np

from .bucketing import Bucketer
from .card_tools import board_index, second_round_boards
from .config import Config
from .torch7_blas import mm as torch7_mm


class ValueNetwork(Protocol):
    def get_value(self, inputs: np.ndarray, outputs: np.ndarray | None = None) -> np.ndarray: ...


class NextRoundValue:
    """Port of ``Source/Nn/next_round_value.lua``.

    The class batches all six possible second-round boards, converts card
    ranges to the original 36-bucket representation, calls a value network,
    rescales counterfactual values by opponent reach, and maps them back to
    private-card values.
    """

    def __init__(self, nn: ValueNetwork, cfg: Config = Config()) -> None:
        self.nn = nn
        self.cfg = cfg
        self.bucketer = Bucketer()
        self.bucket_count = self.bucketer.get_bucket_count()
        self.boards = second_round_boards(cfg)
        self.board_count = int(self.boards.shape[0])
        self._init_bucketing()
        self.iter = 0
        self._values_are_prepared = False

    def _init_bucketing(self) -> None:
        self._range_matrix = np.zeros(
            (self.cfg.card_count, self.board_count * self.bucket_count),
            dtype=np.float32,
        )
        view = self._range_matrix.reshape(
            self.cfg.card_count, self.board_count, self.bucket_count
        )
        for idx, board_arr in enumerate(self.boards):
            board = tuple(int(x) for x in board_arr)
            buckets = self.bucketer.compute_buckets(board)
            for card, bucket in enumerate(buckets):
                if bucket >= 0:
                    view[card, idx, int(bucket)] = 1.0
        self._range_matrix_board_view = view
        self._reverse_value_matrix = self._range_matrix.T.copy()
        self._reverse_value_matrix *= 1.0 / (self.board_count - 2)

    def card_range_to_bucket_range(self, card_range: np.ndarray) -> np.ndarray:
        card_range = np.asarray(card_range, dtype=np.float32)
        return torch7_mm(card_range, self._range_matrix)

    def bucket_value_to_card_value(self, bucket_value: np.ndarray) -> np.ndarray:
        bucket_value = np.asarray(bucket_value, dtype=np.float32)
        return torch7_mm(bucket_value, self._reverse_value_matrix)

    def bucket_value_to_card_value_on_board(
        self, board: tuple[int, ...], bucket_value: np.ndarray
    ) -> np.ndarray:
        idx = board_index(board, self.cfg)
        board_matrix = self._range_matrix_board_view[:, idx, :].T
        selected = np.asarray(bucket_value, dtype=np.float32)[:, :, idx, :]
        return torch7_mm(selected.reshape(-1, self.bucket_count), board_matrix)

    def start_computation(self, pot_sizes: np.ndarray) -> None:
        pot_sizes = np.asarray(pot_sizes, dtype=np.float32).reshape(-1, 1)
        if pot_sizes.size == 0:
            raise ValueError("pot_sizes must be non-empty")
        self.iter = 0
        self.pot_sizes = pot_sizes.copy()
        self.batch_size = int(pot_sizes.shape[0])
        self._values_are_prepared = False
        self.range_normalization_memory = None
        self.counterfactual_value_memory = None

    def get_value(self, ranges: np.ndarray, values: np.ndarray | None = None) -> np.ndarray:
        if not hasattr(self, "batch_size"):
            raise RuntimeError("start_computation() must be called first")
        ranges = np.asarray(ranges, dtype=np.float32)
        expected = (self.batch_size, 2, self.cfg.card_count)
        if ranges.shape != expected:
            raise ValueError(f"ranges must have shape {expected}, got {ranges.shape}")
        if values is None:
            values = np.zeros_like(ranges)
        elif values.shape != expected:
            raise ValueError(f"values must have shape {expected}")

        self.iter += 1
        if self.iter == 1:
            self.next_round_inputs = np.zeros(
                (self.batch_size, self.board_count, 2 * self.bucket_count + 1),
                dtype=np.float32,
            )
            self.next_round_values = np.zeros(
                (self.batch_size, self.board_count, 2, self.bucket_count),
                dtype=np.float32,
            )
            pot_feature = (self.pot_sizes / self.cfg.stack).reshape(self.batch_size, 1)
            self.next_round_inputs[:, :, -1] = np.broadcast_to(
                pot_feature, (self.batch_size, self.board_count)
            )

        use_memory = self.iter > self.cfg.cfr_skip_iters
        if use_memory and self.iter == self.cfg.cfr_skip_iters + 1:
            self.range_normalization_memory = np.zeros(
                (self.batch_size, 2, self.board_count), dtype=np.float32
            )
            self.counterfactual_value_memory = np.zeros(
                (self.batch_size, 2, self.board_count, self.bucket_count),
                dtype=np.float32,
            )

        extended = self.card_range_to_bucket_range(
            ranges.reshape(self.batch_size * 2, self.cfg.card_count)
        ).reshape(self.batch_size, 2, self.board_count, self.bucket_count)

        # Torch7 FloatTensor:sum(dim) uses accreal=double, then casts to float32.
        range_normalization = np.empty(
            extended.shape[:3], dtype=np.float32
        )
        for b in range(extended.shape[0]):
            for player in range(extended.shape[1]):
                for board in range(extended.shape[2]):
                    acc = 0.0
                    for bucket in range(extended.shape[3]):
                        acc += float(extended[b, player, board, bucket])
                    range_normalization[b, player, board] = np.float32(acc)
        # A player's CFV is weighted by the opponent's reach probability.
        value_normalization = range_normalization[:, ::-1, :].copy()
        if use_memory:
            assert self.range_normalization_memory is not None
            self.range_normalization_memory += value_normalization

        safe_norm = range_normalization.copy()
        safe_norm[safe_norm == 0] = 1.0
        normalized = extended / safe_norm[..., None]
        self.next_round_inputs[:, :, : self.bucket_count] = normalized[:, 0]
        self.next_round_inputs[:, :, self.bucket_count : 2 * self.bucket_count] = normalized[:, 1]

        serialized_inputs = self.next_round_inputs.reshape(
            self.batch_size * self.board_count, -1
        )
        serialized_outputs = self.nn.get_value(serialized_inputs)
        self.next_round_values[...] = serialized_outputs.reshape(
            self.batch_size, self.board_count, 2, self.bucket_count
        )

        # Lua normalization view is [batch, board, player, 1].
        self.next_round_values *= value_normalization.transpose(0, 2, 1)[..., None]
        transposed = self.next_round_values.transpose(0, 2, 1, 3)
        if use_memory:
            assert self.counterfactual_value_memory is not None
            self.counterfactual_value_memory += transposed

        card_values = self.bucket_value_to_card_value(
            transposed.reshape(self.batch_size * 2, -1)
        ).reshape(expected)
        values[...] = card_values
        return values

    def _prepare_next_round_values(self) -> None:
        if self.iter != self.cfg.cfr_iters:
            raise RuntimeError(
                f"expected exactly {self.cfg.cfr_iters} calls, got {self.iter}"
            )
        if self._values_are_prepared:
            return
        if self.range_normalization_memory is None or self.counterfactual_value_memory is None:
            raise RuntimeError("no post-skip values were accumulated")
        safe = self.range_normalization_memory.copy()
        safe[safe == 0] = 1.0
        self.counterfactual_value_memory /= safe[..., None]
        self._values_are_prepared = True

    def get_value_on_board(
        self, board: tuple[int, ...], values: np.ndarray | None = None
    ) -> np.ndarray:
        self._prepare_next_round_values()
        if values is None:
            values = np.zeros((self.batch_size, 2, self.cfg.card_count), dtype=np.float32)
        expected = (self.batch_size, 2, self.cfg.card_count)
        if values.shape != expected:
            raise ValueError(f"values must have shape {expected}")
        assert self.counterfactual_value_memory is not None
        flat = self.bucket_value_to_card_value_on_board(
            board, self.counterfactual_value_memory
        )
        values[...] = flat.reshape(expected)
        return values
