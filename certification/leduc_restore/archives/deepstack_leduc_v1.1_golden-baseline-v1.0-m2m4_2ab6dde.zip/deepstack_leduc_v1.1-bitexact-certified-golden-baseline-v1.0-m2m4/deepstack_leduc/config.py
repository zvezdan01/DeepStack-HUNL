from dataclasses import dataclass

@dataclass(frozen=True)
class Config:
    ante: int = 100
    stack: int = 1200
    bet_fractions: tuple[float, ...] = (1.0,)
    cfr_iters: int = 1000
    cfr_skip_iters: int = 500
    regret_epsilon: float = 1e-9
    card_count: int = 6
    board_card_count: int = 1
    rank_count: int = 3
    suit_count: int = 2
