from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .torch7_tensor import load_float_tensor


@dataclass
class DatasetSplit:
    inputs: np.ndarray
    targets: np.ndarray
    mask: np.ndarray


class DataStream:
    """Reference-compatible loader for DeepStack Torch7 datasets."""

    def __init__(self, directory: str | Path, batch_size: int = 100) -> None:
        directory = Path(directory)
        self.batch_size = int(batch_size)
        self.train = self._load_split(directory, "train")
        self.valid = self._load_split(directory, "valid")
        for split in (self.train, self.valid):
            if split.inputs.shape[0] < self.batch_size:
                raise ValueError("dataset must contain at least one full batch")
            if split.inputs.shape[0] % self.batch_size != 0:
                raise ValueError("reference DataStream requires exact full batches")

    @staticmethod
    def _load_split(directory: Path, prefix: str) -> DatasetSplit:
        inputs = load_float_tensor(directory / f"{prefix}.inputs")
        targets = load_float_tensor(directory / f"{prefix}.targets")
        mask36 = load_float_tensor(directory / f"{prefix}.mask")
        mask = np.tile(mask36, (1, 2))
        if inputs.shape[0] != targets.shape[0] or inputs.shape[0] != mask.shape[0]:
            raise ValueError("split row counts do not match")
        return DatasetSplit(inputs, targets, mask)

    def start_epoch(self, rng: np.random.Generator | None = None) -> None:
        rng = rng or np.random.default_rng()
        order = rng.permutation(self.train.inputs.shape[0])
        self.train = DatasetSplit(
            self.train.inputs[order], self.train.targets[order], self.train.mask[order]
        )

    def _batch(self, split: DatasetSplit, index: int):
        if index < 0:
            raise IndexError(index)
        start = index * self.batch_size
        stop = start + self.batch_size
        if stop > split.inputs.shape[0]:
            raise IndexError(index)
        return split.inputs[start:stop], split.targets[start:stop], split.mask[start:stop]

    @property
    def train_batch_count(self) -> int:
        return self.train.inputs.shape[0] // self.batch_size

    @property
    def valid_batch_count(self) -> int:
        return self.valid.inputs.shape[0] // self.batch_size

    def get_train_batch(self, index: int):
        return self._batch(self.train, index)

    def get_valid_batch(self, index: int):
        return self._batch(self.valid, index)
