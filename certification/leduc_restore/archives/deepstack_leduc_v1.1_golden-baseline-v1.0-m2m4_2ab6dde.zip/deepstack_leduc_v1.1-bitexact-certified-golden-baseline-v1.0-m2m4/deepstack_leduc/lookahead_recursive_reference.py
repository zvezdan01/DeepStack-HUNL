from __future__ import annotations

from dataclasses import dataclass
import numpy as np

from .config import Config
from .cfrd_gadget import CFRDGadget
from .mock_nn_terminal import MockNNTerminal
from .next_round_value import NextRoundValue
from .terminal import TerminalEquity
from .tree import CHANCE, Node


@dataclass
class LookaheadResults:
    strategy: np.ndarray
    achieved_cfvs: np.ndarray
    children_cfvs: np.ndarray
    root_cfvs: np.ndarray | None = None
    root_cfvs_both_players: np.ndarray | None = None


class Lookahead:
    """Numerical port of ``Source/Lookahead/lookahead.lua``.

    The reference implementation stores a level-packed tensor tree.  This port
    keeps the exact same CFR+/CFR-D update equations on the public tree itself.
    The representation differs, but action ordering, range propagation,
    counterfactual-value indexing, root averaging, and child-CFV normalization
    follow the Lua source.
    """

    def __init__(self, cfg: Config = Config(), value_network=None) -> None:
        self.cfg = cfg
        self.value_network = value_network if value_network is not None else MockNNTerminal()
        self.tree: Node | None = None
        self.reconstruction_gadget: CFRDGadget | None = None
        self.reconstruction_opponent_cfvs: np.ndarray | None = None

    def build_lookahead(self, tree: Node) -> None:
        self.tree = tree
        self.terminal_equity = TerminalEquity(tree.board)
        self._decision_nodes: list[Node] = []
        self._chance_leaves: list[Node] = []
        self._initialize_nodes(tree)

    def _initialize_nodes(self, node: Node) -> None:
        node.ranges_absolute = np.zeros((2, self.cfg.card_count), dtype=np.float64)
        node.cf_values = np.zeros_like(node.ranges_absolute)
        if node.terminal:
            return
        if node.current_player == CHANCE and not node.children:
            box = NextRoundValue(self.value_network, self.cfg)
            box.start_computation(np.array([node.pot], dtype=np.float64))
            node._next_round_box = box  # type: ignore[attr-defined]
            self._chance_leaves.append(node)
            return
        if node.current_player != CHANCE:
            actions = len(node.children)
            node.regrets = np.full((actions, self.cfg.card_count), self.cfg.regret_epsilon)
            node._current_strategy = np.full((actions, self.cfg.card_count), 1.0 / actions)  # type: ignore[attr-defined]
            self._decision_nodes.append(node)
        for child in node.children:
            self._initialize_nodes(child)

    def resolve_first_node(self, player_range: np.ndarray, opponent_range: np.ndarray) -> None:
        self._validate_root()
        self.reconstruction_gadget = None
        self.reconstruction_opponent_cfvs = None
        self._root_player_range = np.asarray(player_range, dtype=np.float64).copy()
        self._fixed_opponent_range = np.asarray(opponent_range, dtype=np.float64).copy()
        self._compute()

    def resolve(self, player_range: np.ndarray, opponent_cfvs: np.ndarray) -> None:
        self._validate_root()
        self._root_player_range = np.asarray(player_range, dtype=np.float64).copy()
        self.reconstruction_opponent_cfvs = np.asarray(opponent_cfvs, dtype=np.float64).copy()
        assert self.tree is not None
        self.reconstruction_gadget = CFRDGadget(
            self.tree.board,
            self._root_player_range,
            self.reconstruction_opponent_cfvs,
            self.cfg,
        )
        self._compute()

    def _validate_root(self) -> None:
        if self.tree is None:
            raise RuntimeError("build_lookahead() must be called first")
        if self.tree.current_player not in (0, 1):
            raise ValueError("lookahead root must be a player node")

    def _compute(self) -> None:
        assert self.tree is not None
        root_actions = len(self.tree.children)
        k = self.cfg.card_count
        self._average_root_strategy = np.zeros((root_actions, k), dtype=np.float64)
        self._average_root_cfvs = np.zeros((2, k), dtype=np.float64)
        self._average_children_opponent_cfvs = np.zeros((root_actions, k), dtype=np.float64)
        self._last_root_cfvs = np.zeros((2, k), dtype=np.float64)

        for iteration in range(1, self.cfg.cfr_iters + 1):
            if self.reconstruction_gadget is not None:
                opponent_range = self.reconstruction_gadget.compute_opponent_range(
                    self._last_root_cfvs[1 - self.tree.current_player], iteration
                )
            else:
                opponent_range = self._fixed_opponent_range

            root_ranges = np.zeros((2, k), dtype=np.float64)
            root_ranges[self.tree.current_player] = self._root_player_range
            root_ranges[1 - self.tree.current_player] = opponent_range

            self._compute_current_strategies()
            root_cfvs, root_child_cfvs = self._cfr(self.tree, root_ranges)
            self._last_root_cfvs = root_cfvs.copy()

            if iteration > self.cfg.cfr_skip_iters:
                self._average_root_strategy += self.tree._current_strategy  # type: ignore[attr-defined]
                self._average_root_cfvs += root_cfvs
                opp = 1 - self.tree.current_player
                self._average_children_opponent_cfvs += root_child_cfvs[:, opp, :]

        n = self.cfg.cfr_iters - self.cfg.cfr_skip_iters
        if n <= 0:
            raise ValueError("cfr_iters must exceed cfr_skip_iters")
        self._average_root_cfvs /= n
        self._normalize_average_strategy()
        self._finalize_children_cfvs(n)

    def _compute_current_strategies(self) -> None:
        for node in self._decision_nodes:
            assert node.regrets is not None
            positive = np.maximum(node.regrets, self.cfg.regret_epsilon)
            # All concrete tree actions are legal; padding masks only exist in
            # the packed Lua representation and are absent here.
            sums = positive.sum(axis=0, keepdims=True)
            node._current_strategy = positive / sums  # type: ignore[attr-defined]

    def _cfr(self, node: Node, ranges: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        node.ranges_absolute = ranges.copy()
        if node.terminal:
            values = self._terminal_values(node, ranges)
            node.cf_values = values
            return values, np.zeros((0, 2, self.cfg.card_count), dtype=np.float64)

        if node.current_player == CHANCE and not node.children:
            box: NextRoundValue = node._next_round_box  # type: ignore[attr-defined]
            values = box.get_value(ranges[None, :, :])[0] * node.pot
            node.cf_values = values
            return values, np.zeros((0, 2, self.cfg.card_count), dtype=np.float64)

        if node.current_player == CHANCE:
            # This path is not used by depth-limited lookaheads, but preserves
            # the original chance strategy semantics for completeness.
            all_cfvs = []
            assert node.strategy is not None
            for action, child in enumerate(node.children):
                child_ranges = ranges.copy()
                child_ranges *= node.strategy[action][None, :]
                child_cfvs, _ = self._cfr(child, child_ranges)
                all_cfvs.append(child_cfvs)
            out = np.sum(np.asarray(all_cfvs), axis=0)
            node.cf_values = out
            return out, np.asarray(all_cfvs)

        player = node.current_player
        opponent = 1 - player
        strategy: np.ndarray = node._current_strategy  # type: ignore[attr-defined]
        child_cfvs = np.zeros((len(node.children), 2, self.cfg.card_count), dtype=np.float64)
        for action, child in enumerate(node.children):
            child_ranges = ranges.copy()
            child_ranges[player] *= strategy[action]
            child_cfvs[action], _ = self._cfr(child, child_ranges)

        out = np.zeros((2, self.cfg.card_count), dtype=np.float64)
        out[player] = np.sum(strategy * child_cfvs[:, player, :], axis=0)
        out[opponent] = np.sum(child_cfvs[:, opponent, :], axis=0)

        assert node.regrets is not None
        current_regrets = child_cfvs[:, player, :] - out[player][None, :]
        node.regrets += current_regrets
        np.maximum(node.regrets, 0.0, out=node.regrets)  # CFR+
        node.cf_values = out
        return out, child_cfvs

    def _terminal_values(self, node: Node, ranges: np.ndarray) -> np.ndarray:
        terminal = TerminalEquity(node.board)
        if node.terminal_type == "fold":
            # Child current_player is the winner; the other player folded.
            values = terminal.fold_values(ranges, 1 - node.current_player)
        elif node.terminal_type == "call":
            values = terminal.call_values(ranges)
        else:
            raise ValueError(f"unknown terminal type: {node.terminal_type}")
        return values * node.pot

    def _normalize_average_strategy(self) -> None:
        sums = self._average_root_strategy.sum(axis=0, keepdims=True)
        with np.errstate(divide="ignore", invalid="ignore"):
            strategy = self._average_root_strategy / sums
        bad = ~np.isfinite(strategy)
        if np.any(bad):
            strategy[:, np.any(bad, axis=0)] = 0.0
            strategy[0, np.any(bad, axis=0)] = 1.0
        self._average_root_strategy = strategy

    def _finalize_children_cfvs(self, averaging_iterations: int) -> None:
        assert self.tree is not None
        player_range = self._root_player_range[None, :]
        reach = np.sum(self._average_root_strategy * player_range, axis=1, keepdims=True)
        scaler = reach * averaging_iterations
        with np.errstate(divide="ignore", invalid="ignore"):
            out = self._average_children_opponent_cfvs / scaler
        out[~np.isfinite(out)] = 0.0
        self._children_cfvs = out

    def get_results(self) -> LookaheadResults:
        if not hasattr(self, "_children_cfvs"):
            raise RuntimeError("resolve() or resolve_first_node() must be called first")
        assert self.tree is not None
        player = self.tree.current_player
        opponent = 1 - player
        root_cfvs = None
        both = None
        if self.reconstruction_opponent_cfvs is None:
            root_cfvs = self._average_root_cfvs[player].copy()
            both = self._average_root_cfvs.copy()
        return LookaheadResults(
            strategy=self._average_root_strategy.copy(),
            achieved_cfvs=self._average_root_cfvs[opponent].copy(),
            children_cfvs=self._children_cfvs.copy(),
            root_cfvs=root_cfvs,
            root_cfvs_both_players=both,
        )

    def get_chance_action_cfv(self, action_index: int, board: tuple[int, ...]) -> np.ndarray:
        """Returns post-chance opponent CFVs for a chosen root action.

        Unlike the packed Lua implementation, the recursive tree lets us find
        the corresponding transition leaf directly.  ``action_index`` is
        zero-based in Python.
        """
        if self.tree is None:
            raise RuntimeError("lookahead not built")
        if not (0 <= action_index < len(self.tree.children)):
            raise IndexError("action_index out of range")
        child = self.tree.children[action_index]
        transition = self._find_first_transition(child)
        if transition is None:
            raise ValueError("selected action does not lead to a chance transition")
        box: NextRoundValue = transition._next_round_box  # type: ignore[attr-defined]
        values = box.get_value_on_board(board)[0] * transition.pot
        return values[1 - self.tree.current_player].copy()

    def _find_first_transition(self, node: Node) -> Node | None:
        if node.current_player == CHANCE and not node.children:
            return node
        for child in node.children:
            found = self._find_first_transition(child)
            if found is not None:
                return found
        return None
