import ctypes
import platform
from pathlib import Path

import numpy as np


_machine = platform.machine().lower()
_system = platform.system().lower()

BIT_EXACT_BACKEND = (
    _system == "linux"
    and _machine in ("x86_64", "amd64")
)

_lib = None
_sgemm = None


if BIT_EXACT_BACKEND:
    _lib = ctypes.CDLL(
        str(
            Path(__file__).resolve().parent.parent
            / "torch7_openblas.so.0"
        )
    )

    _sgemm = _lib.cblas_sgemm

    _sgemm.argtypes = [
        ctypes.c_int, ctypes.c_int, ctypes.c_int,
        ctypes.c_int, ctypes.c_int, ctypes.c_int,
        ctypes.c_float,
        ctypes.POINTER(ctypes.c_float), ctypes.c_int,
        ctypes.POINTER(ctypes.c_float), ctypes.c_int,
        ctypes.c_float,
        ctypes.POINTER(ctypes.c_float), ctypes.c_int,
    ]


def backend_name() -> str:
    if BIT_EXACT_BACKEND:
        return "torch7-openblas-bitexact"
    return f"numpy-portable-{_system}-{_machine}"


def mm(a, b):
    a = np.ascontiguousarray(a, dtype=np.float32)
    b = np.ascontiguousarray(b, dtype=np.float32)

    m, k = a.shape
    k2, n = b.shape
    assert k == k2

    if not BIT_EXACT_BACKEND:
        return np.asarray(a @ b, dtype=np.float32)

    out = np.empty((m, n), dtype=np.float32)

    _sgemm(
        101, 111, 111,             # RowMajor, NoTrans, NoTrans
        m, n, k,
        ctypes.c_float(1.0),
        a.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), k,
        b.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), n,
        ctypes.c_float(0.0),
        out.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), n,
    )

    return out
