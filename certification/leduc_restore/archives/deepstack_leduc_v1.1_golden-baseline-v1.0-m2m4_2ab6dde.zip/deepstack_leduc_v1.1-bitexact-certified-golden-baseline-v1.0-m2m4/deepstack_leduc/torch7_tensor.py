from __future__ import annotations

import io
import struct
from pathlib import Path

import numpy as np


class Torch7FormatError(ValueError):
    pass


def _read_i32(f: io.BufferedReader) -> int:
    data = f.read(4)
    if len(data) != 4:
        raise Torch7FormatError("unexpected end of file")
    return struct.unpack("<i", data)[0]


def _read_i64(f: io.BufferedReader) -> int:
    data = f.read(8)
    if len(data) != 8:
        raise Torch7FormatError("unexpected end of file")
    return struct.unpack("<q", data)[0]


def _read_string(f: io.BufferedReader) -> str:
    n = _read_i32(f)
    if n < 0 or n > 1_000_000:
        raise Torch7FormatError(f"invalid string length {n}")
    data = f.read(n)
    if len(data) != n:
        raise Torch7FormatError("truncated string")
    return data.decode("utf-8")


def load_float_tensor(path: str | Path) -> np.ndarray:
    """Load a standalone Torch7 ``torch.FloatTensor`` file.

    This intentionally supports the exact tensor serialization used by the
    uploaded DeepStack train/validation files. It does not pretend to be a
    general Torch7 object deserializer.
    """

    with Path(path).open("rb") as f:
        type_tag = _read_i32(f)
        object_index = _read_i32(f)
        if type_tag != 4 or object_index != 1:
            raise Torch7FormatError("expected root Torch object")
        version = _read_string(f)
        class_name = _read_string(f)
        if version != "V 1" or class_name != "torch.FloatTensor":
            raise Torch7FormatError(
                f"expected V 1 torch.FloatTensor, got {version!r} {class_name!r}"
            )

        ndim = _read_i32(f)
        if ndim < 0 or ndim > 16:
            raise Torch7FormatError(f"invalid ndim {ndim}")
        size = tuple(_read_i64(f) for _ in range(ndim))
        stride = tuple(_read_i64(f) for _ in range(ndim))
        storage_offset = _read_i64(f) - 1  # Torch7 is one-based.

        storage_tag = _read_i32(f)
        storage_index = _read_i32(f)
        storage_version = _read_string(f)
        storage_class = _read_string(f)
        if storage_tag != 4 or storage_index != 2:
            raise Torch7FormatError("expected embedded Torch storage")
        if storage_version != "V 1" or storage_class != "torch.FloatStorage":
            raise Torch7FormatError("expected torch.FloatStorage")
        storage_size = _read_i64(f)
        raw = f.read(storage_size * 4)
        if len(raw) != storage_size * 4:
            raise Torch7FormatError("truncated float storage")
        storage = np.frombuffer(raw, dtype="<f4").copy()

    if ndim == 0:
        return storage[storage_offset : storage_offset + 1].reshape(())
    max_index = storage_offset + sum((n - 1) * st for n, st in zip(size, stride))
    if storage_offset < 0 or max_index >= storage_size:
        raise Torch7FormatError("tensor view exceeds storage")
    byte_strides = tuple(st * storage.itemsize for st in stride)
    base = storage[storage_offset:]
    return np.lib.stride_tricks.as_strided(base, shape=size, strides=byte_strides).copy()
