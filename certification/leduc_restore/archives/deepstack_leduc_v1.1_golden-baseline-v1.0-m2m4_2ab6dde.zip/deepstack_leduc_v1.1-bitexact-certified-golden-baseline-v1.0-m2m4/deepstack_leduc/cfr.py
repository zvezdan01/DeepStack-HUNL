from __future__ import annotations
import numpy as np
from .config import Config
from .tree import Node
from .terminal import TerminalEquity

class TreeCFR:
    """Faithful NumPy port of Source/Tree/tree_cfr.lua (CFR+ style)."""
    def __init__(self, cfg: Config = Config()):
        self.cfg=cfg
        self._terminal_cache: dict[tuple[int,...], TerminalEquity] = {}

    def _terminal(self, board: tuple[int,...]) -> TerminalEquity:
        if board not in self._terminal_cache:
            self._terminal_cache[board]=TerminalEquity(board)
        return self._terminal_cache[board]

    def run(self, root: Node, starting_ranges: np.ndarray, iters: int | None=None) -> Node:
        iters = iters or self.cfg.cfr_iters
        root.ranges_absolute=np.asarray(starting_ranges,dtype=float).copy()
        for i in range(1,iters+1): self._dfs(root,i)
        return root

    def _dfs(self,node:Node,iteration:int) -> np.ndarray:
        assert node.ranges_absolute is not None
        if node.terminal:
            te=self._terminal(node.board)
            if node.terminal_type=="fold":
                # current_player is winner in original child construction, so folding player is opponent.
                folding_player=1-node.current_player
                vals=te.fold_values(node.ranges_absolute,folding_player)
            else:
                vals=te.call_values(node.ranges_absolute)
            node.cf_values=vals*node.pot
            return node.cf_values

        a=len(node.children)
        if node.current_player == -1:
            current_strategy=node.strategy
        else:
            if node.regrets is None:
                node.regrets=np.full((a,6),self.cfg.regret_epsilon)
            pos=np.maximum(node.regrets,self.cfg.regret_epsilon)
            current_strategy=pos/pos.sum(axis=0,keepdims=True)
        assert current_strategy is not None
        all_cf=np.zeros((a,2,6),dtype=float)
        for i,ch in enumerate(node.children):
            ch.ranges_absolute=node.ranges_absolute.copy()
            if node.current_player == -1:
                ch.ranges_absolute[0] *= current_strategy[i]
                ch.ranges_absolute[1] *= current_strategy[i]
            else:
                ch.ranges_absolute[node.current_player] *= current_strategy[i]
            all_cf[i]=self._dfs(ch,iteration)
        out=np.zeros((2,6),dtype=float)
        if node.current_player == -1:
            out=all_cf.sum(axis=0)
        else:
            p=node.current_player; o=1-p
            out[p]=(current_strategy*all_cf[:,p,:]).sum(axis=0)
            out[o]=all_cf[:,o,:].sum(axis=0)
            regret=all_cf[:,p,:]-out[p][None,:]
            node.regrets=np.maximum(node.regrets+regret,self.cfg.regret_epsilon)
            if iteration>self.cfg.cfr_skip_iters:
                if node.strategy is None or node.avg_weight_sum is None:
                    node.strategy=np.zeros((a,6),dtype=float)
                    node.avg_weight_sum=np.zeros(6,dtype=float)
                contrib=np.maximum(node.ranges_absolute[p],self.cfg.regret_epsilon)
                node.avg_weight_sum += contrib
                w=contrib/node.avg_weight_sum
                node.strategy *= (1-w)[None,:]
                node.strategy += current_strategy*w[None,:]
        node.cf_values=out
        return out
