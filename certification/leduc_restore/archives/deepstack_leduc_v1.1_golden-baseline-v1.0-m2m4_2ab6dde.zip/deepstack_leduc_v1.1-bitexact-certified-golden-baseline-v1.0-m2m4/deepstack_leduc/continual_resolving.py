from __future__ import annotations

import numpy as np

from .acpc import MatchState
from .card_tools import normalize_range
from .cards import uniform_range
from .config import Config
from .resolving import Resolving
from .tree import CALL, FOLD, Node


class ContinualResolving:
    """Direct zero-based port of ``Player/continual_resolving.lua``."""

    def __init__(self, cfg: Config = Config(), value_network=None, seed: int | None = None) -> None:
        self.cfg = cfg
        self.value_network = value_network
        self.rng = np.random.default_rng(seed)
        self.starting_player_range = uniform_range(()).astype(np.float32)
        self.resolve_first_node()
        self.last_node: Node | None = None
        self.last_bet: int | None = None
        self.decision_id: int | None = None
        self.position: int | None = None
        self.hand_id: int | None = None
        self.current_player_range: np.ndarray | None = None
        self.current_opponent_cfvs_bound: np.ndarray | None = None
        self.resolving: Resolving | None = None

    def resolve_first_node(self) -> None:
        first_node = Node(
            street=1,
            current_player=0,
            bets=np.array([self.cfg.ante, self.cfg.ante], dtype=np.float32),
            board=(),
        )
        player_range = uniform_range(first_node.board).astype(np.float32)
        opponent_range = uniform_range(first_node.board).astype(np.float32)
        self.first_node_resolving = Resolving(self.cfg, self.value_network)
        self.first_node_resolving.resolve_first_node(first_node, player_range, opponent_range)
        self.starting_cfvs_p1 = self.first_node_resolving.get_root_cfv()

    def start_new_hand(self, state: MatchState) -> None:
        if state.private_card is None:
            raise ValueError("cannot start a hand without the player's private card")
        self.last_node = None
        self.last_bet = None
        self.decision_id = 0
        self.position = state.position
        self.hand_id = state.private_card
        self.current_player_range = None
        self.current_opponent_cfvs_bound = None
        self.resolving = None

    def _resolve_node(self, node: Node, state: MatchState) -> None:
        if self.decision_id is None or self.position is None:
            raise RuntimeError("start_new_hand() must be called first")
        if self.decision_id == 0 and self.position == 0:
            self.current_player_range = self.starting_player_range.copy()
            self.resolving = self.first_node_resolving
        else:
            if node.terminal or node.current_player != self.position:
                raise ValueError("node is not a decision node for this player")
            self._update_invariant(node, state)
            assert self.current_player_range is not None
            assert self.current_opponent_cfvs_bound is not None
            self.resolving = Resolving(self.cfg, self.value_network)
            self.resolving.resolve(node, self.current_player_range, self.current_opponent_cfvs_bound)

    def _update_invariant(self, node: Node, state: MatchState) -> None:
        del state  # retained to keep the original API contract
        if self.last_node is not None and self.last_node.street != node.street:
            if self.last_node.street + 1 != node.street:
                raise ValueError("street transition must advance exactly one street")
            if self.resolving is None or self.last_bet is None:
                raise RuntimeError("missing previous resolving state")
            self.current_opponent_cfvs_bound = self.resolving.get_chance_action_cfv(
                self.last_bet, node.board
            )
            assert self.current_player_range is not None
            self.current_player_range = normalize_range(node.board, self.current_player_range).astype(np.float32)
        elif self.decision_id == 0:
            if self.position != 1 or node.street != 1:
                raise ValueError("the only non-P1 first decision is P2 on street 1")
            self.current_player_range = self.starting_player_range.copy()
            self.current_opponent_cfvs_bound = self.starting_cfvs_p1.copy()
        else:
            if self.last_node is None or self.last_node.street != node.street:
                raise ValueError("within-street invariant update has inconsistent state")
            # No update is required for opponent actions within the street. The
            # opponent's bound was stored immediately after our previous action.

    def compute_action(self, node: Node, state: MatchState) -> str:
        self._resolve_node(node, state)
        sampled_bet = self._sample_bet(node, state)
        assert self.decision_id is not None
        self.decision_id += 1
        self.last_bet = sampled_bet
        self.last_node = Node(
            street=node.street,
            current_player=node.current_player,
            bets=node.bets.copy(),
            board=tuple(node.board),
        )
        return self._bet_to_protocol_action(sampled_bet)

    def _sample_bet(self, node: Node, state: MatchState) -> int:
        del state
        if self.resolving is None or self.hand_id is None:
            raise RuntimeError("node has not been resolved")
        possible_bets = self.resolving.get_possible_actions()
        hand_strategy = np.array(
            [self.resolving.get_action_strategy(b)[self.hand_id] for b in possible_bets],
            dtype=np.float64,
        )
        total = float(hand_strategy.sum())
        if abs(1.0 - total) >= 0.001:
            raise RuntimeError(f"hand strategy must sum to one, got {total}")
        cumsum = np.cumsum(hand_strategy)
        r = float(self.rng.random())
        action_index = int(np.searchsorted(cumsum, r, side="right"))
        action_index = min(action_index, len(possible_bets) - 1)
        sampled_bet = int(possible_bets[action_index])

        self.current_opponent_cfvs_bound = self.resolving.get_action_cfv(sampled_bet)
        strategy = self.resolving.get_action_strategy(sampled_bet)
        assert self.current_player_range is not None
        self.current_player_range *= strategy
        self.current_player_range = normalize_range(node.board, self.current_player_range).astype(np.float32)
        return sampled_bet

    @staticmethod
    def _bet_to_protocol_action(sampled_bet: int) -> str:
        if sampled_bet == FOLD:
            return "f"
        if sampled_bet == CALL:
            return "c"
        if sampled_bet < 0:
            raise ValueError(f"invalid internal action {sampled_bet}")
        return f"r{sampled_bet}"
