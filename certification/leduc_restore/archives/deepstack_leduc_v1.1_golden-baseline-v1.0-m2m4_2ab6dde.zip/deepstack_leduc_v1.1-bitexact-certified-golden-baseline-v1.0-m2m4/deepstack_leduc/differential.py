from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
import json
import numpy as np


TRACE_STAGES = (
    "opponent_range",
    "current_strategy",
    "ranges",
    "average_strategy",
    "terminal_cfvs",
    "current_cfvs",
    "regrets",
    "average_cfvs",
)


@dataclass(frozen=True)
class TensorMismatch:
    name: str
    shape_python: tuple[int, ...]
    shape_reference: tuple[int, ...]
    max_abs_error: float
    max_rel_error: float


def _flatten_named(mapping: dict[str, object], prefix: str = "") -> dict[str, np.ndarray]:
    out: dict[str, np.ndarray] = {}
    for key, value in mapping.items():
        name = f"{prefix}{key}"
        if isinstance(value, dict):
            out.update(_flatten_named({str(k): v for k, v in value.items()}, name + "."))
        elif value is None:
            continue
        else:
            arr = np.asarray(value)
            if arr.dtype.kind in "biufc":
                out[name] = np.ascontiguousarray(arr).copy()
    return out


def capture_lookahead(lookahead, stage: str, iteration: int) -> dict[str, np.ndarray]:
    if stage not in TRACE_STAGES:
        raise ValueError(f"unknown trace stage: {stage}")
    raw: dict[str, object] = {
        "meta": {
            "iteration": np.asarray([iteration], dtype=np.int64),
            "stage_id": np.asarray([TRACE_STAGES.index(stage)], dtype=np.int64),
        },
        "ranges_data": lookahead.ranges_data,
        "cfvs_data": lookahead.cfvs_data,
        "regrets_data": lookahead.regrets_data,
        "current_strategy_data": lookahead.current_strategy_data,
        "average_strategies_data": lookahead.average_strategies_data,
        "average_cfvs_data": lookahead.average_cfvs_data,
    }
    if lookahead.reconstruction_gadget is not None:
        gadget = lookahead.reconstruction_gadget
        raw["gadget"] = {
            "play_current_strategy": gadget.play_current_strategy,
            "terminate_current_strategy": gadget.terminate_current_strategy,
            "play_regrets": gadget.play_regrets,
            "terminate_regrets": gadget.terminate_regrets,
        }
    return _flatten_named(raw)


def save_trace(path: str | Path, snapshots: Iterable[tuple[str, int, dict[str, np.ndarray]]]) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    manifest = []
    for stage, iteration, arrays in snapshots:
        file_name = f"iter_{iteration:04d}_{stage}.npz"
        np.savez(path / file_name, **arrays)
        manifest.append({"iteration": iteration, "stage": stage, "file": file_name})
    (path / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return path


def compare_npz(
    python_file: str | Path,
    reference_file: str | Path,
    *,
    atol: float = 1e-6,
    rtol: float = 1e-5,
) -> list[TensorMismatch]:
    py = np.load(python_file)
    ref = np.load(reference_file)
    if set(py.files) != set(ref.files):
        missing_py = sorted(set(ref.files) - set(py.files))
        missing_ref = sorted(set(py.files) - set(ref.files))
        raise AssertionError(f"tensor key mismatch: missing_python={missing_py}, missing_reference={missing_ref}")
    mismatches: list[TensorMismatch] = []
    for name in sorted(py.files):
        a = np.asarray(py[name])
        b = np.asarray(ref[name])
        if a.shape != b.shape:
            mismatches.append(TensorMismatch(name, a.shape, b.shape, float("inf"), float("inf")))
            continue
        if np.array_equal(a, b):
            continue
        abs_err = np.abs(a.astype(np.float64) - b.astype(np.float64))
        denom = np.maximum(np.abs(b.astype(np.float64)), 1e-30)
        rel_err = abs_err / denom
        if not np.allclose(a, b, atol=atol, rtol=rtol, equal_nan=True):
            mismatches.append(
                TensorMismatch(name, a.shape, b.shape, float(abs_err.max(initial=0.0)), float(rel_err.max(initial=0.0)))
            )
    return mismatches
