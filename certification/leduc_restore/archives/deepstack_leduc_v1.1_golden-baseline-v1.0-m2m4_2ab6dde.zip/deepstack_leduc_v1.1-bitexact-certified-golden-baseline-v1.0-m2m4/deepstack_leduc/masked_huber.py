from __future__ import annotations

import torch
from torch import Tensor


class MaskedHuberLoss:
    """Exact behavioral port of Source/Nn/masked_huber_loss.lua.

    This intentionally reproduces the reference implementation's in-place
    masking and its unusual scalar rescaling. It is not replaced with a more
    conventional masked mean because numerical compatibility is the goal.
    """

    def __init__(self) -> None:
        self._mask_multiplier: Tensor | None = None

    @staticmethod
    def _smooth_l1_mean(outputs: Tensor, targets: Tensor) -> Tensor:
        return torch.nn.functional.smooth_l1_loss(outputs, targets, reduction="mean", beta=1.0)

    def forward(self, outputs: Tensor, targets: Tensor, mask: Tensor) -> Tensor:
        if outputs.shape != targets.shape or outputs.shape != mask.shape:
            raise ValueError("outputs, targets and mask must have identical shapes")
        if outputs.ndim != 2:
            raise ValueError("Expected N x M tensors")

        outputs.mul_(mask)
        targets.mul_(mask)
        loss = self._smooth_l1_mean(outputs, targets)

        batch_size, feature_size = outputs.shape
        mask_sum = mask.sum(dim=1)
        self._mask_multiplier = ((feature_size - mask_sum) / feature_size).view(-1, 1)
        denominator = batch_size * feature_size - mask_sum.sum()
        if denominator.item() == 0:
            raise ZeroDivisionError("Reference loss is undefined when every feature is masked in")
        loss_multiplier = (batch_size * feature_size) / denominator
        return loss_multiplier * loss

    def backward(self, outputs: Tensor, targets: Tensor) -> Tensor:
        if self._mask_multiplier is None:
            raise RuntimeError("forward() must be called before backward()")
        diff = outputs - targets
        grad = torch.where(diff.abs() < 1.0, diff, diff.sign()) / outputs.numel()
        return grad / self._mask_multiplier.expand_as(grad)
