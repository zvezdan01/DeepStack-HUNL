from __future__ import annotations

from dataclasses import dataclass
import re
import socket
import numpy as np

from .cards import string_to_card, string_to_board
from .config import Config
from .tree import Node


@dataclass(frozen=True)
class ParsedAction:
    kind: str
    raise_amount: int | None
    player: int
    street: int
    index: int


@dataclass
class MatchState:
    """Processed ACPC state matching ``protocol_to_node.lua`` semantics.

    Internal players are zero-based: P1=0, P2=1. ACPC position 0 therefore
    maps directly to P1 and position 1 to P2.
    """

    position: int
    hand_number: int
    actions_by_street: list[str]
    private_card: int | None
    board: tuple[int, ...]
    raw: str
    actions: list[list[tuple[str, int | None]]]
    all_actions: list[ParsedAction]
    acting_player: int
    bets: np.ndarray

    @property
    def street(self) -> int:
        return 2 if self.board else 1

    @property
    def hand_id(self) -> int | None:
        # Lua overloads hand_id after parsing to mean the private card id.
        return self.private_card

    def to_node(self) -> Node:
        return Node(
            street=self.street,
            current_player=self.acting_player,
            bets=self.bets.astype(float, copy=True),
            board=tuple(self.board),
        )


_ACTION_RE = re.compile(r"r(\d+)|[cf]")


def decode_actions(raw: str) -> list[tuple[str, int | None]]:
    out: list[tuple[str, int | None]] = []
    pos = 0
    for m in _ACTION_RE.finditer(raw):
        if m.start() != pos:
            raise ValueError(f"invalid ACPC action string at offset {pos}: {raw!r}")
        tok = m.group(0)
        if tok == "c":
            out.append(("call", None))
        elif tok == "f":
            out.append(("fold", None))
        else:
            out.append(("raise", int(m.group(1))))
        pos = m.end()
    if pos != len(raw):
        raise ValueError(f"invalid ACPC action string at offset {pos}: {raw!r}")
    return out


def _convert_actions(actions: list[list[tuple[str, int | None]]]) -> list[ParsedAction]:
    out: list[ParsedAction] = []
    for street, street_actions in enumerate(actions, start=1):
        # Reference Leduc implementation starts P1 on both streets.
        for i, (kind, amount) in enumerate(street_actions):
            player = i % 2
            out.append(ParsedAction(kind, amount, player, street, len(out)))
    return out


def _acting_player(street: int, actions: list[list[tuple[str, int | None]]], all_actions: list[ParsedAction]) -> int:
    if not all_actions:
        if street != 1:
            raise ValueError("empty action history is only legal on street 1")
        return 0
    last = all_actions[-1]
    if last.street != street:
        return 0
    if last.kind == "fold":
        return -1
    if street == 2 and len(actions[1]) >= 2 and last.kind == "call":
        return -1
    return 1 - last.player


def _compute_commitments(cfg: Config, all_actions: list[ParsedAction], acting_player: int) -> np.ndarray:
    """Replay ACPC total-commitment actions into the public node commitments.

    ACPC no-limit raise amounts are total chips committed by the actor. A call
    copies the opponent's total commitment. This is the state represented by
    ``processed_state.bet1/bet2`` and consumed by ``parsed_state_to_node``.
    """
    if acting_player == -1:
        return np.array([-1.0, -1.0], dtype=np.float32)
    bets = np.array([cfg.ante, cfg.ante], dtype=np.float32)
    for action in all_actions:
        if action.kind == "raise":
            if action.raise_amount is None:
                raise ValueError("raise without amount")
            bets[action.player] = float(action.raise_amount)
        elif action.kind == "call":
            bets[action.player] = bets[1 - action.player]
        elif action.kind == "fold":
            break
        else:
            raise ValueError(f"unknown action kind: {action.kind}")
    return bets


def parse_matchstate(line: str, cfg: Config = Config()) -> MatchState:
    line = line.strip()
    parts = line.split(":", 4)
    if len(parts) != 5 or parts[0] != "MATCHSTATE":
        raise ValueError(f"Bad MATCHSTATE: {line}")
    position = int(parts[1])
    if position not in (0, 1):
        raise ValueError(f"invalid position {position}")
    hand_number = int(parts[2])

    actions_raw = parts[3].split("/")
    if len(actions_raw) > 2:
        raise ValueError("Leduc implementation supports exactly two streets")
    actions_raw += [""] * (2 - len(actions_raw))
    actions = [decode_actions(x) for x in actions_raw]
    all_actions = _convert_actions(actions)

    cards = parts[4].split("/")
    hole = cards[0].split("|")
    hole += [""] * (2 - len(hole))
    own = hole[position].strip()
    private = string_to_card(own) if own else None
    board = string_to_board(cards[1]) if len(cards) > 1 and cards[1] else ()
    street = 2 if board else 1
    actor = _acting_player(street, actions, all_actions)
    bets = _compute_commitments(cfg, all_actions, actor)

    return MatchState(
        position=position,
        hand_number=hand_number,
        actions_by_street=actions_raw,
        private_card=private,
        board=board,
        raw=line,
        actions=actions,
        all_actions=all_actions,
        acting_player=actor,
        bets=bets,
    )


class ACPCClient:
    def __init__(self, host: str, port: int, timeout: float = 60, cfg: Config = Config()):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.cfg = cfg

    def play(self, agent) -> None:
        with socket.create_connection((self.host, self.port), timeout=self.timeout) as s:
            f = s.makefile("rwb", buffering=0)
            f.write(b"VERSION:2.0.0\r\n")
            for raw in f:
                line = raw.decode().strip()
                if not line:
                    continue
                state = parse_matchstate(line, self.cfg)
                if state.acting_player != state.position:
                    continue
                if np.all(state.bets == self.cfg.stack):
                    continue
                action = agent.act(state)
                if action is not None:
                    f.write((line + ":" + action + "\r\n").encode())
