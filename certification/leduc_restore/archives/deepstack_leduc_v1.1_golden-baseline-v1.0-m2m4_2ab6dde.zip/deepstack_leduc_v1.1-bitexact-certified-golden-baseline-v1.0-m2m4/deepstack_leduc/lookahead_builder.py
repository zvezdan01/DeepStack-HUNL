from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
import numpy as np

from .tree import Node, CHANCE
from .config import Config


@dataclass
class LookaheadData:
    """Tensor layout used by the original Torch7 lookahead_builder.lua.

    Dictionary keys keep the original Lua depth numbers (1-based). NumPy
    indices inside tensors are naturally 0-based.
    """
    tree: Node
    depth: int
    ccall_action_index: int = 0
    fold_action_index: int = 1
    regret_epsilon: float = 1e-9

    bets_count: Dict[int, int] = field(default_factory=dict)
    nonallinbets_count: Dict[int, int] = field(default_factory=dict)
    terminal_actions_count: Dict[int, int] = field(default_factory=dict)
    actions_count: Dict[int, int] = field(default_factory=dict)

    acting_player: np.ndarray | None = None
    nonterminal_nodes_count: Dict[int, int] = field(default_factory=dict)
    nonterminal_nonallin_nodes_count: Dict[int, int] = field(default_factory=dict)
    all_nodes_count: Dict[int, int] = field(default_factory=dict)
    terminal_nodes_count: Dict[int, int] = field(default_factory=dict)
    allin_nodes_count: Dict[int, int] = field(default_factory=dict)
    inner_nodes_count: Dict[int, int] = field(default_factory=dict)

    pot_size: Dict[int, np.ndarray] = field(default_factory=dict)
    ranges_data: Dict[int, np.ndarray] = field(default_factory=dict)
    average_strategies_data: Dict[int, np.ndarray | None] = field(default_factory=dict)
    current_strategy_data: Dict[int, np.ndarray | None] = field(default_factory=dict)
    cfvs_data: Dict[int, np.ndarray] = field(default_factory=dict)
    average_cfvs_data: Dict[int, np.ndarray] = field(default_factory=dict)
    regrets_data: Dict[int, np.ndarray | None] = field(default_factory=dict)
    current_regrets_data: Dict[int, np.ndarray | None] = field(default_factory=dict)
    positive_regrets_data: Dict[int, np.ndarray | None] = field(default_factory=dict)
    placeholder_data: Dict[int, np.ndarray] = field(default_factory=dict)
    regrets_sum: Dict[int, np.ndarray] = field(default_factory=dict)
    empty_action_mask: Dict[int, np.ndarray | None] = field(default_factory=dict)
    inner_nodes: Dict[int, np.ndarray] = field(default_factory=dict)
    inner_nodes_p1: Dict[int, np.ndarray] = field(default_factory=dict)
    swap_data: Dict[int, np.ndarray] = field(default_factory=dict)

    first_call_terminal: bool = False
    first_call_transition: bool = False
    first_call_check: bool = False


class LookaheadBuilder:
    def __init__(self, cfg: Config = Config()) -> None:
        self.cfg = cfg

    def build_from_tree(self, tree: Node) -> LookaheadData:
        la = LookaheadData(tree=tree, depth=tree.depth, regret_epsilon=self.cfg.regret_epsilon)
        self.la = la
        self._compute_tree_structures([tree], 1)
        self._construct_data_structures()
        self._set_datastructures_from_tree_dfs(tree, 1, 1, 1, 1)

        if la.terminal_actions_count[1] not in (1, 2):
            raise AssertionError("root layer must have one or two terminal/chance actions")
        call_child = tree.children[1]
        la.first_call_terminal = bool(call_child.terminal)
        la.first_call_transition = call_child.current_player == CHANCE
        la.first_call_check = not la.first_call_terminal and not la.first_call_transition

        # Original masks fold when checking is free.
        if float(tree.bets[0]) == float(tree.bets[1]):
            assert la.empty_action_mask[2] is not None
            la.empty_action_mask[2][0, ...] = 0.0
        return la

    def _compute_tree_structures(self, current_layer: List[Node], current_depth: int) -> None:
        la = self.la
        layer_actions_count = 0
        layer_terminal_actions_count = 0
        next_layer: List[Node] = []
        for node in current_layer:
            layer_actions_count = max(layer_actions_count, len(node.children))
            node_terminal = sum(
                1 for c in node.children if c.terminal or c.current_player == CHANCE
            )
            layer_terminal_actions_count = max(layer_terminal_actions_count, node_terminal)
            if not node.terminal:
                next_layer.extend(node.children)

        if (layer_actions_count == 0) != (len(next_layer) == 0):
            raise AssertionError("inconsistent final layer")
        if (layer_actions_count == 0) != (current_depth == la.depth):
            raise AssertionError("tree depth mismatch")

        la.bets_count[current_depth] = layer_actions_count - layer_terminal_actions_count
        nonallin = layer_actions_count - layer_terminal_actions_count - 1
        if layer_actions_count == 2:
            if layer_actions_count != layer_terminal_actions_count:
                raise AssertionError("two-action layer must be fully terminal/chance")
            nonallin = 0
        la.nonallinbets_count[current_depth] = nonallin
        la.terminal_actions_count[current_depth] = layer_terminal_actions_count
        la.actions_count[current_depth] = layer_actions_count

        if next_layer:
            if layer_actions_count < 2:
                raise AssertionError("nonfinal layer needs at least two actions")
            self._compute_tree_structures(next_layer, current_depth + 1)

    def _compute_structure(self) -> None:
        la = self.la
        for k in (-1, 0):
            la.bets_count[k] = 1
            la.nonallinbets_count[k] = 1
            la.terminal_actions_count[k] = 0
            la.actions_count[k] = 1

        la.acting_player = np.full(la.depth + 1, -1, dtype=np.int64)
        la.acting_player[0] = 1
        for d in range(1, la.depth + 1):
            la.acting_player[d] = 3 - la.acting_player[d - 1]

        la.nonterminal_nodes_count[1] = 1
        la.nonterminal_nodes_count[2] = la.bets_count[1]
        la.nonterminal_nonallin_nodes_count[0] = 1
        la.nonterminal_nonallin_nodes_count[1] = 1
        la.nonterminal_nonallin_nodes_count[2] = la.nonterminal_nodes_count[2] - 1
        la.all_nodes_count[1] = 1
        la.all_nodes_count[2] = la.actions_count[1]
        la.terminal_nodes_count[1] = 0
        la.terminal_nodes_count[2] = 2
        la.allin_nodes_count[1] = 0
        la.allin_nodes_count[2] = 1
        la.inner_nodes_count[1] = 1
        la.inner_nodes_count[2] = 1

        for d in range(2, la.depth + 1):
            la.all_nodes_count[d + 1] = (
                la.nonterminal_nonallin_nodes_count[d - 1]
                * la.bets_count[d - 1]
                * la.actions_count[d]
            )
            la.allin_nodes_count[d + 1] = (
                la.nonterminal_nonallin_nodes_count[d - 1] * la.bets_count[d - 1]
            )
            la.nonterminal_nodes_count[d + 1] = (
                la.nonterminal_nonallin_nodes_count[d - 1]
                * la.nonallinbets_count[d - 1]
                * la.bets_count[d]
            )
            la.nonterminal_nonallin_nodes_count[d + 1] = (
                la.nonterminal_nonallin_nodes_count[d - 1]
                * la.nonallinbets_count[d - 1]
                * la.nonallinbets_count[d]
            )
            la.terminal_nodes_count[d + 1] = (
                la.nonterminal_nonallin_nodes_count[d - 1]
                * la.bets_count[d - 1]
                * la.terminal_actions_count[d]
            )

    def _construct_data_structures(self) -> None:
        self._compute_structure()
        la, K, P = self.la, self.cfg.card_count, 2

        la.ranges_data[1] = np.full((1, 1, 1, P, K), 1.0 / K, dtype=np.float32)
        la.ranges_data[2] = np.full((la.actions_count[1], 1, 1, P, K), 1.0 / K, dtype=np.float32)
        for d in (1, 2):
            la.pot_size[d] = np.zeros_like(la.ranges_data[d])
            la.cfvs_data[d] = np.zeros_like(la.ranges_data[d])
            la.average_cfvs_data[d] = np.zeros_like(la.ranges_data[d])
            la.placeholder_data[d] = np.zeros_like(la.ranges_data[d])

        la.average_strategies_data[1] = None
        la.current_strategy_data[1] = None
        la.regrets_data[1] = None
        la.current_regrets_data[1] = None
        la.positive_regrets_data[1] = None
        la.empty_action_mask[1] = None

        shape2 = (la.actions_count[1], 1, 1, K)
        la.average_strategies_data[2] = np.zeros(shape2, dtype=np.float32)
        la.current_strategy_data[2] = np.zeros(shape2, dtype=np.float32)
        la.regrets_data[2] = np.zeros(shape2, dtype=np.float32)
        la.current_regrets_data[2] = np.zeros(shape2, dtype=np.float32)
        la.positive_regrets_data[2] = np.zeros(shape2, dtype=np.float32)
        la.empty_action_mask[2] = np.ones(shape2, dtype=np.float32)
        la.regrets_sum[1] = np.zeros((1, 1, 1, K), dtype=np.float32)
        la.regrets_sum[2] = np.zeros((1, la.bets_count[1], 1, K), dtype=np.float32)

        la.inner_nodes[1] = np.zeros((1, 1, 1, P, K), dtype=np.float32)
        la.swap_data[1] = la.inner_nodes[1].swapaxes(1, 2).copy()
        la.inner_nodes_p1[1] = np.zeros((1, 1, 1, 1, K), dtype=np.float32)
        if la.depth > 2:
            la.inner_nodes[2] = np.zeros((la.bets_count[1], 1, 1, P, K), dtype=np.float32)
            la.swap_data[2] = la.inner_nodes[2].swapaxes(1, 2).copy()
            la.inner_nodes_p1[2] = np.zeros((la.bets_count[1], 1, 1, 1, K), dtype=np.float32)

        for d in range(3, la.depth + 1):
            rshape = (
                la.actions_count[d - 1],
                la.bets_count[d - 2],
                la.nonterminal_nonallin_nodes_count[d - 2],
                P,
                K,
            )
            la.ranges_data[d] = np.zeros(rshape, dtype=np.float32)
            la.cfvs_data[d] = np.zeros(rshape, dtype=np.float32)
            la.placeholder_data[d] = np.zeros(rshape, dtype=np.float32)
            la.pot_size[d] = np.full(rshape, self.cfg.stack, dtype=np.float32)
            sshape = rshape[:3] + (K,)
            la.average_strategies_data[d] = np.zeros(sshape, dtype=np.float32)
            la.current_strategy_data[d] = np.zeros(sshape, dtype=np.float32)
            la.regrets_data[d] = np.full(sshape, la.regret_epsilon, dtype=np.float32)
            la.current_regrets_data[d] = np.zeros(sshape, dtype=np.float32)
            la.empty_action_mask[d] = np.ones(sshape, dtype=np.float32)
            la.positive_regrets_data[d] = np.full(sshape, la.regret_epsilon, dtype=np.float32)
            la.regrets_sum[d] = np.zeros(
                (1, la.bets_count[d - 2], la.nonterminal_nonallin_nodes_count[d - 2], P, K),
                dtype=np.float32,
            )
            if d < la.depth:
                ishape = (
                    la.bets_count[d - 1],
                    la.nonallinbets_count[d - 2],
                    la.nonterminal_nonallin_nodes_count[d - 2],
                    P,
                    K,
                )
                la.inner_nodes[d] = np.zeros(ishape, dtype=np.float32)
                la.inner_nodes_p1[d] = np.zeros(ishape[:3] + (1, K), dtype=np.float32)
                la.swap_data[d] = la.inner_nodes[d].swapaxes(1, 2).copy()

    def _set_datastructures_from_tree_dfs(
        self, node: Node, layer: int, action_id: int, parent_id: int, gp_id: int
    ) -> None:
        la = self.la
        ai, pi, gi = action_id - 1, parent_id - 1, gp_id - 1
        la.pot_size[layer][ai, pi, gi, :, :] = node.pot
        node.lookahead_coordinates = np.array([action_id, parent_id, gp_id], dtype=np.int64)

        if node.current_player == CHANCE and parent_id > la.nonallinbets_count[layer - 2]:
            raise AssertionError("transition call cannot be all-in call")

        if layer >= la.depth + 1:
            return

        gp_nonallin = la.nonallinbets_count[layer - 2]
        prev_terminal = la.terminal_actions_count[layer - 1]
        next_parent_id = action_id - prev_terminal
        next_gp_id = (gp_id - 1) * gp_nonallin + parent_id

        if node.terminal or node.current_player == CHANCE:
            return
        if parent_id > la.nonallinbets_count[layer - 2]:
            raise AssertionError("parent is an all-in raise")

        if len(node.children) < la.actions_count[layer]:
            if layer <= 1:
                raise AssertionError("root cannot have padded actions")
            terminal_count = la.terminal_actions_count[layer]
            if terminal_count != 2:
                raise AssertionError("padded node expected two terminal actions")
            existing_bets = len(node.children) - terminal_count
            if existing_bets == 0 and action_id != la.actions_count[layer - 1]:
                raise AssertionError("all-in node must be last action")

            for child_id in range(1, terminal_count + 1):
                self._set_datastructures_from_tree_dfs(
                    node.children[child_id - 1], layer + 1, child_id, next_parent_id, next_gp_id
                )
            for b in range(1, existing_bets + 1):
                child = node.children[len(node.children) - b]
                padded_action = la.actions_count[layer] - b + 1
                self._set_datastructures_from_tree_dfs(
                    child, layer + 1, padded_action, next_parent_id, next_gp_id
                )

            mask = la.empty_action_mask[layer + 1]
            assert mask is not None
            start = terminal_count
            stop = la.actions_count[layer] - existing_bets
            if start < stop:
                mask[start:stop, next_parent_id - 1, next_gp_id - 1, :] = 0.0
        else:
            for child_id, child in enumerate(node.children, start=1):
                self._set_datastructures_from_tree_dfs(
                    child, layer + 1, child_id, next_parent_id, next_gp_id
                )
