from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from .torch7_blas import mm as torch7_mm

from .config import Config
from .cfrd_gadget import CFRDGadget
from .lookahead_builder import LookaheadBuilder, LookaheadData
from .next_round_value import NextRoundValue
from .terminal import TerminalEquity
from .tree import Node


@dataclass
class LookaheadResults:
    strategy: np.ndarray
    achieved_cfvs: np.ndarray
    children_cfvs: np.ndarray
    root_cfvs: np.ndarray | None = None
    root_cfvs_both_players: np.ndarray | None = None


class Lookahead:
    """Tensor-for-tensor port of ``Source/Lookahead/lookahead.lua``.

    Layer dictionaries retain the Lua depth keys (1-based). Every tensor axis
    has the same meaning and order as the corresponding Torch7 tensor. NumPy
    indexing is 0-based, but no tree-recursive substitute is used in the CFR
    computation.
    """

    def __init__(self, cfg: Config = Config(), value_network=None) -> None:
        self.cfg = cfg
        # Source fidelity (lookahead_builder.lua:35): the default network is
        # the real checkpoint, resolved lazily when a street-1 tree builds
        # its next-street boxes. No implicit mock fallback (M4).
        self.value_network = value_network
        self.layout: LookaheadData | None = None
        self.tree: Node | None = None
        self.reconstruction_gadget: CFRDGadget | None = None
        self.reconstruction_opponent_cfvs: np.ndarray | None = None
        self.next_street_boxes: dict[int, NextRoundValue] = {}
        self.next_street_boxes_inputs: dict[int, np.ndarray] = {}
        self.next_street_boxes_outputs: dict[int, np.ndarray] = {}
        self.trace_callback = None

    def build_lookahead(self, tree: Node) -> None:
        self.tree = tree
        self.layout = LookaheadBuilder(self.cfg).build_from_tree(tree)
        self.terminal_equity = TerminalEquity(tree.board)
        self._bind_layout_fields()
        self._construct_transition_boxes()

    def _bind_layout_fields(self) -> None:
        assert self.layout is not None
        # Preserve the field names of the Lua object so differential tests can
        # inspect each intermediate tensor directly.
        for name in self.layout.__dataclass_fields__:
            setattr(self, name, getattr(self.layout, name))

    def _construct_transition_boxes(self) -> None:
        assert self.tree is not None
        if self.tree.street == 2:
            return
        if self.value_network is None:
            # Lua: neural_net = neural_net or ValueNn()  (lookahead_builder.lua:35)
            from .value_model import load_original_value_net

            self.value_network = load_original_value_net()
        for d in range(2, self.depth + 1):
            box = NextRoundValue(self.value_network, self.cfg)
            # Lua: pot_size[d][{2, {}, {}, 1, 1}]:clone():view(-1)
            pots = self.pot_size[d][1, :, :, 0, 0].copy().reshape(-1)
            box.start_computation(pots)
            self.next_street_boxes[d] = box

    def resolve_first_node(self, player_range: np.ndarray, opponent_range: np.ndarray) -> None:
        self._require_built()
        self.reconstruction_gadget = None
        self.reconstruction_opponent_cfvs = None
        self.ranges_data[1][..., 0, :] = np.asarray(player_range, dtype=np.float32)
        self.ranges_data[1][..., 1, :] = np.asarray(opponent_range, dtype=np.float32)
        self._compute()

    def resolve(self, player_range: np.ndarray, opponent_cfvs: np.ndarray) -> None:
        self._require_built()
        assert self.tree is not None
        player = np.asarray(player_range, dtype=np.float32)
        opp_cfvs = np.asarray(opponent_cfvs, dtype=np.float32)
        self.reconstruction_gadget = CFRDGadget(self.tree.board, player, opp_cfvs, self.cfg)
        self.ranges_data[1][..., 0, :] = player
        self.reconstruction_opponent_cfvs = opp_cfvs.copy()
        self._compute()

    def _require_built(self) -> None:
        if self.layout is None or self.tree is None:
            raise RuntimeError("build_lookahead() must be called first")

    def _compute(self) -> None:
        for iteration in range(1, self.cfg.cfr_iters + 1):
            self._set_opponent_starting_range(iteration)
            self._emit_trace("opponent_range", iteration)
            self._compute_current_strategies()
            self._emit_trace("current_strategy", iteration)
            self._compute_ranges()
            self._emit_trace("ranges", iteration)
            self._compute_update_average_strategies(iteration)
            self._emit_trace("average_strategy", iteration)
            self._compute_terminal_equities()
            self._emit_trace("terminal_cfvs", iteration)
            self._compute_cfvs()
            self._emit_trace("current_cfvs", iteration)
            self._compute_regrets()
            self._emit_trace("regrets", iteration)
            self._compute_cumulate_average_cfvs(iteration)
            self._emit_trace("average_cfvs", iteration)
        self._compute_normalize_average_strategies()
        self._compute_normalize_average_cfvs()

    def _emit_trace(self, stage: str, iteration: int) -> None:
        callback = self.trace_callback
        if callback is not None:
            callback(self, stage, iteration)

    def _compute_current_strategies(self) -> None:
        for d in range(2, self.depth + 1):
            regrets = self.regrets_data[d]
            positive = self.positive_regrets_data[d]
            mask = self.empty_action_mask[d]
            strategy = self.current_strategy_data[d]
            assert regrets is not None and positive is not None and mask is not None and strategy is not None
            np.copyto(positive, regrets)
            # Lua: clamp(regret_epsilon, tools:max_number()) with
            # tools.lua:29-31 max_number() = 999999 (lookahead.lua:91)
            np.clip(positive, self.regret_epsilon, 999999.0, out=positive)
            positive *= mask
            summed = positive.sum(axis=0, keepdims=True, dtype=np.float32)
            # torch.sum(output, input, dim) resizes ``output``. regrets_sum is
            # deliberately reused later with a different rank in the Lua code.
            self.regrets_sum[d] = summed.copy()
            np.divide(positive, np.broadcast_to(self.regrets_sum[d], positive.shape), out=strategy)

    def _compute_ranges(self) -> None:
        for d in range(1, self.depth):
            current = self.ranges_data[d]
            nxt = self.ranges_data[d + 1]
            prev_terminal = self.terminal_actions_count[d - 1]
            prev_bets = self.bets_count[d - 1]
            gp_nonallin = self.nonallinbets_count[d - 2]

            selected = current[prev_terminal:, :gp_nonallin, ...].swapaxes(1, 2)
            inner = self.inner_nodes[d]
            inner.reshape(-1)[:] = selected.reshape(-1)
            super_view = inner.reshape(1, prev_bets, -1, 2, self.cfg.card_count)
            np.copyto(nxt, np.broadcast_to(super_view, nxt.shape))

            strategy = self.current_strategy_data[d + 1]
            assert strategy is not None and self.acting_player is not None
            acting = int(self.acting_player[d - 1]) - 1
            nxt[..., acting, :] *= strategy

    def _compute_update_average_strategies(self, iteration: int) -> None:
        if iteration > self.cfg.cfr_skip_iters:
            assert self.average_strategies_data[2] is not None
            assert self.current_strategy_data[2] is not None
            self.average_strategies_data[2] += self.current_strategy_data[2]

    def _compute_terminal_equities_terminal_equity(self) -> None:
        assert self.tree is not None and self.acting_player is not None
        for d in range(2, self.depth + 1):
            if self.tree.street == 1:
                if d > 2 or self.first_call_terminal:
                    r = self.ranges_data[d][1, -1, ...].reshape(-1, self.cfg.card_count)
                    out = self.cfvs_data[d][1, -1, ...].reshape(-1, self.cfg.card_count)
                    out[:] = torch7_mm(r, self.terminal_equity.call_matrix)
            else:
                if d > 2 or self.first_call_terminal:
                    r = self.ranges_data[d][1, ...].reshape(-1, self.cfg.card_count)
                    out = self.cfvs_data[d][1, ...].reshape(-1, self.cfg.card_count)
                    out[:] = torch7_mm(r, self.terminal_equity.call_matrix)

            r = self.ranges_data[d][0, ...].reshape(-1, self.cfg.card_count)
            out = self.cfvs_data[d][0, ...].reshape(-1, self.cfg.card_count)
            out[:] = torch7_mm(r, self.terminal_equity.fold_matrix)
            fold_multiplier = int(self.acting_player[d - 1]) * 2 - 3
            self.cfvs_data[d][0, ..., 0, :] *= fold_multiplier
            self.cfvs_data[d][0, ..., 1, :] *= -fold_multiplier

    def _compute_terminal_equities_next_street_box(self) -> None:
        assert self.tree is not None and self.tree.street == 1
        for d in range(2, self.depth + 1):
            if not (d > 2 or self.first_call_transition):
                continue
            raw = self.ranges_data[d][1, ...]
            batch = raw.reshape(-1, 2, self.cfg.card_count)
            inputs = self.next_street_boxes_inputs.get(d)
            outputs = self.next_street_boxes_outputs.get(d)
            if inputs is None:
                inputs = np.zeros_like(batch, dtype=np.float32)
                outputs = np.zeros_like(batch, dtype=np.float32)
                self.next_street_boxes_inputs[d] = inputs
                self.next_street_boxes_outputs[d] = outputs
            assert outputs is not None
            outputs[:] = batch
            if self.tree.current_player == 0:
                inputs[:] = outputs
            else:
                inputs[:, 0, :] = outputs[:, 1, :]
                inputs[:, 1, :] = outputs[:, 0, :]
            self.next_street_boxes[d].get_value(inputs, outputs)
            if self.tree.current_player == 0:
                inputs[:] = outputs
                outputs[:, 0, :] = inputs[:, 1, :]
                outputs[:, 1, :] = inputs[:, 0, :]
            self.cfvs_data[d][1, ...] = outputs.reshape(raw.shape)

    def _compute_terminal_equities(self) -> None:
        assert self.tree is not None
        if self.tree.street == 1:
            self._compute_terminal_equities_next_street_box()
        self._compute_terminal_equities_terminal_equity()
        for d in range(2, self.depth + 1):
            self.cfvs_data[d] *= self.pot_size[d]

    def _compute_cfvs(self) -> None:
        assert self.acting_player is not None
        for d in range(self.depth, 1, -1):
            gp_terminal = self.terminal_actions_count[d - 2]
            ggp_nonallin = self.nonallinbets_count[d - 3]
            mask = self.empty_action_mask[d]
            strategy = self.current_strategy_data[d]
            assert mask is not None and strategy is not None
            self.cfvs_data[d][..., 0, :] *= mask
            self.cfvs_data[d][..., 1, :] *= mask
            self.placeholder_data[d][:] = self.cfvs_data[d]
            acting = int(self.acting_player[d - 1]) - 1
            self.placeholder_data[d][..., acting, :] *= strategy
            summed = self.placeholder_data[d].sum(axis=0, keepdims=True, dtype=np.float32)
            self.regrets_sum[d] = summed.copy()
            swap = self.swap_data[d - 1]
            swap.reshape(-1)[:] = self.regrets_sum[d].reshape(-1)
            target = self.cfvs_data[d - 1][gp_terminal:, :ggp_nonallin, ...]
            target[:] = swap.swapaxes(1, 2)

    def _compute_cumulate_average_cfvs(self, iteration: int) -> None:
        if iteration > self.cfg.cfr_skip_iters:
            self.average_cfvs_data[1] += self.cfvs_data[1]
            self.average_cfvs_data[2] += self.cfvs_data[2]

    def _compute_normalize_average_strategies(self) -> None:
        avg = self.average_strategies_data[2]
        assert avg is not None
        summed = avg.sum(axis=0, keepdims=True, dtype=np.float32)
        self.regrets_sum[2] = summed.copy()
        with np.errstate(divide="ignore", invalid="ignore"):
            avg[:] = avg / np.broadcast_to(self.regrets_sum[2], avg.shape)
        # Exact Lua NaN fallback: first action becomes 1, every other NaN 0.
        first_nan = np.isnan(avg[0])
        avg[0][first_nan] = 1.0
        avg[np.isnan(avg)] = 0.0

    def _compute_normalize_average_cfvs(self) -> None:
        self.average_cfvs_data[1] /= np.float32(
            self.cfg.cfr_iters - self.cfg.cfr_skip_iters
        )

    def _compute_regrets(self) -> None:
        assert self.acting_player is not None
        for d in range(self.depth, 1, -1):
            gp_terminal = self.terminal_actions_count[d - 2]
            gp_bets = self.bets_count[d - 2]
            ggp_nonallin = self.nonallinbets_count[d - 3]
            current = self.current_regrets_data[d]
            total = self.regrets_data[d]
            assert current is not None and total is not None
            acting = int(self.acting_player[d - 1]) - 1
            current[:] = self.cfvs_data[d][..., acting, :]
            selected = self.cfvs_data[d - 1][
                gp_terminal:, :ggp_nonallin, ..., acting, :
            ].swapaxes(1, 2)
            parent = self.inner_nodes_p1[d - 1]
            parent.reshape(-1)[:] = selected.reshape(-1)
            parent_view = parent.reshape(1, gp_bets, -1, self.cfg.card_count)
            current -= np.broadcast_to(parent_view, current.shape)
            total += current
            # Lua CFR+ clamp: regrets_data[d]:clamp(0, tools:max_number())
            # = clamp(0, 999999)  (lookahead.lua:381, tools.lua:29-31)
            np.clip(total, 0.0, 999999.0, out=total)

    def _set_opponent_starting_range(self, iteration: int) -> None:
        if self.reconstruction_opponent_cfvs is None:
            return
        assert self.reconstruction_gadget is not None
        current = self.cfvs_data[1][..., 0, :].reshape(self.cfg.card_count)
        opponent_range = self.reconstruction_gadget.compute_opponent_range(current, iteration)
        self.ranges_data[1][..., 1, :] = np.asarray(opponent_range, dtype=np.float32)

    def get_results(self) -> LookaheadResults:
        self._require_built()
        avg_strategy = self.average_strategies_data[2]
        assert avg_strategy is not None
        strategy = avg_strategy.reshape(-1, self.cfg.card_count).copy()
        root = self.average_cfvs_data[1].reshape(2, self.cfg.card_count)
        achieved = root[0].copy()
        root_cfvs = None
        both = None
        if self.reconstruction_opponent_cfvs is None:
            root_cfvs = root[1].copy()
            both = root[[1, 0]].copy()
        children = self.average_cfvs_data[2][..., 0, :].reshape(-1, self.cfg.card_count).copy()
        scaler = strategy.copy()
        range_mul = self.ranges_data[1][..., 0, :].reshape(1, self.cfg.card_count)
        scaler *= np.broadcast_to(range_mul, scaler.shape)
        # Torch7 FloatTensor:sum(2) uses double accreal, then stores float32.
        action_reach = np.empty((scaler.shape[0], 1), dtype=np.float32)
        for row in range(scaler.shape[0]):
            acc = 0.0
            for col in range(scaler.shape[1]):
                acc += float(scaler[row, col])
            action_reach[row, 0] = np.float32(acc)
        divisor = np.broadcast_to(action_reach, scaler.shape).copy()
        divisor *= np.float32(self.cfg.cfr_iters - self.cfg.cfr_skip_iters)
        with np.errstate(divide="ignore", invalid="ignore"):
            children /= divisor
        return LookaheadResults(strategy, achieved, children, root_cfvs, both)

    def get_chance_action_cfv(self, action_index: int, board: tuple[int, ...]) -> np.ndarray:
        """Exact port; ``action_index`` remains zero-based at the Python API."""
        self._require_built()
        assert self.tree is not None
        lua_action = action_index + 1
        if lua_action == 2 and self.first_call_terminal:
            raise AssertionError("terminal call has no chance CFV")
        if lua_action == 2 and self.first_call_transition:
            box_outputs = np.zeros_like(self.next_street_boxes_inputs[2])
            if box_outputs.shape[0] != 1:
                raise AssertionError("root transition call must have batch size one")
            batch_index = 0
            box = self.next_street_boxes[2]
            pot_mult = self.pot_size[2][1, ...].reshape(-1, 2, self.cfg.card_count)
        else:
            batch_index = lua_action - 2  # remove fold and convert to zero-based
            if self.first_call_transition:
                batch_index -= 1
            box_outputs = np.zeros_like(self.next_street_boxes_inputs[3])
            box = self.next_street_boxes[3]
            pot_mult = self.pot_size[3][1, ...].reshape(-1, 2, self.cfg.card_count)
        box.get_value_on_board(board, box_outputs)
        box_outputs *= pot_mult
        return box_outputs[batch_index, 1 - self.tree.current_player].copy()
