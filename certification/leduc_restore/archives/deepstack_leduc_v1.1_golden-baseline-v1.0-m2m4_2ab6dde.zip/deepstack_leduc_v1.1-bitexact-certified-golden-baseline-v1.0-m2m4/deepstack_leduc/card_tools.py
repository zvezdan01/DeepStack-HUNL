from __future__ import annotations

from math import comb
from typing import Iterable

import numpy as np

from .config import Config


def _board_tuple(board: Iterable[int] | tuple[int, ...]) -> tuple[int, ...]:
    return tuple(int(c) for c in board)


def hand_is_possible(hand: Iterable[int], config: Config = Config()) -> bool:
    cards = tuple(int(c) for c in hand)
    if not cards:
        return True
    if min(cards) < 0 or max(cards) >= config.card_count:
        raise ValueError("Illegal cards in hand")
    return len(set(cards)) == len(cards)


def possible_hand_indexes(board: Iterable[int], config: Config = Config()) -> np.ndarray:
    board_t = _board_tuple(board)
    if not hand_is_possible(board_t, config):
        raise ValueError("Board contains illegal or repeated cards")
    out = np.ones(config.card_count, dtype=np.float64)
    for card in board_t:
        out[card] = 0.0
    return out


def impossible_hand_indexes(board: Iterable[int], config: Config = Config()) -> np.ndarray:
    return 1.0 - possible_hand_indexes(board, config)


def uniform_range(board: Iterable[int], config: Config = Config()) -> np.ndarray:
    out = possible_hand_indexes(board, config)
    return out / out.sum()


def random_range(
    board: Iterable[int], seed: int | None = None, config: Config = Config()
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    out = rng.random(config.card_count) * possible_hand_indexes(board, config)
    total = out.sum()
    return out if total == 0 else out / total


def is_valid_range(values: np.ndarray, board: Iterable[int], config: Config = Config()) -> bool:
    arr = np.asarray(values, dtype=np.float64)
    if arr.shape != (config.card_count,):
        return False
    impossible_mass = float(np.dot(arr, impossible_hand_indexes(board, config)))
    return impossible_mass == 0.0 and abs(float(arr.sum()) - 1.0) < 1e-4


def board_to_street(board: Iterable[int]) -> int:
    return 1 if len(_board_tuple(board)) == 0 else 2


def boards_count(config: Config = Config()) -> int:
    return comb(config.card_count, config.board_card_count)


def second_round_boards(config: Config = Config()) -> np.ndarray:
    if config.board_card_count == 1:
        return np.arange(config.card_count, dtype=np.int64).reshape(-1, 1)
    if config.board_card_count == 2:
        rows: list[tuple[int, int]] = []
        for c1 in range(config.card_count):
            for c2 in range(c1 + 1, config.card_count):
                rows.append((c1, c2))
        return np.asarray(rows, dtype=np.int64)
    raise NotImplementedError("unsupported board size")


def board_index(board: Iterable[int], config: Config = Config()) -> int:
    """Zero-based equivalent of Lua card_tools:get_board_index()."""
    board_t = _board_tuple(board)
    if len(board_t) != config.board_card_count:
        raise ValueError("Board must contain exactly board_card_count cards")
    if not hand_is_possible(board_t, config):
        raise ValueError("Invalid board")
    if config.board_card_count == 1:
        return board_t[0]
    ordered = tuple(sorted(board_t))
    for idx, row in enumerate(second_round_boards(config)):
        if tuple(int(x) for x in row) == ordered:
            return idx
    raise ValueError("Unknown board")


def normalize_range(board: Iterable[int], values: np.ndarray, config: Config = Config()) -> np.ndarray:
    # Bit-exact equivalent of Torch7:
    # out = range:clone():cmul(mask)
    # out:div(out:sum())
    out = np.asarray(values, dtype=np.float32).copy()

    if out.shape != (config.card_count,):
        raise ValueError(f"Expected shape {(config.card_count,)}, got {out.shape}")

    mask = possible_hand_indexes(board, config).astype(np.float32)

    for i in range(config.card_count):
        out[i] = np.float32(out[i] * mask[i])

    # Torch7 FloatTensor sum uses double accreal.
    total = 0.0
    for i in range(config.card_count):
        total += float(out[i])

    if total == 0.0:
        return out

    # Lua/Torch binding passes the scalar to THTensor_div as `real`.
    # For FloatTensor, `real` is float32.
    divisor = np.float32(total)

    for i in range(config.card_count):
        out[i] = np.float32(
            np.float32(out[i]) / divisor
        )

    return out

