from __future__ import annotations

from pathlib import Path
from typing import Sequence

import numpy as np
import torch
from .torch7_blas import mm as torch7_mm
from torch import Tensor, nn

from .torch7_model import (
    Torch7ModelError,
    Torch7Object,
    load_torch7_object,
    module_children,
    table_get,
)



def _torch7_exact_inference(model, inputs):
    x = np.ascontiguousarray(inputs, dtype=np.float32)
    out = x.copy()

    for layer in model.feedforward:
        if isinstance(layer, nn.Linear):
            w = np.ascontiguousarray(
                layer.weight.detach().cpu().numpy().astype(np.float32).T
            )
            b = layer.bias.detach().cpu().numpy().astype(np.float32)

            out = torch7_mm(
                np.ascontiguousarray(out, dtype=np.float32),
                w,
            )

            for r in range(out.shape[0]):
                for c in range(out.shape[1]):
                    out[r, c] = np.float32(out[r, c] + b[c])

        elif isinstance(layer, nn.PReLU):
            with torch.no_grad():
                out = layer(
                    torch.from_numpy(np.ascontiguousarray(out, dtype=np.float32))
                ).cpu().numpy().astype(np.float32)

        else:
            raise RuntimeError(type(layer).__name__)

    raw = out.copy()
    ranges = x[:, :model.output_size]
    result = raw.copy()

    for r in range(raw.shape[0]):
        dot = 0.0
        for c in range(model.output_size):
            prod = np.float32(raw[r, c] * ranges[r, c])
            dot += float(prod)

        dot32 = np.float32(dot)
        corr = np.float32(dot32 * np.float32(-0.5))

        for c in range(model.output_size):
            result[r, c] = np.float32(raw[r, c] + corr)

    return result


class DeepStackValueNet(nn.Module):
    """PyTorch equivalent of the exact network stored in final_cpu.model.

    The uploaded reference checkpoint contains six Linear layers and five
    scalar PReLU layers:

      73 -> 50 -> 50 -> 50 -> 50 -> 50 -> 72

    The feed-forward output then passes through the same range-weighted
    zero-sum correction graph built by ``Source/Nn/net_builder.lua``.
    """

    def __init__(
        self,
        bucket_count: int = 36,
        layer_sizes: Sequence[int] = (73, 50, 50, 50, 50, 50, 72),
    ) -> None:
        super().__init__()
        self.bucket_count = int(bucket_count)
        self.output_size = 2 * self.bucket_count
        self.input_size = self.output_size + 1
        sizes = tuple(int(x) for x in layer_sizes)
        if sizes[0] != self.input_size or sizes[-1] != self.output_size:
            raise ValueError(
                f"layer sizes must start at {self.input_size} and end at {self.output_size}"
            )
        layers: list[nn.Module] = []
        for i, (in_features, out_features) in enumerate(zip(sizes, sizes[1:])):
            layers.append(nn.Linear(in_features, out_features))
            if i != len(sizes) - 2:
                layers.append(nn.PReLU(num_parameters=1))
        self.feedforward = nn.Sequential(*layers)

    def forward(self, inputs: Tensor) -> Tensor:
        if inputs.ndim != 2 or inputs.shape[1] != self.input_size:
            raise ValueError(
                f"inputs must have shape [N,{self.input_size}], got {tuple(inputs.shape)}"
            )
        raw = self.feedforward(inputs)
        ranges = inputs[:, : self.output_size]
        correction = -0.5 * torch.sum(raw * ranges, dim=1, keepdim=True)
        return raw + correction.expand_as(raw)

    @torch.no_grad()
    def get_value(self, inputs, outputs=None):
        result = _torch7_exact_inference(self, inputs)
        if outputs is not None:
            outputs[...] = result
            return outputs
        return result

    @classmethod
    def from_torch7(cls, path: str | Path) -> "DeepStackValueNet":
        root = load_torch7_object(path)
        if not isinstance(root, Torch7Object) or root.class_name != "nn.Sequential":
            raise Torch7ModelError("checkpoint root is not nn.Sequential")

        root_modules = module_children(root)
        if len(root_modules) < 1 or root_modules[0].class_name != "nn.ConcatTable":
            raise Torch7ModelError("unexpected DeepStack network graph")
        first_concat = root_modules[0]
        concat_children = module_children(first_concat)
        if len(concat_children) != 2 or concat_children[0].class_name != "nn.Sequential":
            raise Torch7ModelError("feed-forward branch not found")
        torch_modules = module_children(concat_children[0])

        linear_modules = [m for m in torch_modules if m.class_name == "nn.Linear"]
        prelu_modules = [m for m in torch_modules if m.class_name == "nn.PReLU"]
        if len(linear_modules) != len(prelu_modules) + 1:
            raise Torch7ModelError("unexpected Linear/PReLU sequence")

        sizes: list[int] = []
        for i, module in enumerate(linear_modules):
            weight = table_get(module, "weight")
            bias = table_get(module, "bias")
            if not isinstance(weight, Torch7Object) or not isinstance(weight.data, np.ndarray):
                raise Torch7ModelError("Linear weight tensor missing")
            if not isinstance(bias, Torch7Object) or not isinstance(bias.data, np.ndarray):
                raise Torch7ModelError("Linear bias tensor missing")
            if weight.data.ndim != 2 or bias.data.shape != (weight.data.shape[0],):
                raise Torch7ModelError("invalid Linear tensor shapes")
            if i == 0:
                sizes.append(int(weight.data.shape[1]))
            elif sizes[-1] != int(weight.data.shape[1]):
                raise Torch7ModelError("disconnected Linear dimensions")
            sizes.append(int(weight.data.shape[0]))

        model = cls(layer_sizes=sizes).float()
        py_linears = [m for m in model.feedforward if isinstance(m, nn.Linear)]
        py_prelus = [m for m in model.feedforward if isinstance(m, nn.PReLU)]
        with torch.no_grad():
            for target, source in zip(py_linears, linear_modules):
                target.weight.copy_(torch.from_numpy(table_get(source, "weight").data))
                target.bias.copy_(torch.from_numpy(table_get(source, "bias").data))
            for target, source in zip(py_prelus, prelu_modules):
                weight = table_get(source, "weight")
                if not isinstance(weight, Torch7Object) or not isinstance(weight.data, np.ndarray):
                    raise Torch7ModelError("PReLU weight tensor missing")
                target.weight.copy_(torch.from_numpy(weight.data.reshape(1)))
        model.eval()
        return model


def bundled_model_path() -> Path:
    return Path(__file__).resolve().parent / "models" / "final_cpu.model"


def load_original_value_net(path: str | Path | None = None) -> DeepStackValueNet:
    model_path = Path(path) if path is not None else bundled_model_path()
    if not model_path.exists():
        raise FileNotFoundError(f"original DeepStack model not found: {model_path}")
    return DeepStackValueNet.from_torch7(model_path)
