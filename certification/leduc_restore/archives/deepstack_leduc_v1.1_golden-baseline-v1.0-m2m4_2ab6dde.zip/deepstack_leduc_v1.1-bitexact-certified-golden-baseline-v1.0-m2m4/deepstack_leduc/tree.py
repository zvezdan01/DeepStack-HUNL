from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
from .config import Config
from .cards import possible_mask

FOLD = -2
CALL = -1
CHANCE = -1

@dataclass
class Node:
    street: int
    current_player: int  # 0/1 or CHANCE encoded as -1 internally
    bets: np.ndarray
    board: tuple[int, ...] = ()
    terminal: bool = False
    terminal_type: str | None = None
    children: list["Node"] = field(default_factory=list)
    actions: list[int] = field(default_factory=list)
    strategy: np.ndarray | None = None
    regrets: np.ndarray | None = None
    avg_weight_sum: np.ndarray | None = None
    ranges_absolute: np.ndarray | None = None
    cf_values: np.ndarray | None = None
    depth: int = 1

    @property
    def pot(self) -> float:
        return float(np.min(self.bets))

class BetSizing:
    def __init__(self, cfg: Config): self.cfg = cfg
    def possible_bets(self, node: Node) -> list[np.ndarray]:
        p = node.current_player
        o = 1-p
        opponent_bet = float(node.bets[o])
        max_raise = self.cfg.stack - opponent_bet
        min_raise = max(opponent_bet - float(node.bets[p]), self.cfg.ante)
        min_raise = min(max_raise, min_raise)
        if min_raise == 0: return []
        if min_raise == max_raise:
            b = np.array([opponent_bet, opponent_bet], dtype=float)
            b[p] = opponent_bet + min_raise
            return [b]
        pot = opponent_bet * 2
        out: list[np.ndarray] = []
        seen: set[tuple[float,float]] = set()
        for frac in self.cfg.bet_fractions:
            raise_size = pot * frac
            if raise_size >= min_raise and raise_size < max_raise:
                b = np.array([opponent_bet, opponent_bet], dtype=float)
                b[p] = opponent_bet + raise_size
                key = tuple(b)
                if key not in seen: out.append(b); seen.add(key)
        b = np.array([opponent_bet, opponent_bet], dtype=float)
        b[p] = opponent_bet + max_raise
        if tuple(b) not in seen: out.append(b)
        return out

class PokerTreeBuilder:
    def __init__(self, cfg: Config = Config()):
        self.cfg = cfg
        self.bet_sizing = BetSizing(cfg)

    def build_tree(self, root: Node | None = None, limit_to_street: bool = False) -> Node:
        if root is None:
            root = Node(1, 0, np.array([self.cfg.ante, self.cfg.ante], dtype=float), ())
        self.limit_to_street = limit_to_street
        self._build(root)
        self._fill_uniform(root)
        return root

    def _build(self, node: Node) -> None:
        if node.terminal:
            node.depth = 1; return
        if node.current_player == -1:
            if self.limit_to_street:
                node.children=[]; node.actions=[]; node.depth=1; return
            node.children = [Node(node.street+1, 0, node.bets.copy(), (b,)) for b in range(6)]
            node.actions = list(range(6))
        else:
            p=node.current_player
            children: list[Node]=[]; actions: list[int]=[]
            # fold is always included exactly as in original tree_builder.
            children.append(Node(node.street, 1-p, node.bets.copy(), node.board, True, "fold")); actions.append(FOLD)
            equal = node.bets[0] == node.bets[1]
            if p == 0 and equal:
                children.append(Node(node.street, 1, node.bets.copy(), node.board)); actions.append(CALL)
            elif node.street == 1 and ((p == 1 and equal) or ((not equal) and np.max(node.bets) < self.cfg.stack)):
                children.append(Node(node.street, -1, np.full(2, np.max(node.bets)), node.board)); actions.append(CALL)
            else:
                children.append(Node(node.street, 1-p, np.full(2, np.max(node.bets)), node.board, True, "call")); actions.append(CALL)
            for b in self.bet_sizing.possible_bets(node):
                children.append(Node(node.street, 1-p, b, node.board)); actions.append(int(np.max(b)))
            node.children, node.actions = children, actions
        maxd=0
        for c in node.children:
            self._build(c); maxd=max(maxd,c.depth)
        node.depth=maxd+1

    def _fill_uniform(self, node: Node) -> None:
        if node.terminal: return
        n=len(node.children)
        if node.current_player == -1:
            st=np.zeros((n,6), dtype=float)
            for i,c in enumerate(node.children):
                st[i] = possible_mask(c.board) / 4.0
            node.strategy=st
        else:
            node.strategy=np.full((n,6), 1.0/n, dtype=float)
        for c in node.children: self._fill_uniform(c)

    @staticmethod
    def count_nodes(root: Node) -> int:
        return 1 + sum(PokerTreeBuilder.count_nodes(c) for c in root.children)
