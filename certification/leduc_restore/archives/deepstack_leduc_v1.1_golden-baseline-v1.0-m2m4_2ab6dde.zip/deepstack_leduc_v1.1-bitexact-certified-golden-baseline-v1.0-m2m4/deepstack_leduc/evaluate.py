from __future__ import annotations
import numpy as np
from .tree import Node
from .terminal import TerminalEquity

class StrategyEvaluator:
    def __init__(self): self.cache={}
    def terminal(self,b):
        if b not in self.cache:self.cache[b]=TerminalEquity(b)
        return self.cache[b]
    def value(self,node:Node,ranges:np.ndarray)->np.ndarray:
        if node.terminal:
            te=self.terminal(node.board)
            if node.terminal_type=='fold': v=te.fold_values(ranges,1-node.current_player)
            else:v=te.call_values(ranges)
            return v*node.pot
        assert node.strategy is not None
        vals=np.zeros((2,6))
        for i,ch in enumerate(node.children):
            cr=ranges.copy()
            if node.current_player==-1:
                cr[0]*=node.strategy[i];cr[1]*=node.strategy[i]
                vals += self.value(ch,cr)
            else:
                cr[node.current_player]*=node.strategy[i]
                cv=self.value(ch,cr)
                p=node.current_player;o=1-p
                vals[p]+=node.strategy[i]*cv[p]
                vals[o]+=cv[o]
        return vals
