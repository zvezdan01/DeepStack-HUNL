from __future__ import annotations

import numpy as np

from .bucketing import Bucketer
from .terminal import TerminalEquity


class MockNNTerminal:
    """Exact Python port of ``Source/Nn/mock_nn_terminal.lua``.

    It exposes the same value-network interface but evaluates terminal
    showdown equity exactly in the 36-bucket space.
    """

    def __init__(self) -> None:
        self.bucketer = Bucketer()
        self.bucket_count = self.bucketer.get_bucket_count()
        self.board_count = 6
        self.equity_matrix = np.zeros(
            (self.bucket_count, self.bucket_count), dtype=np.float64
        )

        terminal = TerminalEquity()
        for board_card in range(self.board_count):
            board = (board_card,)
            terminal.set_board(board)
            call_matrix = terminal.call_matrix
            buckets = self.bucketer.compute_buckets(board)
            for c1 in range(6):
                for c2 in range(6):
                    b1 = int(buckets[c1])
                    b2 = int(buckets[c2])
                    if b1 >= 0 and b2 >= 0:
                        self.equity_matrix[b1, b2] = call_matrix[c1, c2]

    def get_value(self, inputs: np.ndarray, outputs: np.ndarray | None = None) -> np.ndarray:
        inputs = np.asarray(inputs, dtype=np.float64)
        if inputs.ndim != 2 or inputs.shape[1] != 2 * self.bucket_count + 1:
            raise ValueError(
                f"inputs must have shape [N,{2 * self.bucket_count + 1}], got {inputs.shape}"
            )
        if outputs is None:
            outputs = np.zeros((inputs.shape[0], 2 * self.bucket_count), dtype=np.float64)
        elif outputs.shape != (inputs.shape[0], 2 * self.bucket_count):
            raise ValueError("outputs has incorrect shape")

        p1 = slice(0, self.bucket_count)
        p2 = slice(self.bucket_count, 2 * self.bucket_count)
        outputs[:, p1] = inputs[:, p2] @ self.equity_matrix
        outputs[:, p2] = inputs[:, p1] @ self.equity_matrix
        return outputs
