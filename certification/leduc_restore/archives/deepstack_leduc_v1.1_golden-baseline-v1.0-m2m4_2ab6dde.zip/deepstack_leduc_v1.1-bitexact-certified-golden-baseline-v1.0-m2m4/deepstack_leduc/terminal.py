from __future__ import annotations
import numpy as np
from .cards import possible_mask, hand_strength
from .torch7_blas import mm as torch7_mm


class TerminalEquity:
    def __init__(self, board: tuple[int, ...] = ()) -> None:
        self.set_board(board)

    def set_board(self, board: tuple[int, ...]) -> None:
        self.board = tuple(board)
        self.fold_matrix = np.ones((6,6), dtype=np.float32) - np.eye(6)
        mask = possible_mask(self.board)
        self.fold_matrix *= mask[:,None] * mask[None,:]
        self.call_matrix = self._call_matrix(self.board)

    def _last_round_call_matrix(self, board: tuple[int, ...]) -> np.ndarray:
        strengths = np.array([hand_strength(i, board) for i in range(6)])
        # Original: +1 where row hand is weaker than col? The Lua matrix is used
        # symmetrically with opposite player ranges. This orientation matches it.
        out = (strengths[:,None] > strengths[None,:]).astype(np.float32)
        out -= (strengths[:,None] < strengths[None,:]).astype(np.float32)
        mask = possible_mask(board)
        out *= mask[:,None] * mask[None,:]
        return out

    def _call_matrix(self, board: tuple[int, ...]) -> np.ndarray:
        if board:
            return self._last_round_call_matrix(board)
        out = np.zeros((6,6), dtype=np.float32)
        for b in range(6):
            out += self._last_round_call_matrix((b,))
        return out / 4.0

    def call_values(self, ranges: np.ndarray) -> np.ndarray:
        ranges = np.asarray(ranges, dtype=np.float32)
        result = np.zeros_like(ranges)
        result[1] = torch7_mm(ranges[0:1], self.call_matrix)[0]
        result[0] = torch7_mm(ranges[1:2], self.call_matrix)[0]
        return result

    def fold_values(self, ranges: np.ndarray, folding_player: int) -> np.ndarray:
        ranges = np.asarray(ranges, dtype=np.float32)
        result = np.zeros_like(ranges)
        result[1] = torch7_mm(ranges[0:1], self.fold_matrix)[0]
        result[0] = torch7_mm(ranges[1:2], self.fold_matrix)[0]
        result[folding_player] *= -1
        return result
