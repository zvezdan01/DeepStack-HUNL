# DeepStack-Leduc Python Port v1.1-bitexact-certified

## Status

This release is a modern Python port of the public DeepStack-Leduc implementation and preserves the original Leduc game semantics and Torch7 numerical behavior for the certified paths below.

## Certified against the original Lua/Torch7 implementation

- One complete CFR iteration: 232/232 captured internal tensors match bit-for-bit (`atol=0`, `rtol=0`).
- Original `final_cpu.model`: feed-forward network and zero-sum correction match bit-for-bit.
- Continual resolving, deterministic first action (`raise 300`): 6/6 checkpoints match bit-for-bit.
- Chance transition to board `Ah` and second-street CFR-D resolve: 16/16 checkpoints match bit-for-bit.
- Terminal showdown equity on the certified deterministic hand: 3/3 tensors match bit-for-bit.
- Deterministic end-to-end regression hand passes:
  `P1 raise 300 -> P2 call -> board Ah -> P1 check -> P2 check -> showdown`.
- Full Python test suite at release time: 36/36 tests pass.

## Numerical compatibility

Bit-exact mode uses the same legacy x86_64 OpenBLAS behavior as the Torch7 reference. The release therefore includes:

- `torch7_openblas.so.0`
- `libopenblas_sandybridgep-r0.3.0.dev.so`
- `libgfortran.so.3`
- `libgfortran.so.3.0.0`

Run tests/programs from the release root with:

```bash
LD_LIBRARY_PATH="$PWD" PYTHONPATH=. python3 -m pytest -q
```

## Scope

This certifies the tested DeepStack-Leduc paths above. It does not claim exhaustive bit-for-bit verification of every possible action history, board, private-card combination, random action sample, or every ACPC branch.

This repository is the public Leduc/extended-Leduc DeepStack implementation. It is not the full heads-up no-limit Texas Hold'em system from the DeepStack paper.

## Reference material retained

The release retains the original Lua implementation, original model/data required by the tests, Lua reference traces, and exporters/comparators used for differential verification.

## Release build

Release directory: `deepstack_leduc_v1.1-bitexact-certified`

Final archive checksum is generated after this file is added to the archive.
