# Tensor-layout correction

This revision removes the recursive lookahead implementation from the active
resolver path and ports `Source/Lookahead/lookahead_builder.lua` and
`Source/Lookahead/lookahead.lua` using the original packed, per-depth tensors.

## Corrected

- Active `Lookahead` now uses `LookaheadBuilder`'s layer dictionaries.
- Tensor axes retain the Torch7 order:
  `[action, parent_action, grandparent_id, player, card]` for ranges/CFVs and
  `[action, parent_action, grandparent_id, card]` for strategies/regrets.
- Padded actions, the final all-in action index, fold masking on a free check,
  and 1-based coordinates stored on public-tree nodes are preserved.
- Range propagation uses the original inner-node transpose/view/expand path.
- CFV back-propagation, regret calculation, CFR+ clamp, root strategy averaging,
  root CFV averaging, and child-CFV scaling follow the Lua operation order.
- The CFR-D starting range is read from the packed root CFV tensor.
- Chance CFV lookup follows the same batch-index branches as Lua.
- Packed lookahead and CFR-D storage uses `float32`, matching `torch.FloatTensor`.
- `torch.sum(output, input, dim)` output-resizing semantics are reproduced; the
  shared `regrets_sum` buffer changes rank exactly where the Lua code does.

## Removed from the active path

The former recursive implementation is retained only as
`lookahead_recursive_reference.py`. It is not imported by `Resolving` and is
not the final implementation.

## Validation performed

- `pytest`: 25 passed.
- `python -m compileall`: passed.
- Preflop packed-lookahead smoke solve: finite 4x6 strategy, each card column
  sums to one, and the free-fold row is zero as required by the Lua builder.

## Remaining verification boundary

The container does not have Torch7/`th`, so this revision has not yet run a
live tensor-by-tensor differential execution against the Lua runtime. The
source-level layout and operation order are now ported, but numerical identity
must still be confirmed with a Torch7 oracle before calling the complete Python
bot fully reference-verified.
