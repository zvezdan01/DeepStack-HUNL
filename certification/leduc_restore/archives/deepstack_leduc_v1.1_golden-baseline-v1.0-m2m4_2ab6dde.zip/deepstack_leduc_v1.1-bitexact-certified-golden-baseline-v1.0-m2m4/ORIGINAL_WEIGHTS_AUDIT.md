# Original Torch7 weights integration audit

## Integrated files

- `deepstack_leduc/models/final_cpu.model`
- `deepstack_leduc/models/final_cpu.info`

The files are copied byte-for-byte from the original `DeepStack-Leduc-master`
archive. The CPU checkpoint is loaded directly; it is not retrained and is not
converted through an approximate interchange format.

## Actual architecture discovered in the checkpoint

The serialized model is authoritative and contains:

```
Linear(73, 50)
PReLU(1)
Linear(50, 50)
PReLU(1)
Linear(50, 50)
PReLU(1)
Linear(50, 50)
PReLU(1)
Linear(50, 50)
PReLU(1)
Linear(50, 72)
```

followed by the original `Narrow -> DotProduct -> Replicate -> MulConstant(-0.5)
-> CAddTable` zero-sum correction graph.

This corrects an earlier assumption based only on the current
`arguments.lua`, which describes a shallower network. The actual checkpoint,
not that default configuration string, is the source of truth for runtime.

## Verification

The Python Torch7 reader parses the complete object graph, shared storages,
strides, Linear weights/biases and PReLU coefficients. A differential test
reconstructs the checkpoint's cached input and compares every PyTorch layer
against the corresponding cached Torch7 layer output. Maximum float32
difference is below `1e-4`.

The `final_cpu.info` file reports epoch 9849 and validation loss
`0.0003499235609046845`. Re-evaluating the included validation sample files
produces a different loss. Therefore the info value is not used as a numerical
acceptance test: the final checkpoint cache demonstrates that the imported
weights and forward equations are correct, while the archived sample set was
apparently not the exact set used for that recorded loss.

## Runtime behavior

`DeepStackLeducAgent()` now loads the bundled original checkpoint by default.
The exact-terminal `MockNNTerminal` remains available only when explicitly
passed for tests. The CLI seed argument bug was also fixed: it is now passed as
`seed=...`, not accidentally as a value-network object.
