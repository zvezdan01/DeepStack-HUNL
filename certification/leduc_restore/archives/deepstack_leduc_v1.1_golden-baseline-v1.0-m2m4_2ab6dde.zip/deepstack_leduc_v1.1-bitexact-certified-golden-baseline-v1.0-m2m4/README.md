# DeepStack-Leduc audited Python baseline

This archive contains two things:

1. `reference_lua/` — the original repository from the supplied ZIP, preserved as the canonical implementation.
2. `deepstack_leduc/` — a Python/NumPy full-tree CFR baseline and ACPC client.

## Important status

The Python package is **not yet an exact port of the original online DeepStack player**. The original runtime uses depth-limited lookahead, CFR-D continual re-solving and the supplied Torch7 value network. The Python baseline currently implements the repository's separate full-tree CFR utility.

The audit fixed a material evaluator error: the Lua evaluator uses one-based rank values in its arithmetic. The previous Python code used zero-based ranks, which made some pairs and high-card hands receive identical strength values.

The audit also removed nearest-action snapping for unseen raises. The reference player resolves from the actual commitment state; silently mapping an off-tree raise to another amount is not faithful.

## Tests

```bash
PYTHONPATH=. pytest -q
```

## Baseline commands

```bash
PYTHONPATH=. python -m deepstack_leduc.cli tree
PYTHONPATH=. python -m deepstack_leduc.cli solve --iters 1000 --skip 500
```

For exact-reference work, use `reference_lua/Source` as the oracle and port the modules listed in `AUDIT_REPORT.md`.
