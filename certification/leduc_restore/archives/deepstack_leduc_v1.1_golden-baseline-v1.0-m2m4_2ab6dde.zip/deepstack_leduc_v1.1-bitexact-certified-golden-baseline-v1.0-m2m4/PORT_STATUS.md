# Exact port status

## Active components

- Leduc cards, evaluator and terminal equity
- pot-fraction bet sizing and public tree
- 36-bucket conversion
- CFR-D gadget
- masked Huber loss
- Torch7 tensor and model readers
- original checkpoint weights and PyTorch value graph
- NextRoundValue
- packed Torch7-compatible lookahead layout
- packed CFR lookahead computation in the original operation order
- Resolving and ContinualResolving
- ACPC state parser and online player bridge
- per-stage, per-iteration tensor tracing
- original-Torch7 export and Python comparison tools

## Audit correction in v1.1.0

A one-index translation defect in `_compute_ranges()` was corrected. Lua `acting_player[d]` maps to Python `acting_player[d - 1]`. The old code multiplied the wrong player range at the root, contaminating subsequent CFVs and regrets. A dedicated regression test now verifies both player ranges for every root action.

## Verification completed here

- 35 Python tests pass
- compileall passes
- full public tree remains 653 nodes, depth 9
- one complete CFR iteration emits all eight requested stage snapshots
- original checkpoint loading tests pass

## Remaining certification boundary

The included live differential test must be executed in an environment with the original Torch7 `th` runtime. This environment has no `th`, Lua or LuaJIT, so the original Lua process could not be run here. Until that run reports PASS, live numerical identity with the executing Torch7 program is not claimed.
