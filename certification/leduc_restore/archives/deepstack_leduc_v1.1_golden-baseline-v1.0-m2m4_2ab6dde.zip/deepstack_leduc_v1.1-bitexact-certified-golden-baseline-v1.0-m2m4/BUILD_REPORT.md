# Build report

## Source basis

The implementation was built by inspecting the complete supplied ZIP, including all Lua source files, tests, ACPC server code, documentation, model files and data files. The untouched original `Source/` and `ACPCServer/` trees are included under `reference_lua/`.

## Implemented Python modules

- card mapping and Leduc hand evaluator
- card blocking and uniform ranges
- terminal fold/showdown matrices
- pot-fraction bet sizing and all-in action
- public tree builder
- uniform chance strategy
- full-tree CFR+ solver ported from `Source/Tree/tree_cfr.lua`
- ACPC MATCHSTATE parser
- ACPC socket client
- runnable poker agent
- off-tree opponent raise mapping to nearest abstract action

## Verified

- Python tests: 4 passed
- root public tree: 653 nodes, depth 9
- bundled C ACPC dealer and example player compile successfully with GCC
- two-hand end-to-end ACPC match completed successfully
- match result from smoke test: `SCORE:-200|200:PythonDeepStack|Example`

## Honest scope boundary

The supplied original project contains two solving paths:

1. full-tree CFR, used as an exact/reference solver;
2. online depth-limited continual re-solving using CFR-D and the Torch7 value network.

The immediately runnable Python bot currently uses path 1. The complete original path 2 source is included unchanged, but a numerically validated modern PyTorch port of the Torch7 network and tensorized lookahead is not yet claimed complete. This avoids pretending that the old neural runtime has already been reproduced exactly.
