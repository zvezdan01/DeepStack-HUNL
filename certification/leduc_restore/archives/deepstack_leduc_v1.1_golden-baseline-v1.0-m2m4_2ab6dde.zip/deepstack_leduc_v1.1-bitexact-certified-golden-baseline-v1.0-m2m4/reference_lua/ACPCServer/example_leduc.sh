#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
exec "$DIR/example_player" "$DIR/leduc.game" "$1" "$2"
