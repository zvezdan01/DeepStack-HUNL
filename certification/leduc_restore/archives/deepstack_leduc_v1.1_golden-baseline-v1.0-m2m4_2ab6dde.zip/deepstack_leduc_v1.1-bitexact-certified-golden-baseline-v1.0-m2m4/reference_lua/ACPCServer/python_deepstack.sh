#!/usr/bin/env bash
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
exec "$ROOT/deepstack_player.sh" "$1" "$2"
