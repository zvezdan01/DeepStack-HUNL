#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
exec python -m deepstack_leduc.cli play "$1" "$2" --iters "${DEEPSTACK_ITERS:-200}" --seed "${DEEPSTACK_SEED:-0}"
