import numpy as np
import torch

from deepstack_leduc import BucketConversion, Bucketer, CFRDGadget, Config, MaskedHuberLoss
from deepstack_leduc.card_tools import (
    board_index,
    boards_count,
    normalize_range,
    possible_hand_indexes,
    second_round_boards,
    uniform_range,
)


def test_card_tools_match_reference_for_one_card_boards():
    cfg = Config()
    assert boards_count(cfg) == 6
    assert second_round_boards(cfg).tolist() == [[0], [1], [2], [3], [4], [5]]
    assert board_index((4,), cfg) == 4
    assert possible_hand_indexes((4,), cfg).tolist() == [1, 1, 1, 1, 0, 1]
    assert np.allclose(uniform_range((4,), cfg), [0.2, 0.2, 0.2, 0.2, 0.0, 0.2])
    assert np.allclose(normalize_range((4,), np.ones(6), cfg), uniform_range((4,), cfg))


def test_bucketer_exact_ids_for_as_board():
    b = Bucketer()
    assert b.get_bucket_count() == 36
    # Board As is reference board index 1 in Lua => zero shift after conversion.
    assert b.compute_buckets((0,)).tolist() == [-1, 1, 2, 3, 4, 5]


def test_bucketer_exact_ids_for_qs_board():
    b = Bucketer()
    # Board Qs is Lua board index 5 => shift 24; zero-based ids 24..29.
    assert b.compute_buckets((4,)).tolist() == [24, 25, 26, 27, -1, 29]


def test_bucket_conversion_roundtrip_and_mask():
    conversion = BucketConversion()
    conversion.set_board((4,))
    card_range = np.array([[0.1, 0.2, 0.3, 0.15, 0.0, 0.25]])
    bucket_range = conversion.card_range_to_bucket_range(card_range)
    assert bucket_range.shape == (1, 36)
    assert np.count_nonzero(bucket_range) == 5
    assert np.allclose(conversion.bucket_value_to_card_value(bucket_range), card_range)
    mask = conversion.get_possible_bucket_mask()
    assert mask.shape == (1, 36)
    assert mask.sum() == 5
    assert mask[0, 28] == 0


def test_cfrd_first_iteration_matches_lua_equations():
    board = (0,)
    player_range = np.full(6, 1 / 6)
    terminate = np.array([0.0, 2.0, -1.0, 0.5, 1.5, -0.5])
    play = np.array([10.0, 1.0, 3.0, 0.0, 2.0, 2.5])
    gadget = CFRDGadget(board, player_range, terminate)
    result = gadget.compute_opponent_range(play, 1)

    eps = 1e-8
    # Initial strategy is terminate=1, play=0, so play regret is play-terminate.
    expected_play_regret = np.maximum(play - terminate, eps)
    expected_terminate_regret = np.full(6, eps)
    expected = expected_play_regret / (expected_play_regret + expected_terminate_regret)
    expected[0] = 0.0  # As collides with board.
    assert np.allclose(result, expected)


def test_cfrd_does_not_normalize_reconstructed_range():
    gadget = CFRDGadget((0,), np.ones(6) / 6, np.zeros(6))
    result = gadget.compute_opponent_range(np.ones(6), 1)
    assert result[0] == 0.0
    assert result.sum() > 1.0  # It is per-hand play probability, exactly as in Lua.


def test_masked_huber_forward_and_backward_match_reference_formula():
    outputs = torch.tensor([[0.0, 2.0, 4.0, 8.0]], dtype=torch.float64)
    targets = torch.tensor([[1.0, 0.0, 1.0, 8.0]], dtype=torch.float64)
    mask = torch.tensor([[1.0, 0.0, 1.0, 0.0]], dtype=torch.float64)
    criterion = MaskedHuberLoss()
    loss = criterion.forward(outputs, targets, mask)

    # Masking yields errors [-1, 0, 3, 0]. SmoothL1 sum = .5 + 2.5 = 3,
    # Torch7 criterion mean = 3/4, then reference multiplier 4/(4-2)=2.
    assert torch.allclose(loss, torch.tensor(1.5, dtype=torch.float64))
    grad = criterion.backward(outputs, targets)
    # Base mean gradients [-1/4,0,1/4,0], divided by (4-2)/4 = 1/2.
    assert torch.allclose(grad, torch.tensor([[-0.5, 0.0, 0.5, 0.0]], dtype=torch.float64))

from deepstack_leduc import MockNNTerminal, NextRoundValue
from deepstack_leduc.terminal import TerminalEquity


def test_mock_nn_terminal_matches_bucket_showdown_matrix():
    nn = MockNNTerminal()
    assert nn.equity_matrix.shape == (36, 36)
    assert np.allclose(nn.equity_matrix, -nn.equity_matrix.T)
    inputs = np.zeros((1, 73), dtype=np.float64)
    # Put one unit of opponent reach on a valid bucket for As board.
    inputs[0, 36 + 1] = 1.0
    outputs = nn.get_value(inputs)
    assert outputs.shape == (1, 72)
    assert np.allclose(outputs[0, :36], nn.equity_matrix[1])


def test_next_round_value_mock_matches_first_street_terminal_equity():
    # This is the exact debugging path used by next_round_value_test.lua:
    # averaging exact second-street values must equal first-street call equity.
    cfg = Config(cfr_iters=2, cfr_skip_iters=1)
    nrv = NextRoundValue(MockNNTerminal(), cfg)
    nrv.start_computation(np.array([1200.0]))
    ranges = np.zeros((1, 2, 6), dtype=np.float64)
    ranges[0, 0] = [1, 1, 0, 0, 0, 0]
    ranges[0, 1] = [1, 1, 1, 1, 1, 1]
    values = nrv.get_value(ranges)

    te = TerminalEquity(())
    expected = te.call_values(ranges[0])[None, ...]
    assert np.allclose(values, expected)


def test_next_round_value_board_memory_uses_post_skip_average():
    cfg = Config(cfr_iters=3, cfr_skip_iters=1)
    nrv = NextRoundValue(MockNNTerminal(), cfg)
    nrv.start_computation(np.array([400.0]))
    ranges = np.full((1, 2, 6), 1 / 6, dtype=np.float64)
    for _ in range(cfg.cfr_iters):
        nrv.get_value(ranges)
    board_values = nrv.get_value_on_board((2,))
    assert board_values.shape == (1, 2, 6)
    # The public card cannot be a private hand and therefore has zero value.
    assert board_values[0, 0, 2] == 0.0
    assert board_values[0, 1, 2] == 0.0
    # With identical ranges, the per-own-hand CFV vectors are identical;
    # the scalar game values become opposite only after weighting by own reaches.
    assert np.allclose(board_values[0, 0], board_values[0, 1])
    te = TerminalEquity((2,))
    conditional = ranges[0].copy()
    conditional[:, 2] = 0.0
    conditional /= conditional.sum(axis=1, keepdims=True)
    expected = te.call_values(conditional)[None, ...]
    assert np.allclose(board_values, expected)

from deepstack_leduc import DataStream, DeepStackValueNet, load_float_tensor


def test_torch7_tensor_loader_reads_uploaded_reference_data():
    train_inputs = load_float_tensor('reference_lua/Data/TrainSamples/PotBet/train.inputs')
    train_targets = load_float_tensor('reference_lua/Data/TrainSamples/PotBet/train.targets')
    train_mask = load_float_tensor('reference_lua/Data/TrainSamples/PotBet/train.mask')
    assert train_inputs.shape == (100, 73)
    assert train_targets.shape == (100, 72)
    assert train_mask.shape == (100, 36)
    assert train_inputs.dtype == np.float32
    assert np.isfinite(train_targets).all()
    assert set(np.unique(train_mask)).issubset({0.0, 1.0})


def test_data_stream_repeats_mask_for_both_players():
    stream = DataStream("reference_lua/Data/TrainSamples/PotBet", batch_size=100)
    inputs, targets, mask = stream.get_valid_batch(0)
    assert inputs.shape == (100, 73)
    assert targets.shape == (100, 72)
    assert mask.shape == (100, 72)
    assert np.array_equal(mask[:, :36], mask[:, 36:])
    assert stream.train_batch_count == 1
    assert stream.valid_batch_count == 1


def test_value_net_architecture_and_zero_sum_correction():
    model = DeepStackValueNet().double()
    x = torch.zeros((4, 73), dtype=torch.float64)
    # Valid normalized range features for each player.
    x[:, :36] = 1 / 36
    x[:, 36:72] = 1 / 36
    x[:, 72] = 0.5
    y = model(x)
    assert y.shape == (4, 72)
    # net_builder.lua correction enforces sum_p r_p dot v_p = 0.
    weighted_total = (y * x[:, :72]).sum(dim=1)
    assert torch.allclose(weighted_total, torch.zeros_like(weighted_total), atol=1e-12)


def test_lookahead_builder_root_tree_shapes_and_masks():
    from deepstack_leduc.tree import PokerTreeBuilder
    from deepstack_leduc.lookahead_builder import LookaheadBuilder

    tree = PokerTreeBuilder().build_tree(limit_to_street=True)
    la = LookaheadBuilder().build_from_tree(tree)
    assert la.depth == 6
    assert la.actions_count[1] == 4
    assert la.terminal_actions_count[1] == 1
    assert la.bets_count[1] == 3
    assert la.nonallinbets_count[1] == 2
    assert la.ranges_data[1].shape == (1, 1, 1, 2, 6)
    assert la.ranges_data[2].shape == (4, 1, 1, 2, 6)
    # Equal root commitments: free fold is masked exactly as Lua does.
    assert np.all(la.empty_action_mask[2][0] == 0)
    assert np.all(la.empty_action_mask[2][1:] == 1)
    assert tree.lookahead_coordinates.tolist() == [1, 1, 1]
    assert la.first_call_check is True
    assert la.first_call_terminal is False
    assert la.first_call_transition is False


def test_lookahead_builder_turn_tree_transition_flags():
    from deepstack_leduc.tree import PokerTreeBuilder, Node
    from deepstack_leduc.lookahead_builder import LookaheadBuilder

    root = Node(2, 0, np.array([100.0, 100.0]), (2,))
    tree = PokerTreeBuilder().build_tree(root, limit_to_street=True)
    la = LookaheadBuilder().build_from_tree(tree)
    assert la.first_call_check is True
    assert la.first_call_transition is False
    assert la.first_call_terminal is False
    # Every allocated strategy tensor has a matching mask shape.
    for d in range(2, la.depth + 1):
        assert la.current_strategy_data[d].shape == la.empty_action_mask[d].shape
