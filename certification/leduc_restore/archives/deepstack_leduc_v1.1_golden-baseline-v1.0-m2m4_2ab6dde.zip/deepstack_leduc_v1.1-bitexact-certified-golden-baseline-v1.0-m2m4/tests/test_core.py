import numpy as np
from deepstack_leduc import Config,PokerTreeBuilder,TreeCFR
from deepstack_leduc.cards import uniform_range, hand_strength, CARD_STRINGS
from deepstack_leduc.terminal import TerminalEquity
from deepstack_leduc.acpc import parse_matchstate,decode_actions

def test_tree_shape():
    r=PokerTreeBuilder().build_tree()
    assert PokerTreeBuilder.count_nodes(r)==653
    assert r.depth==9

def test_zero_sum_terminal():
    te=TerminalEquity((0,));rr=np.stack([uniform_range((0,)),uniform_range((0,))]);v=te.call_values(rr)
    ev=(rr*v).sum(axis=1)
    assert abs(ev.sum()) <= np.finfo(np.float32).eps

def test_cfr_runs():
    cfg=Config(cfr_iters=4,cfr_skip_iters=2)
    r=PokerTreeBuilder(cfg).build_tree();rr=np.stack([uniform_range(()),uniform_range(())]);TreeCFR(cfg).run(r,rr)
    assert r.cf_values is not None and np.isfinite(r.cf_values).all()

def test_acpc_parser():
    s=parse_matchstate('MATCHSTATE:0:99:cc/r800:Kh|/As')
    assert s.position==0 and s.private_card==3 and s.board==(0,)
    assert decode_actions('cr300c')==[('call',None),('raise',300),('call',None)]


def test_card_order_matches_reference_lua():
    assert CARD_STRINGS == ("As", "Ah", "Ks", "Kh", "Qs", "Qh")

def test_evaluator_matches_lua_one_based_rank_arithmetic():
    # On As board: Ah is pair aces (1), Ks/Kh are A-K high (5), Qs/Qh A-Q high (6).
    assert hand_strength(1, (0,)) == 1
    assert hand_strength(2, (0,)) == 5
    assert hand_strength(3, (0,)) == 5
    assert hand_strength(4, (0,)) == 6
    assert hand_strength(5, (0,)) == 6

def test_pair_beats_every_high_card():
    board=(0,)
    pair=hand_strength(1, board)
    highs=[hand_strength(c, board) for c in (2,3,4,5)]
    assert pair < min(highs)
