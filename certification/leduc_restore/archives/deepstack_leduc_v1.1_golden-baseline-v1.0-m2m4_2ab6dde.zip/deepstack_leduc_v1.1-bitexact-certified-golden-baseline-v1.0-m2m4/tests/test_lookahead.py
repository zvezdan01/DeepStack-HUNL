import numpy as np

from deepstack_leduc.config import Config
from deepstack_leduc.cfr import TreeCFR
from deepstack_leduc.lookahead import Lookahead
from deepstack_leduc.resolving import Resolving
from deepstack_leduc.tree import Node, PokerTreeBuilder


def cfg_small():
    return Config(cfr_iters=40, cfr_skip_iters=20)


def uniform(board=()):
    r = np.ones(6, dtype=float)
    for c in board:
        r[c] = 0
    return r / r.sum()


def test_river_tensor_lookahead_uses_reference_free_fold_mask_and_layout():
    cfg = cfg_small()
    root = Node(2, 0, np.array([100.0, 100.0]), (0,))
    root = PokerTreeBuilder(cfg).build_tree(root, limit_to_street=True)
    look = Lookahead(cfg)
    look.build_lookahead(root)

    # Exact lookahead_builder.lua behavior: fold is masked when checking is free.
    assert look.empty_action_mask[2] is not None
    np.testing.assert_array_equal(look.empty_action_mask[2][0], 0.0)

    # Torch7 uses FloatTensor and the packed [action,parent,gp,player,card] layout.
    assert look.ranges_data[1].shape == (1, 1, 1, 2, 6)
    assert look.ranges_data[2].shape == (look.actions_count[1], 1, 1, 2, 6)
    assert look.ranges_data[1].dtype == np.float32
    assert look.pot_size[2].dtype == np.float32

    r = uniform((0,))
    look.resolve_first_node(r, r)
    result = look.get_results()
    np.testing.assert_array_equal(result.strategy[0], 0.0)
    np.testing.assert_allclose(result.strategy.sum(axis=0), np.ones(6), atol=2e-6)
    assert result.root_cfvs_both_players is not None
    assert np.isfinite(result.root_cfvs_both_players).all()


def test_preflop_depth_limited_resolve_and_chance_cfv():
    cfg = Config(cfr_iters=12, cfr_skip_iters=6)
    root = Node(1, 0, np.array([100.0, 100.0]), ())
    resolver = Resolving(cfg)
    r = uniform()
    result = resolver.resolve_first_node(root, r, r)
    assert result.strategy.shape[1] == 6
    assert result.children_cfvs.shape == result.strategy.shape
    np.testing.assert_allclose(result.strategy.sum(axis=0), np.ones(6), atol=2e-7)
    assert np.isfinite(result.strategy).all()
    assert np.isfinite(result.achieved_cfvs).all()

    # Root check/call transitions directly to the second round.
    chance = resolver.get_chance_action_cfv(-1, (0,))
    assert chance.shape == (6,)
    assert np.isfinite(chance).all()
    assert chance[0] == 0.0


def test_cfrd_resolve_smoke():
    cfg = Config(cfr_iters=10, cfr_skip_iters=5)
    root = Node(2, 0, np.array([300.0, 300.0]), (2,))
    resolver = Resolving(cfg)
    r = uniform((2,))
    bounds = np.linspace(-1.0, 1.0, 6)
    bounds[2] = 0.0
    result = resolver.resolve(root, r, bounds)
    assert result.root_cfvs is None
    assert result.root_cfvs_both_players is None
    assert np.isfinite(result.strategy).all()
    np.testing.assert_allclose(result.strategy.sum(axis=0), np.ones(6), atol=2e-7)


def test_range_propagation_multiplies_first_lookahead_player_not_opponent():
    """Regression for Lua acting_player[d] -> Python acting_player[d-1]."""
    cfg = Config(cfr_iters=1, cfr_skip_iters=0)
    root = Node(2, 0, np.array([100.0, 100.0]), (0,))
    root = PokerTreeBuilder(cfg).build_tree(root, limit_to_street=True)
    look = Lookahead(cfg)
    look.build_lookahead(root)
    p = np.asarray([0.0, .10, .20, .30, .15, .25], dtype=np.float32)
    o = np.asarray([0.0, .25, .15, .10, .20, .30], dtype=np.float32)
    look.ranges_data[1][..., 0, :] = p
    look.ranges_data[1][..., 1, :] = o
    look._compute_current_strategies()
    root_strategy = look.current_strategy_data[2].copy()
    look._compute_ranges()
    for a in range(look.actions_count[1]):
        np.testing.assert_allclose(look.ranges_data[2][a, 0, 0, 0], p * root_strategy[a, 0, 0], atol=1e-7)
        np.testing.assert_allclose(look.ranges_data[2][a, 0, 0, 1], o, atol=1e-7)


def test_one_iteration_trace_contains_all_requested_stages(tmp_path):
    from deepstack_leduc.differential import TRACE_STAGES, capture_lookahead, save_trace

    cfg = Config(cfr_iters=1, cfr_skip_iters=0)
    root = Node(2, 0, np.array([100.0, 100.0]), (0,))
    root = PokerTreeBuilder(cfg).build_tree(root, limit_to_street=True)
    look = Lookahead(cfg)
    look.build_lookahead(root)
    snapshots = []

    def callback(obj, stage, iteration):
        snapshots.append((stage, iteration, capture_lookahead(obj, stage, iteration)))

    look.trace_callback = callback
    r = uniform((0,)).astype(np.float32)
    look.resolve_first_node(r, r)
    assert [stage for stage, _, _ in snapshots] == list(TRACE_STAGES)
    out = save_trace(tmp_path / "trace", snapshots)
    assert (out / "manifest.json").exists()
    assert len(list(out.glob("*.npz"))) == len(TRACE_STAGES)
