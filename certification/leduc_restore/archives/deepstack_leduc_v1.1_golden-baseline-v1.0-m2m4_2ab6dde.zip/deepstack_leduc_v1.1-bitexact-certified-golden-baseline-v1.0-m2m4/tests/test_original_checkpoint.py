from pathlib import Path

import numpy as np
import torch

from deepstack_leduc.torch7_model import (
    Torch7Object,
    load_torch7_object,
    module_children,
    table_get,
)
from deepstack_leduc.torch7_tensor import load_float_tensor
from deepstack_leduc.value_model import load_original_value_net

ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / "deepstack_leduc/models/final_cpu.model"


def test_checkpoint_architecture_and_parameters():
    model = load_original_value_net()
    linears = [m for m in model.feedforward if isinstance(m, torch.nn.Linear)]
    prelus = [m for m in model.feedforward if isinstance(m, torch.nn.PReLU)]
    assert [(m.in_features, m.out_features) for m in linears] == [
        (73, 50), (50, 50), (50, 50), (50, 50), (50, 50), (50, 72)
    ]
    assert len(prelus) == 5
    assert sum(p.numel() for p in model.parameters()) == 17577


def test_pytorch_layers_reproduce_torch7_cached_forward_values():
    """Verify imported weights against tensors stored inside the checkpoint.

    Torch7 saved each module's most recent output. The first 72 input features
    are cached by nn.Narrow. The pot feature can be recovered from the cached
    first Linear output. This gives a checkpoint-internal differential test
    that does not require a working Torch7 runtime.
    """
    root = load_torch7_object(MODEL)
    assert isinstance(root, Torch7Object)
    root_modules = module_children(root)
    first_concat_children = module_children(root_modules[0])
    torch_layers = module_children(first_concat_children[0])
    narrow = module_children(first_concat_children[1])[0]
    ranges = table_get(narrow, "output").data

    first_linear = torch_layers[0]
    weight = table_get(first_linear, "weight").data
    bias = table_get(first_linear, "bias").data
    cached_first_output = table_get(first_linear, "output").data
    residual = cached_first_output - ranges @ weight[:, :72].T - bias
    pot_weight = weight[:, 72]
    pots = (residual @ pot_weight) / (pot_weight @ pot_weight)
    reconstructed_inputs = np.concatenate([ranges, pots[:, None]], axis=1).astype(np.float32)

    model = load_original_value_net()
    value = torch.from_numpy(reconstructed_inputs)
    with torch.no_grad():
        for py_layer, torch_layer in zip(model.feedforward, torch_layers):
            value = py_layer(value)
            cached = table_get(torch_layer, "output").data
            # Torch7 and PyTorch use different BLAS kernels; accumulation order
            # causes small float32 differences in the deeper layers.
            assert np.max(np.abs(value.numpy() - cached)) < 1e-4


def test_zero_sum_correction_is_exact_per_batch_row():
    model = load_original_value_net()
    x = load_float_tensor(ROOT / 'reference_lua/Data/TrainSamples/PotBet/valid.inputs')[:8]
    with torch.no_grad():
        y = model(torch.from_numpy(x.astype(np.float32)))
    ranges = torch.from_numpy(x[:, :72].astype(np.float32))
    weighted_sum = torch.sum(y * ranges, dim=1)
    assert torch.max(torch.abs(weighted_sum)).item() < 2e-5
