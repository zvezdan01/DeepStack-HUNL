import numpy as np
import pytest

from deepstack_leduc.acpc import parse_matchstate
from deepstack_leduc.torch7_blas import BIT_EXACT_BACKEND
from deepstack_leduc.card_tools import normalize_range
from deepstack_leduc.config import Config
from deepstack_leduc.continual_resolving import ContinualResolving
from deepstack_leduc.resolving import Resolving
from deepstack_leduc.terminal import TerminalEquity
from deepstack_leduc.torch7_tensor import load_float_tensor
from deepstack_leduc.tree import Node
from deepstack_leduc.value_model import load_original_value_net


def same(a, b):
    return np.array_equal(
        np.asarray(a, dtype=np.float32),
        np.asarray(b, dtype=np.float32),
        equal_nan=True,
    )


def lua(name):
    return np.asarray(load_float_tensor(name), dtype=np.float32)


@pytest.mark.skipif(
    not BIT_EXACT_BACKEND,
    reason="bit-exact Torch7 reference test requires Linux x86_64 backend",
)
def test_full_deterministic_hand_bitmatch():
    cfg = Config()
    value_net = load_original_value_net()

    # ACPC terminal state:
    # P1 As, P2 unknown, P1 r300, P2 call,
    # board Ah, then check/check -> showdown.
    terminal_state = parse_matchstate(
        "MATCHSTATE:0:1:r300c/cc:As|/Ah"
    )

    assert terminal_state.position == 0
    assert terminal_state.private_card == 0
    assert terminal_state.acting_player == -1
    assert terminal_state.street == 2
    assert terminal_state.board == (1,)
    assert same(terminal_state.bets, [-1, -1])

    # Continual resolving from hand start.
    start_state = parse_matchstate(
        "MATCHSTATE:0:1::As|"
    )

    cr = ContinualResolving(
        cfg,
        value_network=value_net,
    )
    cr.start_new_hand(start_state)

    node1 = start_state.to_node()
    cr._resolve_node(node1, start_state)

    bet = 300
    strategy = cr.resolving.get_action_strategy(bet)

    cr.current_opponent_cfvs_bound = (
        cr.resolving.get_action_cfv(bet).copy()
    )
    cr.current_player_range *= strategy
    cr.current_player_range = normalize_range(
        node1.board,
        cr.current_player_range,
    )

    cr.decision_id += 1
    cr.last_bet = bet
    cr.last_node = node1

    assert same(
        cr.current_player_range,
        lua("continual_street2_lua_trace/"
            "street1.after_action.player_range.t7"),
    )

    assert same(
        cr.current_opponent_cfvs_bound,
        lua("continual_street2_lua_trace/"
            "street1.after_action.opponent_cfvs.t7"),
    )

    # P2 calls, chance deals Ah, P1 acts on street 2.
    node2 = Node(
        board=(1,),
        street=2,
        current_player=0,
        bets=np.asarray([300, 300], dtype=np.float32),
    )

    cr._update_invariant(node2, start_state)

    assert same(
        cr.current_player_range,
        lua("continual_street2_lua_trace/"
            "street2.invariant.player_range.t7"),
    )

    assert same(
        cr.current_opponent_cfvs_bound,
        lua("continual_street2_lua_trace/"
            "street2.invariant.opponent_cfvs.t7"),
    )

    cr.resolving = Resolving(
        cfg,
        value_network=value_net,
    )
    cr.resolving.resolve(
        node2,
        cr.current_player_range,
        cr.current_opponent_cfvs_bound,
    )

    assert same(
        cr.resolving.resolve_results.achieved_cfvs,
        lua("continual_street2_lua_trace/"
            "street2.achieved_cfvs.t7"),
    )

    assert same(
        cr.resolving.resolve_results.strategy,
        lua("continual_street2_lua_trace/"
            "street2.strategy_all.t7"),
    )

    assert same(
        cr.resolving.resolve_results.children_cfvs,
        lua("continual_street2_lua_trace/"
            "street2.children_cfvs_all.t7"),
    )

    assert same(
        cr.resolving.get_possible_actions(),
        lua("continual_street2_lua_trace/"
            "street2.possible_actions.t7"),
    )

    for action in (-2, -1, 900, 1200):
        assert same(
            cr.resolving.get_action_strategy(action),
            lua(
                f"continual_street2_lua_trace/"
                f"street2.strategy_{action}.t7"
            ),
        )
        assert same(
            cr.resolving.get_action_cfv(action),
            lua(
                f"continual_street2_lua_trace/"
                f"street2.cfv_{action}.t7"
            ),
        )

    # Terminal showdown: As vs Ks on Ah.
    te = TerminalEquity((1,))
    ranges = np.zeros((2, 6), dtype=np.float32)
    ranges[0, 0] = 1.0
    ranges[1, 2] = 1.0

    assert same(
        te.call_matrix,
        lua("terminal_e2e_lua/call_matrix.t7"),
    )
    assert same(
        te.fold_matrix,
        lua("terminal_e2e_lua/fold_matrix.t7"),
    )
    assert same(
        te.call_values(ranges),
        lua("terminal_e2e_lua/call_result.t7"),
    )
