from __future__ import annotations

import numpy as np

from deepstack_leduc.acpc import decode_actions, parse_matchstate
from deepstack_leduc.config import Config
from deepstack_leduc.continual_resolving import ContinualResolving


def tiny_cfg() -> Config:
    return Config(cfr_iters=8, cfr_skip_iters=4)


def test_decode_actions_is_strict():
    assert decode_actions("cr300c") == [("call", None), ("raise", 300), ("call", None)]


def test_parse_root_p1_state():
    s = parse_matchstate("MATCHSTATE:0:99::Kh|", tiny_cfg())
    assert s.position == 0
    assert s.acting_player == 0
    assert s.street == 1
    np.testing.assert_array_equal(s.bets, [100, 100])
    assert s.to_node().current_player == 0


def test_parse_p2_after_p1_raise():
    s = parse_matchstate("MATCHSTATE:1:99:r300:|Qh", tiny_cfg())
    assert s.position == 1
    assert s.acting_player == 1
    np.testing.assert_array_equal(s.bets, [300, 100])


def test_parse_first_actor_after_chance_transition():
    s = parse_matchstate("MATCHSTATE:0:99:cc/:Kh|/Qs", tiny_cfg())
    assert s.street == 2
    assert s.acting_player == 0
    np.testing.assert_array_equal(s.bets, [100, 100])


def test_continual_first_action_updates_invariants():
    cfg = tiny_cfg()
    cr = ContinualResolving(cfg, seed=1)
    s = parse_matchstate("MATCHSTATE:0:7::As|", cfg)
    cr.start_new_hand(s)
    action = cr.compute_action(s.to_node(), s)
    assert action == "c" or action == "f" or action.startswith("r")
    assert cr.decision_id == 1
    assert cr.current_player_range is not None
    assert abs(float(cr.current_player_range.sum()) - 1.0) < 1e-5
    assert cr.current_opponent_cfvs_bound is not None
