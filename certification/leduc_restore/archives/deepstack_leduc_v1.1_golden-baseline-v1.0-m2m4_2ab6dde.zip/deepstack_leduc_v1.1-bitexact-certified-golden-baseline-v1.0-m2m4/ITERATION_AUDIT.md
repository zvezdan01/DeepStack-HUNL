# One-iteration tensor audit

The active packed lookahead was audited again against `Source/Lookahead/lookahead.lua` and `lookahead_builder.lua`.

## Corrected defect

The Python translation of Lua `acting_player[d]` in `_compute_ranges()` used `acting_player[d]` even though the Python array stores Lua index 1 at Python index 0. It therefore multiplied the second lookahead player's range at the root instead of the first lookahead player's range. The correct translation is `acting_player[d - 1]`.

This defect affected all downstream ranges, CFVs, regrets and strategies. A regression test now checks the propagated range for every root action and both players.

## Per-iteration instrumentation

The active `Lookahead` now emits snapshots after the exact original operation order:

1. opponent range
2. current strategy
3. ranges
4. average strategy
5. terminal CFVs
6. current CFVs
7. regrets
8. average CFVs

Snapshots contain every per-layer tensor required for differential comparison, plus CFR-D gadget strategies and regrets when the gadget is active.

## Live Torch7 comparison

`reference_tools/export_one_iteration.lua` runs the original Torch7 implementation for one fixed river state and saves standalone tensors. `reference_tools/compare_lua_trace.py` loads those tensors and compares them element by element against the Python port.

The current execution environment has no `th`, Lua, LuaJIT or Torch7 runtime, so the original Lua exporter could not be executed here. The Python side, trace production, tensor loader and regression tests are executable and pass. A claim of live Lua/Python numerical identity still requires running the included two-command differential test in a Torch7 environment.
