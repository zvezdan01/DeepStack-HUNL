# DeepStack-Leduc Python Port — Certification Report

## Scope

This report documents the differential verification completed for the modern Python port of the public DeepStack-Leduc implementation.

The reference implementation is the original Lua/Torch7 code retained under `reference_lua`. Certified numerical comparisons use the legacy x86_64 OpenBLAS behavior required to reproduce Torch7 `FloatTensor` matrix multiplication.

This report applies to the current extracted working directory:

`deepstack_leduc_v1.0-bitexact`

It supersedes the narrower certification statements in the original release notes. A new immutable archive and SHA-256 must be generated after this report is added.

## Certification summary

### Public game tree structure

The complete public tree was compared node-by-node between the Lua/Torch7 reference and the Python port.

- Lua nodes: 653
- Python nodes: 653
- Maximum depth: 9
- Structural comparison: 653/653 nodes exact
- Compared fields included path, street, acting/current player, bets, board, terminal flag, child count, and actions

This is a structural equality result, not a floating-point tensor comparison.

### One complete CFR iteration

A full one-iteration lookahead trace was captured from the Lua/Torch7 implementation and compared against the Python tensorized lookahead.

- 232/232 internal tensors exact
- Zero numerical tolerance

Certified stages include ranges, CFVs, regrets, strategies, average strategies, and average CFVs.

### Original value network

The original `final_cpu.model` checkpoint was loaded and reproduced by the Python port.

- Architecture observed from checkpoint: 73 -> 50 -> 50 -> 50 -> 50 -> 50 -> 72
- Five PReLU layers
- Zero-sum correction retained
- Feed-forward output and correction path matched bit-for-bit on the certified comparison

### Continual resolving — deterministic first action

The deterministic first action path using `raise 300` was compared against the Lua/Torch7 implementation.

- 6/6 checkpoints bit-exact

### Continual resolving — all legal private-card / board combinations for `r300 -> call`

For the first-street history `P1 raise 300 -> P2 call`, all legal private-card / public-board combinations were exported and compared.

- 6 private cards
- 5 legal boards for each private card
- 30 cases
- 480/480 tensors bit-exact

### Continual resolving — all first-street chance histories

All five first-street histories that transition to chance were certified across all legal private-card / board combinations.

Chance histories:

- `check -> check`
- `check -> raise 300 -> call`
- `check -> raise 300 -> raise 900 -> call`
- `raise 300 -> call`
- `raise 300 -> raise 900 -> call`

Results:

- 150/150 cases passed
- 3720/3720 tensors bit-exact

### Player 2 first-street continual resolving

All Player-2 first-street decision configurations were certified over all six private cards.

- 36/36 cases passed
- 744/744 tensors bit-exact

This includes the six relevant Player-2 decision-node shapes reached from the legal first-street betting histories.

### First-street terminal leaves

Every first-street terminal public-tree leaf was certified with deterministic dense ranges.

- 18/18 terminal leaves
- 12 folds
- 6 calls
- 108/108 tensors bit-exact

Compared tensors include ranges, call matrix, fold matrix, raw terminal values, pot-scaled terminal values, and bets.

During this certification, the Python terminal evaluator was corrected to use the Torch7-compatible BLAS path instead of NumPy `@` in bit-exact mode.

### Exhaustive street-2 one-iteration certification

The complete street-2 lookahead was certified for all relevant starting pots and all legal private-card / board combinations.

Starting pots:

- 100
- 300
- 900

Coverage:

- 3 starting pots
- 6 private cards
- 5 legal boards per private card
- 90 total cases

For every case, the complete street-2 lookahead was built and the internal one-CFR-iteration state was compared stage-by-stage.

Results:

- 90/90 cases passed
- 20,340/20,340 tensors bit-exact
- Comparison uses `np.array_equal`
- No `allclose`
- No epsilon tolerance

Captured state includes:

- `ranges_data`
- `cfvs_data`
- `regrets_data`
- `positive_regrets_data`
- `current_strategy_data`
- `average_strategies_data`
- `average_cfvs_data`

across the following stages:

- opponent range
- current strategy
- ranges
- average strategy
- terminal CFVs
- current CFVs
- regrets
- average CFVs

### Deterministic end-to-end regression

The deterministic ACPC path remains covered:

`P1 raise 300 -> P2 call -> board Ah -> P1 check -> P2 check -> showdown`

The permanent end-to-end bit-match test passes on the x86_64 bit-exact backend.

### Full Python regression suite

After the terminal BLAS correction, the full Python test suite was rerun.

Final result:

- 36/36 tests passed
- Runtime observed: 61.51 seconds

One mathematical zero-sum sanity test was updated from an unrealistic `1e-12` threshold to `np.finfo(np.float32).eps`, because the reference implementation uses Torch7 `FloatTensor` arithmetic. The production terminal implementation was not weakened or changed to satisfy that test; it remains matched to the Lua/Torch7 reference.

## Numerical backend

Bit-exact certification requires the legacy x86_64 BLAS behavior used by the Torch7 reference.

The release retains:

- `torch7_openblas.so.0`
- `libopenblas_sandybridgep-r0.3.0.dev.so`
- `libgfortran.so.3`
- `libgfortran.so.3.0.0`

Run Python tests from the release root with:

```bash
LD_LIBRARY_PATH="$PWD" PYTHONPATH=. pytest -q
```

On non-x86_64 platforms, the port uses a portable NumPy fallback. That mode is intended for functionality and portability, not for claiming bit-for-bit identity with the legacy Torch7 BLAS backend.

## Important scope boundary

This certification applies to the public DeepStack-Leduc implementation and the paths described above.

It does not claim that this repository is the full heads-up no-limit Texas Hold'em DeepStack system from the paper.

It also does not claim bit-for-bit identity for random action sampling, because random-number-generator behavior is not part of the deterministic tensor certification.

## Reference and certification tools

The working release retains the original Lua implementation and the differential tools used to produce the results above, including:

- `reference_tools/export_one_iteration.lua`
- `reference_tools/export_tree_manifest.lua`
- `reference_tools/export_all_chance_histories.lua`
- `reference_tools/compare_all_chance_histories.py`
- `reference_tools/export_p2_all_street1.lua`
- `reference_tools/compare_p2_all_street1.py`
- `reference_tools/export_terminal_all_street1.lua`
- `reference_tools/compare_terminal_all_street1.py`
- `reference_tools/export_street2_exhaustive.lua`
- `reference_tools/compare_street2_exhaustive.py`

## Release finalization

The previously distributed archive checksum beginning with:

`555be419...`

belongs to an earlier, narrower release state and must not be used as the checksum of this expanded certification state.

After this report is added and the final directory contents are frozen, create a new immutable archive and compute a new SHA-256 checksum.
