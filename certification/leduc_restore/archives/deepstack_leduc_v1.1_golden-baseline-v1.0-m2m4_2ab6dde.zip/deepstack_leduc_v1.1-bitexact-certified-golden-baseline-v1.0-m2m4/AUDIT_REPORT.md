# Audit report

## Verdict

The previous archive was runnable, but the statement that it was built *exactly* like the supplied DeepStack ZIP was incorrect. It implemented the repository's convenience `TreeCFR` path, not the actual online DeepStack pipeline.

## Defects found and corrected

### 1. Incorrect hand-strength arithmetic — fixed

`Source/Game/Evaluation/evaluator.lua` uses one-based ranks (`A=1, K=2, Q=3`). The previous Python port used zero-based ranks inside formulas such as `r1 * rank_count + r2`. That caused collisions between pair and high-card categories. The Python evaluator now converts to one-based ranks before applying the Lua formulas.

### 2. Off-tree raise snapping — removed

The previous ACPC agent mapped an unknown raise amount to the nearest prebuilt abstract action. The reference player does not do that; it constructs/resolves from the actual node commitments. The Python baseline now refuses an unknown action rather than silently changing the state.

### 3. Overstated architecture claim — corrected

The Python agent is now labelled as a full-tree CFR baseline. It is not labelled as an exact DeepStack continual-resolving port.

## Components still required for an exact modern port

- `Source/Lookahead/lookahead.lua`
- `Source/Lookahead/lookahead_builder.lua`
- `Source/Lookahead/cfrd_gadget.lua`
- `Source/Lookahead/resolving.lua`
- `Source/Player/continual_resolving.lua`
- `Source/Nn/next_round_value.lua`
- `Source/Nn/value_nn.lua`
- `Source/Nn/net_builder.lua`
- Torch7 checkpoint conversion with numerical parity
- invariant updates after own actions, opponent actions and chance transitions

Until those are ported and checked against the Lua outputs, no Python package should be described as an exact reproduction.
