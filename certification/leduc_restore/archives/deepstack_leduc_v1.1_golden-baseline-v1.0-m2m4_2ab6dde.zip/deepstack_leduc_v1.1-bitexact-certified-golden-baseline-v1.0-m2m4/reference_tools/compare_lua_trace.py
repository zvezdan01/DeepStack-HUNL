from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np

from deepstack_leduc.config import Config
from deepstack_leduc.differential import TRACE_STAGES, capture_lookahead
from deepstack_leduc.lookahead import Lookahead
from deepstack_leduc.torch7_tensor import load_float_tensor
from deepstack_leduc.tree import Node, PokerTreeBuilder


def build_python_trace():
    cfg = Config(cfr_iters=1, cfr_skip_iters=0)
    root = Node(2, 0, np.array([100.0, 100.0]), (0,))
    root = PokerTreeBuilder(cfg).build_tree(root, limit_to_street=True)
    look = Lookahead(cfg)
    look.build_lookahead(root)
    p = np.asarray([0, .10, .20, .30, .15, .25], dtype=np.float32)
    o = np.asarray([0, .25, .15, .10, .20, .30], dtype=np.float32)
    look.ranges_data[1][..., 0, :] = p
    look.ranges_data[1][..., 1, :] = o
    trace = {}
    def cb(obj, stage, iteration):
        trace[stage] = capture_lookahead(obj, stage, iteration)
    look.trace_callback = cb
    look.resolve_first_node(p, o)
    return trace


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('lua_trace', type=Path)
    ap.add_argument('--atol', type=float, default=1e-6)
    ap.add_argument('--rtol', type=float, default=1e-5)
    ns = ap.parse_args()
    py = build_python_trace()
    failures = []
    checked = 0
    for path in sorted(ns.lua_trace.glob('*.t7')):
        stem = path.stem
        stage, key = stem.split('.', 1)
        if stage not in TRACE_STAGES:
            continue
        reference = load_float_tensor(path)
        python_key = key
        if python_key not in py[stage]:
            failures.append((stem, 'missing in Python trace'))
            continue
        actual = py[stage][python_key]
        checked += 1
        if actual.shape != reference.shape:
            failures.append((stem, f'shape {actual.shape} != {reference.shape}'))
        elif not np.allclose(actual, reference, atol=ns.atol, rtol=ns.rtol, equal_nan=True):
            err = float(np.max(np.abs(actual.astype(np.float64)-reference.astype(np.float64))))
            failures.append((stem, f'max_abs_error={err}'))
    if failures:
        for name, reason in failures:
            print(f'FAIL {name}: {reason}')
        raise SystemExit(1)
    print(f'PASS: compared {checked} tensors across one complete CFR iteration')

if __name__ == '__main__':
    main()
