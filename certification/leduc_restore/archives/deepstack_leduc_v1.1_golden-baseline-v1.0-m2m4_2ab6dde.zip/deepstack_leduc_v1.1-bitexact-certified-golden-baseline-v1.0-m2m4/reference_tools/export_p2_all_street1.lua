package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
local card_tools = require "Game.card_tools"
require "Player.continual_resolving"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local root_out = arg[1] or "/work/p2_all_street1_lua_trace"
os.execute("rm -rf " .. root_out)
os.execute("mkdir -p " .. root_out)

local function save(dir, name, t)
  torch.save(dir .. "/" .. name .. ".t7", t:float():contiguous())
end

local function make_node(b1, b2)
  return {
    board = arguments.Tensor{},
    street = 1,
    current_player = constants.players.P2,
    bets = arguments.Tensor{b1, b2},
    terminal = false
  }
end

local function save_resolve(dir, prefix, cr)
  save(dir, prefix .. ".player_range", cr.current_player_range)
  save(dir, prefix .. ".opponent_cfvs", cr.current_opponent_cfvs_bound)

  local r = cr.resolving
  save(dir, prefix .. ".achieved_cfvs", r.resolve_results.achieved_cfvs)
  save(dir, prefix .. ".strategy_all", r.resolve_results.strategy)
  save(dir, prefix .. ".children_cfvs_all", r.resolve_results.children_cfvs)

  local possible = r:get_possible_actions()
  save(dir, prefix .. ".possible_actions", possible)

  for i = 1, possible:size(1) do
    local action = possible[i]
    save(dir, prefix .. ".strategy_" .. tostring(action),
         r:get_action_strategy(action))
    save(dir, prefix .. ".cfv_" .. tostring(action),
         r:get_action_cfv(action))
  end
end

local cases = {
  {
    name = "c",
    target = function() return make_node(100, 100) end
  },
  {
    name = "r300",
    target = function() return make_node(300, 100) end
  },
  {
    name = "r1200",
    target = function() return make_node(1200, 100) end
  },
  {
    name = "c_r300_r900",
    prior = function() return make_node(100, 100) end,
    prior_action = 300,
    target = function() return make_node(900, 300) end
  },
  {
    name = "c_r300_r1200",
    prior = function() return make_node(100, 100) end,
    prior_action = 300,
    target = function() return make_node(1200, 300) end
  },
  {
    name = "r300_r900_r1200",
    prior = function() return make_node(300, 100) end,
    prior_action = 900,
    target = function() return make_node(1200, 900) end
  }
}

local count = 0

for _, case in ipairs(cases) do
  for private_id = 1, 6 do
    local dir =
      root_out .. "/" .. case.name .. "/private_" .. tostring(private_id)

    os.execute("mkdir -p " .. dir)

    local cr = ContinualResolving()
    local state = {
      position = constants.players.P2,
      hand_id = private_id
    }

    cr:start_new_hand(state)

    if case.prior then
      local prior_node = case.prior()

      cr:_resolve_node(prior_node, state)
      save_resolve(dir, "prior.resolve", cr)

      local strategy =
        cr.resolving:get_action_strategy(case.prior_action)

      cr.current_opponent_cfvs_bound =
        cr.resolving:get_action_cfv(case.prior_action):clone()

      cr.current_player_range:cmul(strategy)
      cr.current_player_range =
        card_tools:normalize_range(
          prior_node.board,
          cr.current_player_range
        )

      save(dir, "prior.after_action.player_range",
           cr.current_player_range)
      save(dir, "prior.after_action.opponent_cfvs",
           cr.current_opponent_cfvs_bound)

      cr.decision_id = cr.decision_id + 1
      cr.last_bet = case.prior_action
      cr.last_node = prior_node
    end

    local target = case.target()
    cr:_resolve_node(target, state)

    save_resolve(dir, "target", cr)
    save(dir, "starting_cfvs_p1", cr.starting_cfvs_p1)

    count = count + 1
    print("PASS", case.name, "private", private_id)
  end
end

print("PASS: saved", count, "P2 street1 decision traces")
