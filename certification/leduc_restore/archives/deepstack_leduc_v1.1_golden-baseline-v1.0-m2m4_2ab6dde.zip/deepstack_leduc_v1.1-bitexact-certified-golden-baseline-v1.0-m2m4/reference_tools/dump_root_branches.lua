package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
require "Tree.tree_builder"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local builder = PokerTreeBuilder()

local root = {
  street = 1,
  board = arguments.Tensor{},
  current_player = constants.players.P1,
  bets = arguments.Tensor{arguments.ante, arguments.ante},
  terminal = false
}

local tree = builder:build_tree({root_node = root, limit_to_street = false})

local function dump(node, depth, path)
  if depth > 3 then
    return
  end

  if node.actions and torch.isTensor(node.actions) and node.actions:dim() == 1 then
    io.write("PATH ", path, " | PLAYER ", tostring(node.current_player), " | BETS ")
    if node.bets then
      io.write(tostring(node.bets[1]), ",", tostring(node.bets[2]))
    end
    io.write(" | ACTIONS")

    for i = 1, node.actions:size(1) do
      io.write(" ", tostring(node.actions[i]))
    end

    io.write("\n")
  end

  if node.children and node.actions and torch.isTensor(node.actions) and node.actions:dim() == 1 then
    for i = 1, #node.children do
      local action = node.actions[i]
      dump(
        node.children[i],
        depth + 1,
        path .. "/" .. tostring(action)
      )
    end
  end
end

dump(tree, 0, "ROOT")
