local out_dir = arg[1] or "/work/continual_street2_lua_trace"
os.execute("mkdir -p " .. out_dir)

package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
local card_tools = require "Game.card_tools"
require "Player.continual_resolving"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local function save(name, t)
  torch.save(out_dir .. "/" .. name .. ".t7", t:float():contiguous())
end

local cr = ContinualResolving()

local state = {
  position = constants.players.P1,
  hand_id = 1
}

cr:start_new_hand(state)

local node1 = {
  board = arguments.Tensor{},
  street = 1,
  current_player = constants.players.P1,
  bets = arguments.Tensor{arguments.ante, arguments.ante},
  terminal = false
}

cr:_resolve_node(node1, state)

local bet = 300
local strategy = cr.resolving:get_action_strategy(bet)

cr.current_opponent_cfvs_bound =
  cr.resolving:get_action_cfv(bet):clone()

cr.current_player_range:cmul(strategy)
cr.current_player_range =
  card_tools:normalize_range(node1.board, cr.current_player_range)

cr.decision_id = cr.decision_id + 1
cr.last_bet = bet
cr.last_node = node1

save("street1.after_action.player_range",
     cr.current_player_range)

save("street1.after_action.opponent_cfvs",
     cr.current_opponent_cfvs_bound)

local node2 = {
  board = arguments.Tensor{2},
  street = 2,
  current_player = constants.players.P1,
  bets = arguments.Tensor{300, 300},
  terminal = false
}

cr:_update_invariant(node2, state)

save("street2.invariant.player_range",
     cr.current_player_range)

save("street2.invariant.opponent_cfvs",
     cr.current_opponent_cfvs_bound)

cr.resolving = Resolving()
cr.resolving:resolve(
  node2,
  cr.current_player_range,
  cr.current_opponent_cfvs_bound
)

save("street2.achieved_cfvs",
     cr.resolving.resolve_results.achieved_cfvs)

save("street2.strategy_all",
     cr.resolving.resolve_results.strategy)

save("street2.children_cfvs_all",
     cr.resolving.resolve_results.children_cfvs)

local possible = cr.resolving:get_possible_actions()
save("street2.possible_actions", possible)

for i = 1, possible:size(1) do
  local action = possible[i]

  save(
    "street2.strategy_" .. tostring(action),
    cr.resolving:get_action_strategy(action)
  )

  save(
    "street2.cfv_" .. tostring(action),
    cr.resolving:get_action_cfv(action)
  )
end

print("PASS: saved Lua street-transition reference trace")
print(possible)
