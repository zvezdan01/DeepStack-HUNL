package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
require "Player.continual_resolving"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local out = arg[1] or "/work/p2_first_lua_trace"
os.execute("rm -rf " .. out)
os.execute("mkdir -p " .. out)

local function save(name, t)
  torch.save(out .. "/" .. name .. ".t7", t:float():contiguous())
end

local cr = ContinualResolving()
local state = {
  position = constants.players.P2,
  hand_id = 6
}
cr:start_new_hand(state)

local node = {
  board = arguments.Tensor{},
  street = 1,
  current_player = constants.players.P2,
  bets = arguments.Tensor{300, 100},
  terminal = false
}

cr:_resolve_node(node, state)

save("initial.player_range", cr.current_player_range)
save("initial.opponent_cfvs", cr.current_opponent_cfvs_bound)
save("resolve.achieved_cfvs", cr.resolving.resolve_results.achieved_cfvs)
save("resolve.strategy_all", cr.resolving.resolve_results.strategy)
save("resolve.children_cfvs_all", cr.resolving.resolve_results.children_cfvs)
save("resolve.possible_actions", cr.resolving:get_possible_actions())

local possible = cr.resolving:get_possible_actions()
for i = 1, possible:size(1) do
  local action = possible[i]
  save("resolve.strategy_" .. tostring(action), cr.resolving:get_action_strategy(action))
  save("resolve.cfv_" .. tostring(action), cr.resolving:get_action_cfv(action))
end

save("starting_cfvs_p1", cr.starting_cfvs_p1)

print("PASS: P2 first resolve trace saved")
