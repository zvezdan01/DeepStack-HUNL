from pathlib import Path
import numpy as np

from deepstack_leduc.acpc import parse_matchstate
from deepstack_leduc.card_tools import normalize_range
from deepstack_leduc.continual_resolving import ContinualResolving
from deepstack_leduc.resolving import Resolving
from deepstack_leduc.torch7_tensor import load_float_tensor
from deepstack_leduc.value_model import load_original_value_net

ROOT = Path("continual_all_chance_histories_lua_trace")
VALUE_NET = load_original_value_net()

CARDS = ["As", "Ah", "Ks", "Kh", "Qs", "Qh"]

HISTORIES = {
    "cc": {
        "decisions": [
            ("", -1),
        ],
        "final": "cc",
    },
    "c_r300_c": {
        "decisions": [
            ("", -1),
            ("cr300", -1),
        ],
        "final": "cr300c",
    },
    "c_r300_r900_c": {
        "decisions": [
            ("", -1),
            ("cr300", 900),
        ],
        "final": "cr300r900c",
    },
    "r300_c": {
        "decisions": [
            ("", 300),
        ],
        "final": "r300c",
    },
    "r300_r900_c": {
        "decisions": [
            ("", 300),
            ("r300r900", -1),
        ],
        "final": "r300r900c",
    },
}


checked = 0
cases = 0
failures = []


def ref(case_dir, name):
    return load_float_tensor(case_dir / f"{name}.t7")


def check(case_dir, name, actual):
    global checked

    expected = ref(case_dir, name)
    actual = np.asarray(actual)

    checked += 1

    if actual.shape != expected.shape:
        failures.append(
            f"{case_dir}: {name}: shape {actual.shape} != {expected.shape}"
        )
        return

    if not np.array_equal(actual, expected, equal_nan=True):
        aa = actual.astype(np.float64)
        bb = expected.astype(np.float64)

        mask = ~(np.isnan(aa) & np.isnan(bb))
        if np.any(mask):
            diff = np.abs(aa[mask] - bb[mask])
            maxerr = float(np.max(diff))
        else:
            maxerr = 0.0

        neq = int(np.sum(~((actual == expected) | (np.isnan(actual) & np.isnan(expected)))))

        failures.append(
            f"{case_dir}: {name}: NOT BIT-EXACT; "
            f"different_elements={neq}, max_abs_error={maxerr}"
        )


def force_action(cr, node, state, bet, case_dir, tag):
    cr._resolve_node(node, state)

    r = cr.resolving

    check(case_dir, f"{tag}.possible_actions", r.get_possible_actions())
    check(case_dir, f"{tag}.strategy_all", r.resolve_results.strategy)
    check(case_dir, f"{tag}.children_cfvs_all", r.resolve_results.children_cfvs)
    check(case_dir, f"{tag}.achieved_cfvs", r.resolve_results.achieved_cfvs)

    strategy = r.get_action_strategy(bet)

    cr.current_opponent_cfvs_bound = r.get_action_cfv(bet).copy()

    cr.current_player_range *= strategy
    cr.current_player_range = normalize_range(
        node.board,
        cr.current_player_range
    ).astype(np.float32)

    check(
        case_dir,
        f"{tag}.after_action.player_range",
        cr.current_player_range
    )
    check(
        case_dir,
        f"{tag}.after_action.opponent_cfvs",
        cr.current_opponent_cfvs_bound
    )

    cr.decision_id += 1
    cr.last_bet = int(bet)
    cr.last_node = node


for hname, spec in HISTORIES.items():

    for private_id, private_card in enumerate(CARDS):

        for board_id, board_card in enumerate(CARDS):

            if board_id == private_id:
                continue

            cases += 1

            case_dir = (
                ROOT
                / hname
                / f"private_{private_id + 1}_board_{board_id + 1}"
            )

            cr = ContinualResolving(value_network=VALUE_NET)

            root_state = parse_matchstate(
                f"MATCHSTATE:0:1::{private_card}|"
            )

            cr.start_new_hand(root_state)

            for decision_index, (history, bet) in enumerate(
                spec["decisions"], start=1
            ):

                state = parse_matchstate(
                    f"MATCHSTATE:0:1:{history}:{private_card}|"
                )

                node = state.to_node()

                force_action(
                    cr,
                    node,
                    state,
                    bet,
                    case_dir,
                    f"d{decision_index}",
                )

            check(
                case_dir,
                "street1.final.player_range",
                cr.current_player_range
            )

            check(
                case_dir,
                "street1.final.opponent_cfvs",
                cr.current_opponent_cfvs_bound
            )

            state2 = parse_matchstate(
                "MATCHSTATE:0:1:" + spec["final"] + "/:" + private_card + "|/" + board_card
            )

            node2 = state2.to_node()

            cr._update_invariant(node2, state2)

            check(
                case_dir,
                "street2.invariant.player_range",
                cr.current_player_range
            )

            check(
                case_dir,
                "street2.invariant.opponent_cfvs",
                cr.current_opponent_cfvs_bound
            )

            cr.resolving = Resolving(cr.cfg, cr.value_network)

            cr.resolving.resolve(
                node2,
                cr.current_player_range,
                cr.current_opponent_cfvs_bound,
            )

            r = cr.resolving

            check(
                case_dir,
                "street2.achieved_cfvs",
                r.resolve_results.achieved_cfvs
            )

            check(
                case_dir,
                "street2.strategy_all",
                r.resolve_results.strategy
            )

            check(
                case_dir,
                "street2.children_cfvs_all",
                r.resolve_results.children_cfvs
            )

            possible = r.get_possible_actions()

            check(
                case_dir,
                "street2.possible_actions",
                possible
            )

            for action in possible:
                action = int(action)

                check(
                    case_dir,
                    f"street2.strategy_{action}",
                    r.get_action_strategy(action)
                )

                check(
                    case_dir,
                    f"street2.cfv_{action}",
                    r.get_action_cfv(action)
                )

            print(
                "PASS",
                hname,
                "private",
                private_id + 1,
                "board",
                board_id + 1
            )


print()
print("CASES:", cases)
print("TENSORS CHECKED:", checked)

if failures:
    print()
    print("FAILURES:", len(failures))

    for failure in failures[:30]:
        print("FAIL:", failure)

    raise SystemExit(1)

print(
    f"PASS: {cases}/150 chance-history cases "
    f"and {checked} tensors bit-exact"
)
