package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
local card_tools = require "Game.card_tools"
require "Player.continual_resolving"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local root_out = arg[1] or "/work/continual_all_chance_histories_lua_trace"
os.execute("rm -rf " .. root_out)
os.execute("mkdir -p " .. root_out)

local function save(dir, name, t)
  torch.save(dir .. "/" .. name .. ".t7", t:float():contiguous())
end

local function node(street, player, b1, b2, board)
  return {
    board = board or arguments.Tensor{},
    street = street,
    current_player = player,
    bets = arguments.Tensor{b1, b2},
    terminal = false
  }
end

local function force_own_action(cr, state, n, bet, dir, tag)
  cr:_resolve_node(n, state)
  local possible = cr.resolving:get_possible_actions()
  save(dir, tag .. ".possible_actions", possible)
  save(dir, tag .. ".strategy_all", cr.resolving.resolve_results.strategy)
  save(dir, tag .. ".children_cfvs_all", cr.resolving.resolve_results.children_cfvs)
  save(dir, tag .. ".achieved_cfvs", cr.resolving.resolve_results.achieved_cfvs)

  local strategy = cr.resolving:get_action_strategy(bet)
  cr.current_opponent_cfvs_bound = cr.resolving:get_action_cfv(bet):clone()
  cr.current_player_range:cmul(strategy)
  cr.current_player_range = card_tools:normalize_range(n.board, cr.current_player_range)

  save(dir, tag .. ".after_action.player_range", cr.current_player_range)
  save(dir, tag .. ".after_action.opponent_cfvs", cr.current_opponent_cfvs_bound)

  cr.decision_id = cr.decision_id + 1
  cr.last_bet = bet
  cr.last_node = n
end

local histories = {
  {
    name = "cc",
    pot = 100,
    play = function(cr, state, dir)
      force_own_action(cr, state, node(1, constants.players.P1, 100,100), constants.actions.ccall, dir, "d1")
    end
  },
  {
    name = "c_r300_c",
    pot = 300,
    play = function(cr, state, dir)
      force_own_action(cr, state, node(1, constants.players.P1, 100,100), constants.actions.ccall, dir, "d1")
      force_own_action(cr, state, node(1, constants.players.P1, 100,300), constants.actions.ccall, dir, "d2")
    end
  },
  {
    name = "c_r300_r900_c",
    pot = 900,
    play = function(cr, state, dir)
      force_own_action(cr, state, node(1, constants.players.P1, 100,100), constants.actions.ccall, dir, "d1")
      force_own_action(cr, state, node(1, constants.players.P1, 100,300), 900, dir, "d2")
    end
  },
  {
    name = "r300_c",
    pot = 300,
    play = function(cr, state, dir)
      force_own_action(cr, state, node(1, constants.players.P1, 100,100), 300, dir, "d1")
    end
  },
  {
    name = "r300_r900_c",
    pot = 900,
    play = function(cr, state, dir)
      force_own_action(cr, state, node(1, constants.players.P1, 100,100), 300, dir, "d1")
      force_own_action(cr, state, node(1, constants.players.P1, 300,900), constants.actions.ccall, dir, "d2")
    end
  }
}

local count = 0
for _, h in ipairs(histories) do
  for private_id = 1, 6 do
    for board_id = 1, 6 do
      if board_id ~= private_id then
        local dir = root_out .. "/" .. h.name .. "/private_" .. tostring(private_id) .. "_board_" .. tostring(board_id)
        os.execute("mkdir -p " .. dir)

        local cr = ContinualResolving()
        local state = { position = constants.players.P1, hand_id = private_id }
        cr:start_new_hand(state)

        h.play(cr, state, dir)

        local street1_resolving = cr.resolving
        local last_bet = cr.last_bet
        local last_node = cr.last_node
        local pre_range = cr.current_player_range:clone()
        local pre_cfvs = cr.current_opponent_cfvs_bound:clone()

        save(dir, "street1.final.player_range", pre_range)
        save(dir, "street1.final.opponent_cfvs", pre_cfvs)

        local node2 = node(2, constants.players.P1, h.pot, h.pot, arguments.Tensor{board_id})

        cr.resolving = street1_resolving
        cr.last_bet = last_bet
        cr.last_node = last_node
        cr.current_player_range = pre_range:clone()
        cr.current_opponent_cfvs_bound = pre_cfvs:clone()

        cr :_update_invariant(node2, state)
        save(dir, "street2.invariant.player_range", cr.current_player_range)
        save(dir, "street2.invariant.opponent_cfvs", cr.current_opponent_cfvs_bound)

        cr.resolving = Resolving()
        cr.resolving:resolve(node2, cr.current_player_range, cr.current_opponent_cfvs_bound)

        save(dir, "street2.achieved_cfvs", cr.resolving.resolve_results.achieved_cfvs)
        save(dir, "street2.strategy_all", cr.resolving.resolve_results.strategy)
        save(dir, "street2.children_cfvs_all", cr.resolving.resolve_results.children_cfvs)

        local possible = cr.resolving:get_possible_actions()
        save(dir, "street2.possible_actions", possible)
        for i = 1, possible:size(1) do
          local action = possible[i]
          save(dir, "street2.strategy_" .. tostring(action), cr.resolving:get_action_strategy(action))
          save(dir, "street2.cfv_" .. tostring(action), cr.resolving:get_action_cfv(action))
        end

        count = count + 1
        print("PASS", h.name, "private", private_id, "board", board_id)
      end
    end
  end
end

print("PASS: saved", count, "chance-history/private-card/board traces")
