package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
require "Tree.tree_builder"
require "TerminalEquity.terminal_equity"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local out_root = "/work/terminal_all_street1_lua_trace"
os.execute("rm -rf " .. out_root)
os.execute("mkdir -p " .. out_root)

local builder = PokerTreeBuilder()
local root = {
  street = 1,
  board = arguments.Tensor{},
  current_player = constants.players.P1,
  bets = arguments.Tensor{arguments.ante, arguments.ante}
}

local tree = builder:build_tree{root_node=root, limit_to_street=false}

local ranges = arguments.Tensor(2, 6)
ranges[1] = arguments.Tensor{0.05, 0.10, 0.15, 0.20, 0.22, 0.28}
ranges[2] = arguments.Tensor{0.11, 0.13, 0.17, 0.19, 0.18, 0.22}

local function mkdir(path)
  os.execute("mkdir -p " .. path)
end

local function save_tensor(path, t)
  torch.save(path, t:float():contiguous())
end

local function terminal_type_name(node)
  if node.type == constants.node_types.terminal_fold then
    return "fold"
  elseif node.type == constants.node_types.terminal_call then
    return "call"
  end
  return "unknown"
end

local function player_zero_based(p)
  return p - 1
end

local count = 0
local fold_count = 0
local call_count = 0
local manifest = assert(io.open(out_root .. "/manifest.tsv", "w"))
manifest:write("index\tpath\ttype\tstreet\tcurrent_player\tfolding_player\tbet1\tbet2\tpot\tboard_cards\n")

local function save_terminal(node, path)
  count = count + 1

  local kind = terminal_type_name(node)
  if kind == "fold" then
    fold_count = fold_count + 1
  elseif kind == "call" then
    call_count = call_count + 1
  end

  local dir = string.format("%s/leaf_%02d", out_root, count)
  mkdir(dir)

  local te = TerminalEquity()
  te:set_board(node.board)

  local raw = arguments.Tensor(2, 6):zero()
  local folding_player = -1

  if kind == "fold" then
    folding_player = 3 - node.current_player
    te:tree_node_fold_value(ranges, raw, folding_player)
  else
    te:tree_node_call_value(ranges, raw)
  end

  local scaled = raw * node.pot

  save_tensor(dir .. "/ranges.t7", ranges)
  save_tensor(dir .. "/raw_values.t7", raw)
  save_tensor(dir .. "/scaled_values.t7", scaled)
  save_tensor(dir .. "/call_matrix.t7", te:get_call_matrix())
  save_tensor(dir .. "/fold_matrix.t7", te.fold_matrix)
  save_tensor(dir .. "/bets.t7", node.bets)

  local board_cards = node.board and node.board:numel() or 0

  manifest:write(
    tostring(count), "\t",
    path, "\t",
    kind, "\t",
    tostring(node.street), "\t",
    tostring(player_zero_based(node.current_player)), "\t",
    tostring(folding_player == -1 and -1 or player_zero_based(folding_player)), "\t",
    tostring(node.bets[1]), "\t",
    tostring(node.bets[2]), "\t",
    tostring(node.pot), "\t",
    tostring(board_cards), "\n"
  )

  print(string.format(
    "PASS leaf %02d %-4s path=%s bets=%.0f,%.0f pot=%.0f current=%d folding=%d",
    count, kind, path, node.bets[1], node.bets[2], node.pot,
    player_zero_based(node.current_player),
    folding_player == -1 and -1 or player_zero_based(folding_player)
  ))
end

local function walk(node, path)
  if node.terminal and node.street == 1 then
    save_terminal(node, path)
    return
  end

  if node.children then
    for i = 1, #node.children do
      walk(node.children[i], path .. "." .. tostring(i - 1))
    end
  end
end

walk(tree, "R")
manifest:close()

assert(count == 18, "Expected exactly 18 first-street terminal leaves, got " .. tostring(count))

print("TERMINAL LEAVES:", count)
print("FOLDS:", fold_count)
print("CALLS:", call_count)
print("PASS: saved all 18 first-street terminal leaf traces")
