require "torch"
require "nn"
package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

local arguments = require "Settings.arguments"
arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local model = torch.load("../Data/Models/PotBet/final_cpu.model")
local x = torch.load("/work/nn_root_trace/inputs_3.t7"):float():contiguous()
x = x:view(-1, x:size(3))

local ff = model.modules[1].modules[1]

local out = x
torch.save("/work/nn_root_trace/layer_00_input.t7", out:float():contiguous())

for i,m in ipairs(ff.modules) do
  out = m:forward(out)
  torch.save(
    string.format("/work/nn_root_trace/layer_%02d.t7", i),
    out:float():contiguous()
  )
  print(i, torch.type(m), table.concat(out:size():totable(), "x"))
end

print("saved Lua NN layer trace")
