require "torch"
package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
local card_tools = require "Game.card_tools"
require "Lookahead.resolving"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local out="/work/nn_root_trace"
os.execute("mkdir -p "..out)

local node = {}
node.board = arguments.Tensor{}
node.street = 1
node.current_player = constants.players.P1
node.bets = arguments.Tensor{arguments.ante, arguments.ante}

local player_range = card_tools:get_uniform_range(node.board)
local opponent_range = card_tools:get_uniform_range(node.board)

local resolving = Resolving()
resolving:resolve_first_node(node, player_range, opponent_range)

local found = false
for i,box in pairs(resolving.lookahead.next_street_boxes or {}) do
  if box.next_round_inputs and box.next_round_values then
    torch.save(out.."/inputs_"..i..".t7", box.next_round_inputs:float():contiguous())
    torch.save(out.."/values_"..i..".t7", box.next_round_values:float():contiguous())
    print("saved box "..i)
    found = true
  end
end

assert(found, "no next street NN box found")
print("saved NN root trace")
