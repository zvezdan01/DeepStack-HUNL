package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
require "Tree.tree_builder"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local builder = PokerTreeBuilder()
local root = {
  street = 1,
  board = arguments.Tensor{},
  current_player = constants.players.P1,
  bets = arguments.Tensor{arguments.ante, arguments.ante},
  terminal = false
}

local tree = builder:build_tree({
  root_node = root,
  limit_to_street = false
})

local function action_name(a)
  if a == constants.actions.fold then return "FOLD" end
  if a == constants.actions.ccall then return "CALL/CHECK" end
  return "RAISE_" .. tostring(a)
end

local function walk(node, path)
  if node.terminal then
    print("TERMINAL | " .. path ..
          " | street=" .. tostring(node.street) ..
          " | bets=" .. tostring(node.bets[1]) .. "," .. tostring(node.bets[2]))
    return
  end

  if node.current_player == constants.players.chance then
    print("CHANCE   | " .. path ..
          " | bets=" .. tostring(node.bets[1]) .. "," .. tostring(node.bets[2]))
    return
  end

  if node.street ~= 1 then
    print("STREET2  | " .. path ..
          " | bets=" .. tostring(node.bets[1]) .. "," .. tostring(node.bets[2]))
    return
  end

  if not node.actions or not torch.isTensor(node.actions) or node.actions:dim() ~= 1 then
    return
  end

  for i = 1, node.actions:size(1) do
    local a = node.actions[i]
    local child = node.children[i]
    walk(child, path .. "/" .. action_name(a))
  end
end

walk(tree, "ROOT")
