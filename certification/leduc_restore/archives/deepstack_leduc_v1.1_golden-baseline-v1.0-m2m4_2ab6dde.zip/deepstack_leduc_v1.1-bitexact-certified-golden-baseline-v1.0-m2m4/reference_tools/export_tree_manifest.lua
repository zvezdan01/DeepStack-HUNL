package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"
require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
require "Tree.tree_builder"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local b = PokerTreeBuilder()
local r = {
  street = 1,
  board = arguments.Tensor{},
  current_player = constants.players.P1,
  bets = arguments.Tensor{arguments.ante, arguments.ante}
}

local t = b:build_tree{root_node=r, limit_to_street=false}
local f = assert(io.open("lua_tree_manifest.tsv", "w"))
local idx = 0

local function player(p)
  if p == constants.players.chance then return -1 end
  return p - 1
end

local function board_str(node)
  if not node.board or node.board:numel() == 0 then return "-" end
  local x = {}
  for i=1,node.board:numel() do
    x[#x+1] = tostring(node.board[i] - 1)
  end
  return table.concat(x, ",")
end

local function actions_str(node)
  if node.current_player == constants.players.chance then return "chance" end
  if not node.actions or not torch.isTensor(node.actions) or node.actions:dim() ~= 1 then return "-" end
  local x = {}
  for i=1,node.actions:size(1) do x[#x+1] = tostring(node.actions[i]) end
  return table.concat(x,",")
end

local function walk(node, path)
  idx = idx + 1
  local children = node.children and #node.children or 0
  local term = node.terminal and 1 or 0
  f:write(tostring(idx),"\t",path,"\t",tostring(node.street),"\t",tostring(player(node.current_player)),"\t",tostring(node.bets[1]),",",tostring(node.bets[2]),"\t",board_str(node),"\t",tostring(term),"\t",tostring(children),"\t",actions_str(node),"\n")
  if node.children then
    for i=1,#node.children do walk(node.children[i], path .. "." .. tostring(i-1)) end
  end
end

walk(t,"R")
f:close()
print("LUA MASHES", idx)
