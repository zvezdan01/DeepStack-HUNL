
package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"
require "torch"
require "TerminalEquity.terminal_equity"

local out = "/work/terminal_e2e_lua"
os.execute("mkdir -p " .. out)

local te = TerminalEquity()
local board = torch.FloatTensor{2}
te:set_board(board)

torch.save(out .. "/call_matrix.t7", te:get_call_matrix():float():contiguous())
torch.save(out .. "/fold_matrix.t7", te.fold_matrix:float():contiguous())

local ranges = torch.FloatTensor(2,6):zero()
ranges[1][1] = 1
ranges[2][3] = 1

local call_result = torch.FloatTensor(2,6):zero()
te:tree_node_call_value(ranges, call_result)
torch.save(out .. "/call_result.t7", call_result:float():contiguous())

print("PASS: saved Lua terminal showdown trace")
print(call_result)
