from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

from deepstack_leduc.acpc import parse_matchstate
from deepstack_leduc.continual_resolving import ContinualResolving
from deepstack_leduc.torch7_tensor import load_float_tensor
from deepstack_leduc.value_model import load_original_value_net


ROOT = Path("p2_all_street1_lua_trace")
CARDS = ["As", "Ah", "Ks", "Kh", "Qs", "Qh"]

CASES = [
    {
        "name": "c",
        "target_actions": "c",
    },
    {
        "name": "r300",
        "target_actions": "r300",
    },
    {
        "name": "r1200",
        "target_actions": "r1200",
    },
    {
        "name": "c_r300_r900",
        "prior_actions": "c",
        "prior_action": 300,
        "target_actions": "cr300r900",
    },
    {
        "name": "c_r300_r1200",
        "prior_actions": "c",
        "prior_action": 300,
        "target_actions": "cr300r1200",
    },
    {
        "name": "r300_r900_r1200",
        "prior_actions": "r300",
        "prior_action": 900,
        "target_actions": "r300r900r1200",
    },
]


def load_lua(case_name: str, private_id: int, name: str) -> np.ndarray:
    p = ROOT / case_name / f"private_{private_id}" / f"{name}.t7"
    return np.asarray(load_float_tensor(p), dtype=np.float32)


def exact_equal(actual, expected) -> bool:
    a = np.asarray(actual, dtype=np.float32)
    e = np.asarray(expected, dtype=np.float32)
    return a.shape == e.shape and np.array_equal(a, e, equal_nan=True)


def compare(case_name: str, private_id: int, name: str, actual, failures: list[str]) -> int:
    expected = load_lua(case_name, private_id, name)
    actual = np.asarray(actual, dtype=np.float32)

    if exact_equal(actual, expected):
        return 1

    msg = f"{case_name}/private_{private_id}/{name}"
    if actual.shape != expected.shape:
        failures.append(
            f"{msg}: shape python={actual.shape} lua={expected.shape}"
        )
        return 1

    same = (actual == expected) | (np.isnan(actual) & np.isnan(expected))
    diff = ~same
    n = int(diff.sum())

    if n:
        aa = actual.astype(np.float64)[diff]
        ee = expected.astype(np.float64)[diff]
        max_abs = float(np.max(np.abs(aa - ee)))
    else:
        max_abs = 0.0

    failures.append(f"{msg}: {n} values differ, max_abs={max_abs}")
    return 1


def matchstate(actions: str, private_card: str):
    # ACPC position 1 = DeepStack is P2; P2's private hand is after the '|'.
    return parse_matchstate(f"MATCHSTATE:1:1:{actions}:|{private_card}")


def normalize_current_range(cr: ContinualResolving, board) -> None:
    # Use the port's own normalization path if available.
    # This mirrors Lua card_tools:normalize_range(board, range).
    if hasattr(cr, "_normalize_range"):
        cr.current_player_range = cr._normalize_range(
            board, cr.current_player_range
        )
        return

    # Fallback matching the street-1 case: no public card, so only normalization
    # of the already masked six-card vector is needed. Torch7 semantics in the
    # port are preserved by the float32 sum path used elsewhere in certification.
    r = np.asarray(cr.current_player_range, dtype=np.float32)
    total = np.float32(np.sum(r, dtype=np.float64))
    cr.current_player_range = np.asarray(r / total, dtype=np.float32)


def save_resolve_comparisons(
    cr: ContinualResolving,
    case_name: str,
    private_id: int,
    prefix: str,
    failures: list[str],
) -> int:
    checked = 0
    r = cr.resolving

    checked += compare(
        case_name, private_id, f"{prefix}.player_range",
        cr.current_player_range, failures
    )
    checked += compare(
        case_name, private_id, f"{prefix}.opponent_cfvs",
        cr.current_opponent_cfvs_bound, failures
    )
    checked += compare(
        case_name, private_id, f"{prefix}.achieved_cfvs",
        r.resolve_results.achieved_cfvs, failures
    )
    checked += compare(
        case_name, private_id, f"{prefix}.strategy_all",
        r.resolve_results.strategy, failures
    )
    checked += compare(
        case_name, private_id, f"{prefix}.children_cfvs_all",
        r.resolve_results.children_cfvs, failures
    )

    possible = np.asarray(r.get_possible_actions())
    checked += compare(
        case_name, private_id, f"{prefix}.possible_actions",
        possible, failures
    )

    for action in possible.reshape(-1):
        action_i = int(action)
        checked += compare(
            case_name, private_id, f"{prefix}.strategy_{action_i}",
            r.get_action_strategy(action_i), failures
        )
        checked += compare(
            case_name, private_id, f"{prefix}.cfv_{action_i}",
            r.get_action_cfv(action_i), failures
        )

    return checked


def main() -> int:
    if not ROOT.exists():
        print(f"ERROR: missing Lua trace directory: {ROOT}")
        return 2

    value_net = load_original_value_net()

    failures: list[str] = []
    tensors_checked = 0
    cases_checked = 0

    for spec in CASES:
        name = spec["name"]

        for private_id, private_card in enumerate(CARDS, start=1):
            target_state = matchstate(spec["target_actions"], private_card)

            cr = ContinualResolving(value_network=value_net)
            cr.start_new_hand(target_state)

            if "prior_actions" in spec:
                prior_state = matchstate(spec["prior_actions"], private_card)
                prior_node = prior_state.to_node()

                cr._resolve_node(prior_node, prior_state)

                tensors_checked += save_resolve_comparisons(
                    cr, name, private_id, "prior.resolve", failures
                )

                prior_action = int(spec["prior_action"])
                strategy = np.asarray(
                    cr.resolving.get_action_strategy(prior_action),
                    dtype=np.float32,
                )

                cr.current_opponent_cfvs_bound = np.asarray(
                    cr.resolving.get_action_cfv(prior_action),
                    dtype=np.float32,
                ).copy()

                cr.current_player_range = np.asarray(
                    cr.current_player_range, dtype=np.float32
                )
                cr.current_player_range *= strategy
                normalize_current_range(cr, prior_node.board)

                tensors_checked += compare(
                    name, private_id, "prior.after_action.player_range",
                    cr.current_player_range, failures
                )
                tensors_checked += compare(
                    name, private_id, "prior.after_action.opponent_cfvs",
                    cr.current_opponent_cfvs_bound, failures
                )

                cr.decision_id += 1
                cr.last_bet = prior_action
                cr.last_node = prior_node

            target_node = target_state.to_node()
            cr._resolve_node(target_node, target_state)

            tensors_checked += save_resolve_comparisons(
                cr, name, private_id, "target", failures
            )

            tensors_checked += compare(
                name, private_id, "starting_cfvs_p1",
                cr.starting_cfvs_p1, failures
            )

            cases_checked += 1

            if failures:
                # Do not print a false per-case PASS. Show status based only on
                # failures belonging to this case/private pair.
                tag = f"{name}/private_{private_id}/"
                this_fail = any(f.startswith(tag) for f in failures)
            else:
                this_fail = False

            print(
                ("FAIL" if this_fail else "PASS"),
                name,
                "private",
                private_id,
            )

    print()
    print(f"CASES: {cases_checked}")
    print(f"TENSORS CHECKED: {tensors_checked}")

    if failures:
        print(f"FAILURES: {len(failures)}")
        for f in failures[:50]:
            print(" -", f)
        if len(failures) > 50:
            print(f" ... and {len(failures) - 50} more")
        return 1

    print(
        f"PASS: {cases_checked}/{cases_checked} P2 street1 cases "
        f"and {tensors_checked} tensors bit-exact"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
