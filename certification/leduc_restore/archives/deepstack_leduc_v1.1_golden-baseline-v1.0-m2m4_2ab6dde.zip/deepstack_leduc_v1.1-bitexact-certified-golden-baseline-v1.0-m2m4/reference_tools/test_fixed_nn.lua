require "torch"
package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

local arguments = require "Settings.arguments"
arguments.gpu = false
arguments.Tensor = torch.FloatTensor

require "Nn.value_nn"

local x = torch.load("/work/nn_root_trace/inputs_3.t7"):float():contiguous()
local flat = x:view(-1, x:size(3))

local nn = ValueNn()
local y = torch.FloatTensor(flat:size(1), 72):zero()
nn:get_value(flat, y)

torch.save("/work/nn_root_trace/raw_lua_output.t7", y:contiguous())
print("saved fixed-input Lua NN output", flat:size(1), flat:size(2))
