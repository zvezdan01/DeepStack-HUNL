from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np

from deepstack_leduc.config import Config
from deepstack_leduc.lookahead import Lookahead
from deepstack_leduc.torch7_tensor import load_float_tensor
from deepstack_leduc.tree import Node, PokerTreeBuilder


STAGES = (
    "opponent_range",
    "current_strategy",
    "ranges",
    "average_strategy",
    "terminal_cfvs",
    "current_cfvs",
    "regrets",
    "average_cfvs",
)

FIELDS = (
    "ranges_data",
    "cfvs_data",
    "regrets_data",
    "positive_regrets_data",
    "current_strategy_data",
    "average_strategies_data",
    "average_cfvs_data",
)


def make_ranges(private_id: int, board_id: int) -> tuple[np.ndarray, np.ndarray]:
    """Match export_street2_exhaustive.lua exactly.

    private_id and board_id are Lua-style 1..6 card ids.
    """
    p = np.zeros(6, dtype=np.float32)
    o = np.zeros(6, dtype=np.float32)

    p[private_id - 1] = np.float32(1.0)

    weights = (1, 2, 3, 4, 5, 6)
    total = 0
    for i in range(1, 7):
        if i != private_id and i != board_id:
            o[i - 1] = np.float32(weights[i - 1])
            total += weights[i - 1]

    # Torch7 FloatTensor:div(number): elementwise float32 store.
    o /= np.float32(total)
    return p, o


def snapshot(look: Lookahead) -> dict[str, np.ndarray]:
    out: dict[str, np.ndarray] = {}
    for field in FIELDS:
        table = getattr(look, field)
        if table is None:
            continue
        # Lua tables use 1-based depth keys; Python port deliberately keeps
        # these dictionaries keyed by the same Lua depth numbers.
        for depth, tensor in table.items():
            if tensor is None:
                continue
            out[f"{field}.{depth}"] = np.ascontiguousarray(
                np.asarray(tensor, dtype=np.float32)
            ).copy()
    return out


def build_python_trace(
    pot: int, private_id: int, board_id: int
) -> tuple[dict[str, dict[str, np.ndarray]], int]:
    cfg = Config(cfr_iters=1, cfr_skip_iters=0)

    # Lua board ids are 1..6; Python card ids are 0..5.
    root = Node(
        2,
        0,
        np.asarray([float(pot), float(pot)], dtype=np.float32),
        (board_id - 1,),
    )
    root = PokerTreeBuilder(cfg).build_tree(root, limit_to_street=True)

    look = Lookahead(cfg)
    look.build_lookahead(root)

    p, o = make_ranges(private_id, board_id)
    look.ranges_data[1][..., 0, :] = p
    look.ranges_data[1][..., 1, :] = o

    trace: dict[str, dict[str, np.ndarray]] = {}

    look._set_opponent_starting_range(1)
    trace["opponent_range"] = snapshot(look)

    look._compute_current_strategies()
    trace["current_strategy"] = snapshot(look)

    look._compute_ranges()
    trace["ranges"] = snapshot(look)

    look._compute_update_average_strategies(1)
    trace["average_strategy"] = snapshot(look)

    look._compute_terminal_equities()
    trace["terminal_cfvs"] = snapshot(look)

    look._compute_cfvs()
    trace["current_cfvs"] = snapshot(look)

    look._compute_regrets()
    trace["regrets"] = snapshot(look)

    look._compute_cumulate_average_cfvs(1)
    trace["average_cfvs"] = snapshot(look)

    return trace, int(look.depth)


def max_abs_error(a: np.ndarray, b: np.ndarray) -> float:
    aa = a.astype(np.float64, copy=False)
    bb = b.astype(np.float64, copy=False)
    with np.errstate(invalid="ignore"):
        diff = np.abs(aa - bb)
    finite = diff[np.isfinite(diff)]
    if finite.size:
        return float(finite.max())
    if np.array_equal(np.isnan(a), np.isnan(b)):
        return 0.0
    return float("inf")


def parse_manifest(path: Path) -> list[tuple[int, int, int, int, int]]:
    rows: list[tuple[int, int, int, int, int]] = []
    lines = path.read_text(encoding="utf-8").splitlines()
    if not lines:
        raise RuntimeError("empty manifest")
    if lines[0].strip() != "case\tpot\tprivate_id\tboard_id\tdepth":
        raise RuntimeError(f"unexpected manifest header: {lines[0]!r}")
    for line in lines[1:]:
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) != 5:
            raise RuntimeError(f"bad manifest row: {line!r}")
        rows.append(tuple(map(int, parts)))
    return rows


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "lua_trace",
        nargs="?",
        type=Path,
        default=Path("street2_exhaustive_lua_trace"),
    )
    ns = ap.parse_args()

    root = ns.lua_trace
    manifest = parse_manifest(root / "manifest.tsv")
    if len(manifest) != 90:
        raise SystemExit(f"FAIL: expected 90 manifest cases, got {len(manifest)}")

    failures: list[str] = []
    checked = 0
    passed_cases = 0

    for case_no, pot, private_id, board_id, lua_depth in manifest:
        case_name = f"pot_{pot}_private_{private_id}_board_{board_id}"
        case_dir = root / case_name
        if not case_dir.is_dir():
            failures.append(f"{case_name}: missing case directory")
            continue

        py, py_depth = build_python_trace(pot, private_id, board_id)
        case_failures_before = len(failures)

        if py_depth != lua_depth:
            failures.append(
                f"{case_name}: depth Python={py_depth} Lua={lua_depth}"
            )

        # Inputs are also checked exactly.
        p, o = make_ranges(private_id, board_id)
        for input_name, actual in (
            ("input.player_range", p),
            ("input.opponent_range", o),
        ):
            path = case_dir / f"{input_name}.t7"
            if not path.exists():
                failures.append(f"{case_name}: missing {path.name}")
                continue
            reference = load_float_tensor(path)
            checked += 1
            if actual.shape != reference.shape:
                failures.append(
                    f"{case_name}/{input_name}: shape "
                    f"{actual.shape} != {reference.shape}"
                )
            elif not np.array_equal(actual, reference):
                failures.append(
                    f"{case_name}/{input_name}: max_abs="
                    f"{max_abs_error(actual, reference)}"
                )

        seen_reference: set[str] = set()

        for path in sorted(case_dir.glob("*.t7")):
            stem = path.stem
            if stem.startswith("input."):
                continue

            stage, sep, key = stem.partition(".")
            if not sep or stage not in STAGES:
                failures.append(f"{case_name}: unexpected reference tensor {stem}")
                continue

            seen_reference.add(stem)

            actual = py.get(stage, {}).get(key)
            if actual is None:
                failures.append(f"{case_name}/{stem}: missing in Python trace")
                continue

            reference = load_float_tensor(path)
            checked += 1

            if actual.shape != reference.shape:
                failures.append(
                    f"{case_name}/{stem}: shape "
                    f"{actual.shape} != {reference.shape}"
                )
                continue

            # Zero tolerance: no allclose, no epsilon.
            if not np.array_equal(actual, reference):
                differing = int(np.count_nonzero(actual != reference))
                failures.append(
                    f"{case_name}/{stem}: {differing} values differ, "
                    f"max_abs={max_abs_error(actual, reference)}"
                )

        # Also make sure Python did not produce a tensor that the Lua exporter
        # should have saved but omitted.
        expected_reference = {
            f"{stage}.{key}"
            for stage in STAGES
            for key in py.get(stage, {})
        }
        missing_ref = sorted(expected_reference - seen_reference)
        for stem in missing_ref:
            failures.append(f"{case_name}/{stem}: missing in Lua reference trace")

        if len(failures) == case_failures_before:
            passed_cases += 1
            print(
                f"PASS case {case_no:02d} pot={pot} "
                f"private={private_id} board={board_id} depth={py_depth}"
            )
        else:
            print(
                f"FAIL case {case_no:02d} pot={pot} "
                f"private={private_id} board={board_id}"
            )

    print()
    print(f"CASES: {len(manifest)}")
    print(f"TENSORS CHECKED: {checked}")

    if failures:
        print(f"FAILURES: {len(failures)}")
        for item in failures:
            print(f"FAIL {item}")
        raise SystemExit(1)

    print(
        f"PASS: {passed_cases}/90 exhaustive street-2 cases "
        f"and {checked} tensors bit-exact"
    )


if __name__ == "__main__":
    main()
