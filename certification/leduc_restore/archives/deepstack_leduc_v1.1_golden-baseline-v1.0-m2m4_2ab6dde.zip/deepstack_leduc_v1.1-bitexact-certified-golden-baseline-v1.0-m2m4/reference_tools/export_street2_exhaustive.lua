-- Exhaustive street-2 one-CFR-iteration reference exporter.
-- Covers:
--   3 starting pots: 100, 300, 900
--   6 private cards x 5 legal public boards = 30 combinations per pot
--   90 total cases
--
-- Each case builds the complete street-2 lookahead and snapshots the same
-- internal CFR stages used by export_one_iteration.lua.

package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
require "Tree.tree_builder"
require "Lookahead.lookahead"

arguments.cfr_iters = 1
arguments.cfr_skip_iters = 0
arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local root_out = arg[1] or "/work/street2_exhaustive_lua_trace"
os.execute("mkdir -p " .. root_out)

local pots = {100, 300, 900}

local function save_tensor(dir, name, tensor)
  if tensor == nil then return end
  torch.save(dir .. "/" .. name .. ".t7", tensor:float():contiguous())
end

local function save_layers(dir, prefix, table_value)
  if table_value == nil then return end
  for d, tensor in pairs(table_value) do
    if type(d) == "number" and torch.isTensor(tensor) then
      save_tensor(dir, prefix .. "." .. tostring(d), tensor)
    end
  end
end

local function snapshot(dir, look, stage)
  save_layers(dir, stage .. ".ranges_data", look.ranges_data)
  save_layers(dir, stage .. ".cfvs_data", look.cfvs_data)
  save_layers(dir, stage .. ".regrets_data", look.regrets_data)
  save_layers(dir, stage .. ".positive_regrets_data", look.positive_regrets_data)
  save_layers(dir, stage .. ".current_strategy_data", look.current_strategy_data)
  save_layers(dir, stage .. ".average_strategies_data", look.average_strategies_data)
  save_layers(dir, stage .. ".average_cfvs_data", look.average_cfvs_data)
end

local function make_ranges(private_id, board_id)
  local p = arguments.Tensor(6):zero()
  local o = arguments.Tensor(6):zero()

  -- Player range: exact private-card basis state.
  p[private_id] = 1

  -- Opponent range: deterministic legal-card distribution.
  -- Values are integers then normalized by an exactly specified Torch sum.
  local weights = {1, 2, 3, 4, 5, 6}
  local total = 0
  for i = 1, 6 do
    if i ~= private_id and i ~= board_id then
      o[i] = weights[i]
      total = total + weights[i]
    end
  end
  o:div(total)

  return p, o
end

local manifest = assert(io.open(root_out .. "/manifest.tsv", "w"))
manifest:write("case\tpot\tprivate_id\tboard_id\tdepth\n")

local case_count = 0

for _, pot in ipairs(pots) do
  for private_id = 1, 6 do
    for board_id = 1, 6 do
      if board_id ~= private_id then
        case_count = case_count + 1
        local case_name = string.format(
          "pot_%d_private_%d_board_%d", pot, private_id, board_id
        )
        local out_dir = root_out .. "/" .. case_name
        os.execute("mkdir -p " .. out_dir)

        local node = {
          board = arguments.Tensor{board_id},
          street = 2,
          current_player = constants.players.P1,
          bets = arguments.Tensor{pot, pot},
          terminal = false
        }

        local tree_builder = PokerTreeBuilder()
        local tree = tree_builder:build_tree({
          root_node = node,
          limit_to_street = true
        })

        local look = Lookahead()
        look:build_lookahead(tree)

        local p, o = make_ranges(private_id, board_id)
        look.ranges_data[1][{{}, {}, {}, 1, {}}]:copy(p)
        look.ranges_data[1][{{}, {}, {}, 2, {}}]:copy(o)

        save_tensor(out_dir, "input.player_range", p)
        save_tensor(out_dir, "input.opponent_range", o)

        look:_set_opponent_starting_range(1)
        snapshot(out_dir, look, "opponent_range")

        look:_compute_current_strategies()
        snapshot(out_dir, look, "current_strategy")

        look:_compute_ranges()
        snapshot(out_dir, look, "ranges")

        look:_compute_update_average_strategies(1)
        snapshot(out_dir, look, "average_strategy")

        look:_compute_terminal_equities()
        snapshot(out_dir, look, "terminal_cfvs")

        look:_compute_cfvs()
        snapshot(out_dir, look, "current_cfvs")

        look:_compute_regrets()
        snapshot(out_dir, look, "regrets")

        look:_compute_cumulate_average_cfvs(1)
        snapshot(out_dir, look, "average_cfvs")

        manifest:write(
          tostring(case_count), "\t",
          tostring(pot), "\t",
          tostring(private_id), "\t",
          tostring(board_id), "\t",
          tostring(look.depth), "\n"
        )

        print(
          "PASS case", case_count,
          "pot", pot,
          "private", private_id,
          "board", board_id,
          "depth", look.depth
        )
      end
    end
  end
end

manifest:close()

assert(case_count == 90, "expected 90 cases, got " .. tostring(case_count))
print("CASES:", case_count)
print("PASS: saved 90 exhaustive street-2 one-iteration traces")
