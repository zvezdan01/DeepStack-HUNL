-- Run from the root of the original DeepStack-Leduc repository with Torch7:
--   th /path/to/export_one_iteration.lua /tmp/deepstack_lua_trace
-- Produces standalone torch.FloatTensor files for one CFR iteration.

local out_dir = arg[1] or 'lua_trace'
os.execute('mkdir -p ' .. out_dir)

package.path = package.path .. ';./Source/?.lua;./Source/?/init.lua'
require 'torch'
local arguments = require 'Settings.arguments'
local constants = require 'Settings.constants'
local card_to_string = require 'Game.card_to_string_conversion'
local card_tools = require 'Game.card_tools'
require 'Tree.tree_builder'
require 'Lookahead.lookahead'

arguments.cfr_iters = 1
arguments.cfr_skip_iters = 0
arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local function save_tensor(name, tensor)
  if tensor == nil then return end
  torch.save(out_dir .. '/' .. name .. '.t7', tensor:float():contiguous())
end

local function save_layers(prefix, table_value)
  if table_value == nil then return end
  for d, tensor in pairs(table_value) do
    if type(d) == 'number' and torch.isTensor(tensor) then
      save_tensor(prefix .. '.' .. tostring(d), tensor)
    end
  end
end

local function snapshot(look, stage)
  save_layers(stage .. '.ranges_data', look.ranges_data)
  save_layers(stage .. '.cfvs_data', look.cfvs_data)
  save_layers(stage .. '.regrets_data', look.regrets_data)
  save_layers(stage .. '.current_strategy_data', look.current_strategy_data)
  save_layers(stage .. '.average_strategies_data', look.average_strategies_data)
  save_layers(stage .. '.average_cfvs_data', look.average_cfvs_data)
  if look.reconstruction_gadget then
    local g = look.reconstruction_gadget
    save_tensor(stage .. '.gadget.play_current_strategy', g.play_current_strategy)
    save_tensor(stage .. '.gadget.terminate_current_strategy', g.terminate_current_strategy)
    save_tensor(stage .. '.gadget.play_regrets', g.play_regrets)
    save_tensor(stage .. '.gadget.terminate_regrets', g.terminate_regrets)
  end
end

local node = {}
node.board = card_to_string:string_to_board('As')
node.street = 2
node.current_player = constants.players.P1
node.bets = arguments.Tensor{100, 100}

local tree_builder = PokerTreeBuilder()
local tree = tree_builder:build_tree({root_node = node, limit_to_street = true})
local look = Lookahead()
look:build_lookahead(tree)

local p = arguments.Tensor{0, 0.10, 0.20, 0.30, 0.15, 0.25}
local o = arguments.Tensor{0, 0.25, 0.15, 0.10, 0.20, 0.30}
look.ranges_data[1][{{}, {}, {}, 1, {}}]:copy(p)
look.ranges_data[1][{{}, {}, {}, 2, {}}]:copy(o)

look:_set_opponent_starting_range(1)
snapshot(look, 'opponent_range')
look:_compute_current_strategies()
snapshot(look, 'current_strategy')
look:_compute_ranges()
snapshot(look, 'ranges')
look:_compute_update_average_strategies(1)
snapshot(look, 'average_strategy')
look:_compute_terminal_equities()
snapshot(look, 'terminal_cfvs')
look:_compute_cfvs()
snapshot(look, 'current_cfvs')
look:_compute_regrets()
snapshot(look, 'regrets')
look:_compute_cumulate_average_cfvs(1)
snapshot(look, 'average_cfvs')

print('saved Torch7 one-iteration trace to ' .. out_dir)
