local out_dir = arg[1] or "/work/continual_lua_trace"
os.execute("mkdir -p " .. out_dir)

package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
local card_tools = require "Game.card_tools"
require "Player.continual_resolving"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local function save(name, t)
  torch.save(out_dir .. "/" .. name .. ".t7", t:float():contiguous())
end

local cr = ContinualResolving()

local state = {
  position = constants.players.P1,
  hand_id = 1
}

cr:start_new_hand(state)

local node = {
  board = arguments.Tensor{},
  street = 1,
  current_player = constants.players.P1,
  bets = arguments.Tensor{arguments.ante, arguments.ante},
  terminal = false
}

cr:_resolve_node(node, state)

save("before.player_range", cr.current_player_range)
save("before.starting_cfvs_p1", cr.starting_cfvs_p1)

local bet = 300
save("action.strategy", cr.resolving:get_action_strategy(bet))
save("action.opponent_cfv", cr.resolving:get_action_cfv(bet))

cr.current_opponent_cfvs_bound = cr.resolving:get_action_cfv(bet):clone()

local strategy = cr.resolving:get_action_strategy(bet)
cr.current_player_range:cmul(strategy)
cr.current_player_range =
  card_tools:normalize_range(node.board, cr.current_player_range)

cr.decision_id = cr.decision_id + 1
cr.last_bet = bet
cr.last_node = node

save("after.player_range", cr.current_player_range)
save("after.opponent_cfvs_bound", cr.current_opponent_cfvs_bound)

print("saved continual resolving raise300 trace")
