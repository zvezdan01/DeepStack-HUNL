from __future__ import annotations

import csv
import sys
from pathlib import Path

import numpy as np

from deepstack_leduc.terminal import TerminalEquity
from deepstack_leduc.torch7_tensor import load_float_tensor


ROOT = Path("terminal_all_street1_lua_trace")
MANIFEST = ROOT / "manifest.tsv"


def load_lua(leaf_index: int, name: str) -> np.ndarray:
    p = ROOT / f"leaf_{leaf_index:02d}" / f"{name}.t7"
    return np.asarray(load_float_tensor(p), dtype=np.float32)


def exact_equal(actual, expected) -> bool:
    a = np.asarray(actual, dtype=np.float32)
    e = np.asarray(expected, dtype=np.float32)
    return a.shape == e.shape and np.array_equal(a, e, equal_nan=True)


def compare(
    leaf_index: int,
    path: str,
    name: str,
    actual,
    failures: list[str],
) -> int:
    expected = load_lua(leaf_index, name)
    actual = np.asarray(actual, dtype=np.float32)

    if exact_equal(actual, expected):
        return 1

    tag = f"leaf_{leaf_index:02d} path={path} {name}"

    if actual.shape != expected.shape:
        failures.append(
            f"{tag}: shape python={actual.shape} lua={expected.shape}"
        )
        return 1

    same = (actual == expected) | (np.isnan(actual) & np.isnan(expected))
    diff = ~same
    n = int(diff.sum())

    if n:
        aa = actual.astype(np.float64)[diff]
        ee = expected.astype(np.float64)[diff]
        max_abs = float(np.max(np.abs(aa - ee)))
    else:
        max_abs = 0.0

    failures.append(f"{tag}: {n} values differ, max_abs={max_abs}")
    return 1


def load_manifest() -> list[dict[str, str]]:
    if not MANIFEST.exists():
        raise FileNotFoundError(f"missing manifest: {MANIFEST}")

    with MANIFEST.open("r", newline="") as f:
        rows = list(csv.DictReader(f, delimiter="\t"))

    if len(rows) != 18:
        raise AssertionError(
            f"expected 18 first-street terminal leaves in manifest, got {len(rows)}"
        )
    return rows


def main() -> int:
    if not ROOT.exists():
        print(f"ERROR: missing Lua trace directory: {ROOT}")
        return 2

    try:
        rows = load_manifest()
    except Exception as exc:
        print(f"ERROR: {exc}")
        return 2

    failures: list[str] = []
    tensors_checked = 0
    leaves_checked = 0
    folds = 0
    calls = 0

    for row in rows:
        leaf_index = int(row["index"])
        path = row["path"]
        kind = row["type"]
        street = int(row["street"])
        current_player = int(row["current_player"])
        folding_player = int(row["folding_player"])
        bet1 = np.float32(row["bet1"])
        bet2 = np.float32(row["bet2"])
        pot = np.float32(row["pot"])
        board_cards = int(row["board_cards"])

        leaf_failures_before = len(failures)

        if street != 1:
            failures.append(
                f"leaf_{leaf_index:02d} path={path}: expected street=1, got {street}"
            )
        if board_cards != 0:
            failures.append(
                f"leaf_{leaf_index:02d} path={path}: expected empty board, got {board_cards} cards"
            )

        if kind == "fold":
            folds += 1
            if folding_player not in (0, 1):
                failures.append(
                    f"leaf_{leaf_index:02d} path={path}: invalid folding_player={folding_player}"
                )
            if current_player not in (0, 1):
                failures.append(
                    f"leaf_{leaf_index:02d} path={path}: invalid current_player={current_player}"
                )
            if folding_player == current_player:
                failures.append(
                    f"leaf_{leaf_index:02d} path={path}: folding_player equals terminal current_player"
                )
        elif kind == "call":
            calls += 1
            if folding_player != -1:
                failures.append(
                    f"leaf_{leaf_index:02d} path={path}: call leaf has folding_player={folding_player}"
                )
        else:
            failures.append(
                f"leaf_{leaf_index:02d} path={path}: unknown terminal type={kind!r}"
            )

        ranges = load_lua(leaf_index, "ranges")
        te = TerminalEquity(())

        tensors_checked += compare(
            leaf_index, path, "ranges", ranges, failures
        )
        tensors_checked += compare(
            leaf_index, path, "call_matrix", te.call_matrix, failures
        )
        tensors_checked += compare(
            leaf_index, path, "fold_matrix", te.fold_matrix, failures
        )

        if kind == "fold":
            raw = te.fold_values(ranges, folding_player)
        elif kind == "call":
            raw = te.call_values(ranges)
        else:
            raw = np.zeros_like(ranges, dtype=np.float32)

        raw = np.asarray(raw, dtype=np.float32)
        scaled = np.asarray(raw * pot, dtype=np.float32)
        bets = np.asarray([bet1, bet2], dtype=np.float32)

        tensors_checked += compare(
            leaf_index, path, "raw_values", raw, failures
        )
        tensors_checked += compare(
            leaf_index, path, "scaled_values", scaled, failures
        )
        tensors_checked += compare(
            leaf_index, path, "bets", bets, failures
        )

        leaves_checked += 1

        this_failed = len(failures) != leaf_failures_before
        print(
            ("FAIL" if this_failed else "PASS"),
            f"leaf {leaf_index:02d}",
            kind,
            f"path={path}",
            f"pot={float(pot):.0f}",
        )

    print()
    print(f"LEAVES: {leaves_checked}")
    print(f"FOLDS: {folds}")
    print(f"CALLS: {calls}")
    print(f"TENSORS CHECKED: {tensors_checked}")

    if failures:
        print(f"FAILURES: {len(failures)}")
        for failure in failures[:100]:
            print(" -", failure)
        return 1

    print(
        f"PASS: {leaves_checked}/{leaves_checked} first-street terminal leaves "
        f"and {tensors_checked} tensors bit-exact"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
