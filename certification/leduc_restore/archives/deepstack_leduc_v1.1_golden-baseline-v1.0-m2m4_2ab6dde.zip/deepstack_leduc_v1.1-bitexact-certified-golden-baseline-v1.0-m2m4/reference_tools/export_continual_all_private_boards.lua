package.path = package.path .. ";./Source/?.lua;./Source/?/init.lua"

require "torch"
local arguments = require "Settings.arguments"
local constants = require "Settings.constants"
local card_tools = require "Game.card_tools"
require "Player.continual_resolving"

arguments.gpu = false
arguments.Tensor = torch.FloatTensor

local root_out = arg[1] or "/work/continual_all_private_boards_lua_trace"
os.execute("mkdir -p " .. root_out)

local function save(dir, name, t)
  torch.save(dir .. "/" .. name .. ".t7", t:float():contiguous())
end

for private_id = 1, 6 do
  local cr = ContinualResolving()
  local state = { position = constants.players.P1, hand_id = private_id }
  cr:start_new_hand(state)

  local node1 = {
    board = arguments.Tensor{},
    street = 1,
    current_player = constants.players.P1,
    bets = arguments.Tensor{arguments.ante, arguments.ante},
    terminal = false
  }

  cr:_resolve_node(node1, state)

  local bet = 300
  local strategy = cr.resolving:get_action_strategy(bet)
  cr.current_opponent_cfvs_bound = cr.resolving:get_action_cfv(bet):clone()
  cr.current_player_range:cmul(strategy)
  cr.current_player_range = card_tools:normalize_range(node1.board, cr.current_player_range)
  cr.decision_id = cr.decision_id + 1
  cr.last_bet = bet
  cr.last_node = node1

  local base_player_range = cr.current_player_range:clone()
  local base_opponent_cfvs = cr.current_opponent_cfvs_bound:clone()
  local first_resolving = cr.resolving

  for board_id = 1, 6 do
    if board_id ~= private_id then
      local out_dir = root_out .. "/private_" .. tostring(private_id) .. "_board_" .. tostring(board_id)
      os.execute("mkdir -p " .. out_dir)

      cr.current_player_range = base_player_range:clone()
      cr.current_opponent_cfvs_bound = base_opponent_cfvs:clone()
      cr.resolving = first_resolving
      cr.last_bet = bet
      cr.last_node = node1

      save(out_dir, "street1.after_action.player_range", cr.current_player_range)
      save(out_dir, "street1.after_action.opponent_cfvs", cr.current_opponent_cfvs_bound)

      local node2 = {
        board = arguments.Tensor{board_id},
        street = 2,
        current_player = constants.players.P1,
        bets = arguments.Tensor{300, 300},
        terminal = false
      }

      cr:_update_invariant(node2, state)

      save(out_dir, "street2.invariant.player_range", cr.current_player_range)
      save(out_dir, "street2.invariant.opponent_cfvs", cr.current_opponent_cfvs_bound)

      cr.resolving = Resolving()
      cr.resolving:resolve(node2, cr.current_player_range, cr.current_opponent_cfvs_bound)

      save(out_dir, "street2.achieved_cfvs", cr.resolving.resolve_results.achieved_cfvs)
      save(out_dir, "street2.strategy_all", cr.resolving.resolve_results.strategy)
      save(out_dir, "street2.children_cfvs_all", cr.resolving.resolve_results.children_cfvs)

      local possible = cr.resolving:get_possible_actions()
      save(out_dir, "street2.possible_actions", possible)

      for i = 1, possible:size(1) do
        local action = possible[i]
        save(out_dir, "street2.strategy_" .. tostring(action), cr.resolving:get_action_strategy(action))
        save(out_dir, "street2.cfv_" .. tostring(action), cr.resolving:get_action_cfv(action))
      end

      print("PASS private", private_id, "board", board_id)
    end
  end
end

print("PASS: saved all 30 private-card/board traces")
