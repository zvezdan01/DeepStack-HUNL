# Milestone 3 audit

Implemented directly from `Source/Lookahead/lookahead_builder.lua`:

- per-depth action, terminal-action, bet and non-all-in-bet counts;
- acting-player alternation and structural node-count tables;
- NumPy allocations matching the Torch7 tensor dimensions;
- pot-size filling and original 1-based lookahead coordinates;
- padded-action placement and empty-action masks;
- root flags (`first_call_terminal`, `first_call_transition`, `first_call_check`);
- free-check fold masking.

## Corrected defect

The earlier Python tree exported `CHANCE = 0`, while player 0 is a real player and all
actual chance nodes were encoded as `-1`. This made consumers misclassify player-0 nodes
as chance nodes. The constant is now `CHANCE = -1`, consistent with every constructed
chance node and the original Lua separation between players and chance.

## Verification

- full public tree remains 653 nodes, depth 9;
- depth-limited lookahead trees build without negative dimensions;
- all current tests pass: 22 passed;
- `compileall` passes.

## Not yet complete

The tensor layout is now present, but the iterative numerical operations from
`lookahead.lua` (range propagation, terminal values, CFV backpropagation, regret updates,
averaging and result extraction) still need to be ported and differentially checked.
