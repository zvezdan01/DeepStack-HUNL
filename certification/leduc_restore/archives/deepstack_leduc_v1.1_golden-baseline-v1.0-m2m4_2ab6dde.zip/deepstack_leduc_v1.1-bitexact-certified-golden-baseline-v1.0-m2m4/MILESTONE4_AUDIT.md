# Milestone 4 audit — recursive lookahead and resolving

## Added

- `deepstack_leduc/lookahead.py`
  - CFR+ iteration order from `Source/Lookahead/lookahead.lua`
  - regret matching and non-negative cumulative regrets
  - exact range propagation by acting-player strategy
  - fold/call terminal CFVs and pot scaling
  - depth-limited chance leaves through `NextRoundValue`
  - root-only average strategy accumulation after `cfr_skip_iters`
  - average root CFVs and normalized per-action opponent CFVs
  - CFR-D opponent range reconstruction on every iteration
  - post-chance board CFV extraction
- `deepstack_leduc/resolving.py`
  - `resolve_first_node`, `resolve`
  - legal action mapping
  - root/action/chance CFV and action-strategy accessors

## Representation note

The Lua implementation packs all nodes at equal depth into tensors. The Python
port now executes the same equations recursively on concrete public-tree nodes.
This avoids padded-action tensor slots while preserving concrete action order and
CFR semantics. It is a numerical/behavioral port, not a byte-for-byte tensor
layout reproduction.

## Validation

- River lookahead root strategy is compared with the independent full-tree CFR+
  path on the same complete river tree.
- First-street depth-limited solving is exercised through the exact
  `MockNNTerminal` network.
- Chance-board CFVs are checked for shape, finiteness and blocked-card masking.
- CFR-D solving is exercised separately.
- Full suite: 25 tests passed.

## Still incomplete

- `continual_resolving.lua` port
- original Torch7 checkpoint parameter import and numerical inference comparison
- ACPC runtime wired to the new resolver
- Lua-vs-Python differential fixtures for intermediate iteration tensors
