# Milestone 5 audit — continual resolving and ACPC state bridge

This milestone continues from the corrected packed-tensor lookahead. The active
online agent no longer uses the old full-tree CFR baseline.

## Ported from the original ZIP

- `Source/Player/continual_resolving.lua`
  - one pre-solved first node,
  - P1 first-decision shortcut,
  - P2 initialization from `starting_cfvs_p1`,
  - player-range update immediately after our action,
  - opponent-CFV-bound update immediately after our action,
  - chance-transition update through `get_chance_action_cfv`,
  - board collision masking and range normalization,
  - per-private-card action sampling.
- `Source/ACPC/protocol_to_node.lua`
  - strict ACPC action parsing,
  - P1/P2 actor assignment on each street,
  - current actor detection,
  - total commitment reconstruction,
  - conversion to the public-node representation.
- `Source/Player/deepstack.lua`
  - new-hand detection,
  - online `ContinualResolving.compute_action` path.

## Deliberate representation conversion

Lua uses players P1=1 and P2=2. Python uses P1=0 and P2=1 consistently.
This is an index-base conversion, not an algorithmic substitution.

## Verification performed

- 30 Python tests pass.
- `python -m compileall` passes.
- Root P1, P2-after-raise, and chance-transition ACPC states are tested.
- A first continual-resolving action is solved, sampled, and its tracked
  player range and opponent CFV bound are updated.

## Not yet certified

- The original Torch7 `final_cpu.model` weights are not yet imported into the
  PyTorch graph.
- There is no live Torch7-vs-Python intermediate-tensor differential run in
  this environment.
- The ACPC continual-resolving player has not yet completed a full dealer match
  using the original learned value network.
